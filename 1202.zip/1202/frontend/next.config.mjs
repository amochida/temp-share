/**
 * Next.js の基本設定ファイル。
 * strict mode を維持しつつ、`tsconfig.json` のパスエイリアス (`@/`) を
 * webpack 解決にも確実に反映させる。
 */

import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const ensureSwcWasm = () => {
  if (!process.env.SWC_BINARY_PATH) {
    const require = createRequire(import.meta.url);
    try {
      process.env.SWC_BINARY_PATH = require.resolve("@next/swc-wasm-nodejs/wasm_bg.wasm");
    } catch (error) {
      // wasm パッケージが無い場合は Next.js のデフォルトに任せる
    }
  }
};

ensureSwcWasm();

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  webpack: (config) => {
    const currentDir = path.dirname(fileURLToPath(import.meta.url));
    config.resolve.alias["@"] = config.resolve.alias["@"] ?? currentDir;
    return config;
  }
};

export default nextConfig;
