import type { Config } from "tailwindcss";

// Tailwind CSS の設定ファイル。`features` 配下を含む全画面をスキャン対象にする。
const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/features/**/*.{ts,tsx}",
    "./src/shared/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        /**
         * brand: ブランドアイデンティティを示す主要カラー群。
         *         「アプリの個性」を作る色であり、行動喚起や強調に使用される。
         *         (brand = ブランド・商標)
         * - primary: 主要なブランドカラー。送信ボタン、強調リンク、スレッド背景など「行動させたい箇所」で使用。
         * - accent: アクセントカラー。primary と対になる警告・通知・強調用の補助色。
         * - on: brand 背景上に載せる文字色。通常は白。on = “on color”（上に置く色）を意味する。
         */
        brand: {
          primary: "#0091DC",
          accent: "#FE0000",
          on_right: "#FFFFFF",
          on_dark: "#1F2433"
        },
        /**
         * support: ブランドを支えるコーポレートトーン。
         *           画面全体の安定感や信頼感を作るベースカラー群。
         *           (support = 支える、補助する)
         * - main: ヘッダー・サイドバーなど、静的な背景に使用。ここを変えると全体の印象が大きく変化。
         * - neutral: ニュートラル（中間的）な背景。surface.page の基調色としても使用。
         * - on: support 背景上の文字色。一般的には白。on = “on color”。
         */
        support: {
          main: "#585481",
          neutral: "#E8E9ED",
          on_right: "#FFFFFF",
          on_dark: "#1F2433"
        },
        /**
         * surface: コンテンツを載せる「表面（レイヤー）」の色。
         *           ページ・カード・フォームなど、UI要素の背景層を表す。
         *           (surface = 表面、外層)
         * - page: ページ全体のキャンバス色。背景トーンを決定する基礎。
         * - panel: カード・モーダルなどの標準背景。
         * - muted: 入力欄やバッジなど、控えめな背景色。muted = 落ち着いた、抑えた。
         * - border: 区切り線や枠線。彩度を抑え、他要素とのコントラストを保つ。
         */
        surface: {
          page: "#E8E9ED",
          panel: "#FFFFFF",
          muted: "#F4F6FB",
          border: "#D2D7E3"
        },
        /**
         * content: テキスト・アイコンなど「情報（内容）」の色。
         *           brand/support と調和しつつ、読みやすさのために階層的なコントラストを設ける。
         *           (content = 内容、中身)
         * - primary: メインテキスト色。本文やタイトルなど、最も視認性を重視する箇所に使用。
         * - secondary: サブテキスト色。補足情報・説明文などに使用。
         * - tertiary: 三次的テキスト色。さらに弱い情報や注釈用。
         * - muted: 控えめなテキスト。無効状態や補助テキストなど。
         * - subtle: かすかなテキスト。アイコンや補助的な装飾など。
         * - inverse: 暗色背景（brand/supportなど）上で使用する反転色。通常は白。
         */
        content: {
          primary: "#1F2433",
          secondary: "#272F42",
          tertiary: "#3C455A",
          muted: "#585481",
          subtle: "#737894",
          inverse: "#FFFFFF"
        },
        /**
         * action: ボタン・リンクなどの「インタラクティブ要素」の色。
         *          状態変化（通常・ホバーなど）を明示し、操作感を演出する。
         *          (action = 行動、操作)
         * - strong: プライマリボタン背景色。brand.primary と揃えており、最も目立つアクションを示す。
         * - strongHover: strong のホバー時。やや暗くしてクリック可能性を視覚的に示唆。
         * - subtle: セカンダリボタン背景色。support.main に近い落ち着いたトーン。
         * - subtleHover: subtle のホバー時。わずかに濃くしてインタラクションを示す。
         */
        action: {
          strong: "#0091DC",
          strongHover: "#0075B2",
          subtle: "#585481",
          subtleHover: "#4B4A6B"
        }
      },
      /**
       * keyframes: アニメーション定義。
       *             typing-bounce は入力中の「ドットが跳ねる」動きを表現する。
       */
      keyframes: {
        "typing-bounce": {
          "0%, 80%, 100%": {
            transform: "translateY(0)",
            opacity: "0.3"
          },
          "40%": {
            transform: "translateY(-6px)",
            opacity: "1"
          }
        }
      },
      /**
       * animation: keyframes を呼び出すためのショートカット名。
       *             typing-dot は入力インジケータ（…）で使用。
       */
      animation: {
        "typing-dot": "typing-bounce 1s ease-in-out infinite"
      }
    }
  },
  plugins: []
};

export default config;
