/**
 * 画面全体で繰り返し利用するクラス名集合。
 * Tailwind のデザイン・トークンを統一して使えるようにすることで、
 * どのページでも同じ見た目と余白ルールを再現しやすくする目的で定義している。
 */

/**
 * 入力欄の共通スタイル。
 * - 余計な枠線を排除しつつ、背景色で入力領域を明示する。
 * - フォーカス時は背景を白に戻して視認性を高める。
 */
export const INPUT_BASE_CLASS =
  "border border-transparent bg-surface-muted px-2 py-1 text-sm text-content-secondary focus:bg-surface-panel focus:border-brand-primary/40 focus:outline-none rounded-md";

/**
 * プライマリボタンの共通スタイル。
 * - 濃色背景＋白文字で主ボタンであることを強調する。
 * - ホバー時は若干明るくし、disabled では透明度を下げて無効状態を表現する。
 */
export const PRIMARY_BUTTON_CLASS =
  "bg-action-strong px-3 py-1 text-sm font-semibold text-content-inverse hover:bg-action-strongHover disabled:opacity-40 rounded-lg";

/**
 * セカンダリボタン（淡色背景）の共通スタイル。
 * - 背景は淡いニュートラルカラーで、文字色を抑えている。
 * - ホバー時はブランドカラーに近い色へ遷移し、クリック可能であることを伝える。
 */
export const SECONDARY_BUTTON_CLASS =
  "bg-surface-muted px-3 py-1 text-sm text-content-tertiary hover:text-brand-primary border border-surface-border rounded-lg";

/**
 * テーブル一覧などで繰り返し使う小さめの淡色ボタン。
 * 右寄せの削除ボタンやページャーなど、文字情報が主役の場面で利用する。
 */
export const TERTIARY_TEXT_BUTTON_CLASS =
  "bg-surface-muted px-2 py-1 text-sm text-content-tertiary hover:text-brand-primary disabled:cursor-not-allowed disabled:opacity-40 border border-transparent rounded-lg";

/**
 * 画面説明など淡い補足テキストで利用するクラス。
 * 常に `text-sm` で統一し、カラーのみをトークン化している。
 */
export const SUPPORT_TEXT_CLASS = "text-sm text-content-subtle";

/**
 * セクション見出しの共通クラス。
 * 太字＋一次色の組み合わせで階層を明確にする。
 */
export const SECTION_HEADING_CLASS = "text-base font-semibold text-content-primary";
