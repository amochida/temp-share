"use client";

import { useCallback, useEffect, useRef, useState, type Dispatch, type FormEvent, type SetStateAction } from "react";

interface FetchOptions {
  offset: number;
  limit: number;
}

interface PaginatedResponse<TResult> {
  items: TResult[];
  total: number;
}

export interface UsePaginatedSearchOptions<TState, TResult> {
  initialState: () => TState;
  fetcher: (state: TState, options: FetchOptions) => Promise<PaginatedResponse<TResult>>;
  pageSize?: number;
  cloneState?: (state: TState) => TState;
}

export interface UsePaginatedSearchResult<TState, TResult> {
  formState: TState;
  setFormState: Dispatch<SetStateAction<TState>>;
  appliedState: TState;
  items: TResult[];
  total: number;
  loading: boolean;
  error: string | null;
  handleSubmit: (event?: FormEvent<HTMLFormElement>) => void;
  loadMore: () => void;
  hasMore: boolean;
  resetAppliedState: () => void;
}

const DEFAULT_PAGE_SIZE = 20;

function defaultCloneState<T>(state: T): T {
  return JSON.parse(JSON.stringify(state)) as T;
}

export function usePaginatedSearch<TState, TResult>({
  initialState,
  fetcher,
  pageSize = DEFAULT_PAGE_SIZE,
  cloneState = defaultCloneState
}: UsePaginatedSearchOptions<TState, TResult>): UsePaginatedSearchResult<TState, TResult> {
  const [formState, setFormState] = useState<TState>(() => initialState());
  const [appliedState, setAppliedState] = useState<TState>(() => initialState());
  const [items, setItems] = useState<TResult[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const loadingRef = useRef(false);

  const fetchPage = useCallback(
    (state: TState, nextOffset: number, append: boolean) => {
      if (loadingRef.current) {
        return;
      }
      loadingRef.current = true;
      setLoading(true);
      setError(null);
      fetcher(state, { offset: nextOffset, limit: pageSize })
        .then((payload) => {
          setTotal(payload.total);
          setItems((prev) => (append ? [...prev, ...payload.items] : payload.items));
          const updatedOffset = nextOffset + payload.items.length;
          setOffset(updatedOffset);
          setHasMore(updatedOffset < payload.total);
        })
        .catch((err) => {
          setError(err instanceof Error ? err.message : "検索に失敗しました");
        })
        .finally(() => {
          loadingRef.current = false;
          setLoading(false);
        });
    },
    [fetcher, pageSize]
  );

  useEffect(() => {
    setItems([]);
    setTotal(0);
    setOffset(0);
    setHasMore(true);
    setError(null);
    fetchPage(appliedState, 0, false);
  }, [appliedState, fetchPage]);

  const applyFormState = useCallback(() => {
    setAppliedState(cloneState(formState));
  }, [cloneState, formState]);

  const handleSubmit = useCallback(
    (event?: FormEvent<HTMLFormElement>) => {
      event?.preventDefault();
      applyFormState();
    },
    [applyFormState]
  );

  const loadMore = useCallback(() => {
    if (!hasMore || loadingRef.current) {
      return;
    }
    fetchPage(appliedState, offset, true);
  }, [appliedState, fetchPage, hasMore, offset]);

  const resetAppliedState = useCallback(() => {
    setAppliedState(initialState());
  }, [initialState]);

  return {
    formState,
    setFormState,
    appliedState,
    items,
    total,
    loading,
    error,
    handleSubmit,
    loadMore,
    hasMore,
    resetAppliedState
  };
}
