import { useCallback, useEffect, useRef } from "react";

/**
 * IntersectionObserver を利用して簡易的な無限スクロールを実現するためのフック。
 * target 要素が画面に入ったことを検知すると callback を呼び出す。
 */
/**
 * 無限スクロール用のカスタムフック。
 * @param callback 対象要素が画面内に入ったときに呼び出される関数
 * @param options IntersectionObserver のオプション（rootMargin 等）
 */
export function useInfiniteScroll(
  callback: () => void,
  options?: IntersectionObserverInit
): (node: Element | null) => void {
  const observerRef = useRef<IntersectionObserver | null>(null);
  const callbackRef = useRef(callback);

  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  const setTarget = useCallback(
    (node: Element | null) => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
      if (node) {
        observerRef.current = new IntersectionObserver((entries) => {
          if (entries[0]?.isIntersecting) {
            callbackRef.current();
          }
        }, options);
        observerRef.current.observe(node);
      }
    },
    [options]
  );

  useEffect(() => {
    return () => observerRef.current?.disconnect();
  }, []);

  return setTarget;
}
