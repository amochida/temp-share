/**
 * 選択肢のオン・オフ切り替えで毎回同じ配列操作を書かなくて済むよう、
 * includes で存在チェック → 追加/削除をまとめた小さなユーティリティを用意する。
 */
export function toggleListValue<T>(items: readonly T[], value: T): T[] {
  // 既に選択されている値は取り除き、未選択なら末尾に追加して新しい配列を返す。
  return items.includes(value)
    ? items.filter((item) => item !== value)
    : [...items, value];
}
