/**
 * 選択肢配列から value -> label のマップを生成する小さなユーティリティ。
 * 同じ変換処理を書き直さなくて済むように集約している。
 */
export function createValueLabelMap<T extends { value: string; label: string }>(
  options: readonly T[]
): Record<string, string> {
  return options.reduce<Record<string, string>>((accumulator, option) => {
    // value をキーに、表示用のラベルを素早く引けるよう連想配列へ詰め替える。
    accumulator[option.value] = option.label;
    return accumulator;
  }, {});
}
