import { NextRequest, NextResponse } from "next/server";

/**
 * Next.js 側の API Route で FastAPI バックエンドへリクエストを横流しする際に便利なユーティリティ群。
 * - 基本 URL の結合、認証ヘッダや社内疑似ユーザー情報の付与を一箇所にまとめている。
 * - プロキシとして Next.js が間に挟まる構成を想定しており、SSR/API Route から利用する。
 */
/**
 * Next.js から FastAPI を呼び出す際に利用する内部 URL。
 * docker 環境でも常にこのベースを使うことにより設定を一箇所に集約する。
 */
const FASTAPI_INTERNAL_BASE_URL = "http://127.0.0.1:8000";

// ローカル開発時に認証を簡略化するための疑似ユーザー情報。
// 実運用ではリバースプロキシなどが正しいヘッダーを付与し、この値は利用されない。
/**
 * ローカル開発用の疑似ユーザー情報。
 * - 本番環境ではリバースプロキシがヘッダーを付与するため利用されない。
 */
const FALLBACK_USER = {
  id: process.env.DEV_USER_ID ?? "guest-user",
  email: process.env.DEV_USER_EMAIL ?? "",
  department: process.env.DEV_USER_DEPARTMENT ?? ""
};

/** ヘッダー設定を json 固定にするか既存を引き継ぐかの指定。 */
type HeaderMode = "json" | "inherit" | undefined;

/**
 * フロントエンドから受け取ったパスを FastAPI 用の完全 URL に変換する小さなヘルパー。
 * path の先頭にスラッシュが付いていなくても正規化して補完する。
 */
export function fastapiUrl(path: string): string {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${FASTAPI_INTERNAL_BASE_URL}${normalizedPath}`;
}

/**
 * FastAPI へ転送する際に利用するヘッダを組み立てる。
 * - リクエスト ID（X-Request-Id）が届いている場合はそのまま引き継ぐ。
 * - ローカル開発環境では疑似ユーザー情報（ID/メール/部門）をヘッダで付与して認証の代わりにする。
 * - `mode` が `json` の場合だけ Content-Type を強制的に application/json に設定する。
 */
export function buildForwardHeaders(request: NextRequest, mode: HeaderMode = undefined): Headers {
  const headers = new Headers();

  const requestId = request.headers.get("x-request-id");
  if (requestId) {
    headers.set("X-Request-Id", requestId);
  }

  const userId = request.headers.get("x-user-id") ?? FALLBACK_USER.id;
  const userEmail = request.headers.get("x-user-email") ?? FALLBACK_USER.email;
  const userDept = request.headers.get("x-user-department") ?? FALLBACK_USER.department;

  headers.set("X-User-Id", userId);
  headers.set("X-User-Email", userEmail);
  headers.set("X-User-Department", userDept);

  const auth = request.headers.get("authorization");
  if (auth) {
    headers.set("Authorization", auth);
  }

  if (mode === "json") {
    headers.set("Content-Type", "application/json");
  }

  return headers;
}

/**
 * FastAPI から得た Response オブジェクトを NextResponse へ変換して返す。
 * - Body は text() で取り出し、ステータスコードや Content-Type をそのままコピーする。
 * - コンテンツ長などのヘッダは必要に応じて追加可能だが、ここでは最低限の passthrough に留めている。
 */
export async function proxyResponse(source: Response): Promise<NextResponse> {
  const payload = await source.text();
  const headers = new Headers();
  const contentType = source.headers.get("Content-Type");
  if (contentType) {
    headers.set("Content-Type", contentType);
  }
  return new NextResponse(payload, {
    status: source.status,
    headers
  });
}
