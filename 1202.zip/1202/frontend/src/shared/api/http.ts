import { Buffer } from "buffer";

/**
 * ブラウザ (クライアント側) から FastAPI へアクセスする際に利用する Next.js の RPC エンドポイント。
 * すべてのリクエストをこのプレフィックスに集約し、ブラウザから直接 FastAPI を晒さないようにする。
 */
const API_BASE_PATH = "/api/rpc";

/**
 * 文字列を Base64 へ変換する小さなユーティリティ。
 * - Node.js 実行環境では Buffer、ブラウザでは btoa を使い分ける。
 */
function encodeBase64(value: string): string {
  if (typeof window === "undefined") {
    return Buffer.from(value, "utf-8").toString("base64");
  }
  return btoa(unescape(encodeURIComponent(value)));
}

/** Base64 文字列を UTF-8 テキストへ戻す。 */
function decodeBase64(value: string): string {
  if (typeof window === "undefined") {
    return Buffer.from(value, "base64").toString("utf-8");
  }
  try {
    return decodeURIComponent(escape(atob(value)));
  } catch {
    return atob(value);
  }
}

/**
 * 複数値を持つクエリパラメータを安全にエンコードするための関数。
 * - FastAPI へ渡す際は `?p=<base64>` という 1 つの URL パラメータにまとめて送る。
 */
export function encodeQueryParams(search?: URLSearchParams | null): string {
  if (!search || Array.from(search.keys()).length === 0) {
    return "";
  }
  const payload: Record<string, string[]> = {};
  search.forEach((value, key) => {
    if (!payload[key]) {
      payload[key] = [];
    }
    payload[key].push(value);
  });
  const encoded = encodeBase64(JSON.stringify(payload));
  return `?p=${encodeURIComponent(encoded)}`;
}

/** fetch 結果を汎用的に扱うための独自エラー。 */
export class ApiError extends Error {
  status: number;
  body: string;

  constructor(status: number, body: string, message?: string) {
    super(message ?? `Request failed with status ${status}`);
    this.status = status;
    this.body = body;
    this.name = "ApiError";
  }
}

/**
 * 渡されたパスを RPC 用の完全 URL へ変換する。
 * - http(s) で始まる場合はそのまま利用し、プレフィックスがない場合は `/api/rpc` を付加する。
 */
function resolveUrl(path: string): string {
  if (path.startsWith("http://") || path.startsWith("https://")) {
    return path;
  }
  const normalized = path.startsWith("/") ? path : `/${path}`;
  return `${API_BASE_PATH}${normalized}`;
}

/**
 * エラーレスポンスの本文をテキスト化するヘルパー。
 * - エンベロープ形式の場合は decodeEnvelope で元の JSON/文字列を取り出す。
 */
async function parseBody(response: Response): Promise<string> {
  try {
    const text = await response.text();
    if (!text) {
      return "";
    }
    const decoded = decodeEnvelope(text);
    if (decoded === null) {
      return text;
    }
    return typeof decoded === "string" ? decoded : JSON.stringify(decoded);
  } catch (error) {
    return "";
  }
}

/**
 * 基本的な HTTP リクエストを発行する高機能ラッパー。
 * - fetch の初期化や JSON/テキスト応答の判定を一括で実施する。
 */
export async function apiRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (!(init.body instanceof FormData)) {
    headers.set("Accept", headers.get("Accept") ?? "application/json");
  }
  const response = await fetch(resolveUrl(path), {
    credentials: "include",
    cache: "no-store",
    ...init,
    headers
  });
  if (!response.ok) {
    const body = await parseBody(response);
    throw new ApiError(response.status, body);
  }
  if (response.status === 204) {
    return undefined as T;
  }
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const payload = await response.json();
    const decoded = decodeEnvelope(payload);
    if (decoded !== null) {
      return decoded as T;
    }
    return payload as T;
  }
  const text = await response.text();
  return text as T;
}

/**
 * JSON ボディを送信するリクエスト専用の補助関数。
 * - payload を Base64 包装した上で apiRequest に委譲する。
 */
export function apiJsonRequest<T>(path: string, payload: unknown, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Content-Type", "application/json");
  const encoded = encodeBase64(JSON.stringify(payload ?? {}));
  return apiRequest<T>(path, {
    ...init,
    headers,
    body: JSON.stringify({ p: encoded })
  });
}

/**
 * FastAPI 側で Base64 包装されたレスポンスを元に戻す。
 * - 文字列/オブジェクトのどちらでも対応するため、再帰的に `p` フィールドを探す。
 */
function decodeEnvelope(value: unknown): any {
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      const decoded = decodeEnvelope(parsed);
      if (decoded !== null) {
        return decoded;
      }
    } catch {
      // plain string
    }
    return value;
  }
  if (value && typeof value === "object" && "p" in value && typeof (value as Record<string, unknown>).p === "string") {
    const text = decodeBase64((value as Record<string, unknown>).p as string);
    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  }
  return null;
}
