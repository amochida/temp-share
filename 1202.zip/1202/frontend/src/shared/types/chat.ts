import type { components } from "@/shared/api/generated";

type Schemas = components["schemas"];

/**
 * チャット機能に関わるドメインモデルを集約したモジュール。
 * FastAPI (OpenAPI) の型を再利用しつつ、UI 固有の構造体のみを追加で定義する。
 */

/** UI 表示用に整形されたスレッド概要。 */
export interface ThreadSummary {
  id: string;
  title: string;
  lastMessage: string;
  updatedAt: string;
  department: string;
  documentType: string;
  isDraft?: boolean;
}

export type AnswerMode = "documents" | "all";

export type ThreadApiEntity = Schemas["ThreadResponse"];
export type ThreadListApiResponse = Schemas["ThreadListResponse"];
export type ChatApiCitation = Schemas["ChatCitation"];
export type ChatApiResponse = Schemas["ChatAnswer"];
export type ChatAskPayload = Schemas["ChatQueryRequest"];
export type ChatAskPayloadHistoryItem = Schemas["ChatHistoryTurn"];
export type ChatAskPayloadFilters = Schemas["ChatQueryFilters"];
export type ChatHistoryItem = Schemas["ChatMessage"];
export type ChatHistoryResponse = Schemas["ChatHistoryResponse"];
export type ChatSavePayloadMessage = Schemas["ChatSaveMessage"];
export type ChatSavePayload = Schemas["ChatSaveRequest"];
export type ChatSaveResponse = Schemas["ChatSaveResponse"];
export type FeedbackContextMessage = Schemas["FeedbackContextMessage"];
export type FeedbackPayload = Schemas["FeedbackCreateRequest"];
export type FeedbackLatestRecord = Schemas["FeedbackLatestRecord"];
export type FeedbackLatestResponse = Schemas["FeedbackLatestResponse"];

/** LLM 応答に付随する引用情報 (UI 表示用) 。 */
export interface Citation {
  documentId: string;
  chunkId: string;
  title?: string;
  snippet?: string;
  faqId?: string;
  score?: number;
  source?: string;
  sourceUri?: string;
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
  rating?: "good" | "bad" | null;
  queryId?: string;
  promptType?: string;
  createdAt?: string;
  sourcesUsed?: string[];
}

export interface ThreadFilterState {
  mode: AnswerMode;
  documentCategories: string[];
  departments: string[];
  priority: string;
}

/** フィルタ状態をバッジとして表示するときに利用する型を共通化。 */
export type ChatFilterBadgeType = "department" | "document" | "priority" | "mode";

export interface ChatFilterBadge {
  value: string;
  label: string;
  type: ChatFilterBadgeType;
}
