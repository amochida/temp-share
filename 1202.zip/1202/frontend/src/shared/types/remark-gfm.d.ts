import type { Plugin } from "unified";

declare module "remark-gfm" {
  const remarkGfm: Plugin;
  export default remarkGfm;
}
