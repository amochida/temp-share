import type { components } from "@/shared/api/generated";

/**
 * スタッフ向け管理画面で扱うドメインモデルの定義集。
 * FastAPI (OpenAPI) で生成した型定義をそのまま参照し、
 * 自前の DTO を極力減らすことを目的としている。
 */

type Schemas = components["schemas"];

export type DocumentRecord = Schemas["DocumentResponse"];
export type DocumentListResponse = Schemas["DocumentListResponse"];
export type DocumentUploadResponse = Schemas["DocumentUploadResponse"];
export type DocumentUpdatePayload = Schemas["DocumentUpdateRequest"];
export type DocumentStatus = DocumentRecord["status"];
export type RegistrationType = DocumentRecord["registration_type"];
export type PublicScope = DocumentRecord["public_scope"];

/** ドキュメント検索に指定できるパラメータ。 */
export interface DocumentSearchParams {
  department_codes?: string[];
  document_types?: string[];
  public_scopes?: PublicScope[];
  statuses?: DocumentStatus[];
  q?: string;
  semantic_query?: string;
  limit?: number;
  offset?: number;
}

export type FAQRecord = Schemas["FAQResponse"];
export type FAQListResponse = Schemas["FAQListResponse"];
export type FAQPayload = Schemas["FAQPayload"];
export type FAQUploadResponse = Schemas["FAQUploadResponse"];
export type FAQStatus = FAQRecord["status"];
export type FAQScope = FAQRecord["public_scope"];

/** FAQ 検索に指定できるパラメータ。 */
export interface FAQSearchParams {
  department_codes?: string[];
  categories?: string[];
  faq_types?: string[];
  public_scopes?: FAQScope[];
  statuses?: FAQStatus[];
  q?: string;
  semantic_query?: string;
  limit?: number;
  offset?: number;
}
