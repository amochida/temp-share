"use client";

import type { FormHTMLAttributes, PropsWithChildren, ReactNode } from "react";

/**
 * 絞り込みカードで共通的に利用する <form> コンポーネントの props。
 * - actions: 送信ボタンなど右下に並べたい要素を受け取る。
 */
interface FilterFormCardProps extends FormHTMLAttributes<HTMLFormElement> {
  actions: ReactNode;
}

const baseClass = "space-y-2 bg-surface-panel px-3 py-3 border border-surface-border rounded-lg";

/**
 * フィルタフォームをカード状に表示するためのラッパー。
 * - children: フィルタ本体
 * - actions: 送信/リセットボタンなどのボタン群
 */
export default function FilterFormCard({ actions, children, className, ...props }: PropsWithChildren<FilterFormCardProps>) {
  return (
    <form {...props} className={className ? `${baseClass} ${className}` : baseClass}>
      {children}
      <div className="flex items-center gap-2">{actions}</div>
    </form>
  );
}
