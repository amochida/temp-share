/**
 * フロントエンド全体で共有する選択肢マスタ。
 * チャット・スタッフ画面双方が同じ定義を参照し二重管理を避ける。
 */


export const DEPARTMENT_OPTIONS = [
  { value: "HR", label: "人事部" },
  { value: "IT", label: "情報システム部" },
  { value: "FIN", label: "財務部" },
  { value: "ADM", label: "総務部" },
  { value: "PR", label: "広報部" },
  { value: "CS", label: "CS推進部" }
] as const;

export const DOCUMENT_CATEGORY_OPTIONS = [
  { value: "manual", label: "手順書" },
  { value: "guide", label: "説明書" },
  { value: "policy", label: "規程" },
  { value: "guideline", label: "ガイドライン" },
  { value: "form", label: "申請書式" },
  { value: "memo", label: "社内通達" }
] as const;

export const DEFAULT_DOCUMENT_CATEGORY_SELECTION = ["manual", "guide"] as const;

/** スタッフ画面との互換のための別名。 */
export const DOCUMENT_TYPE_OPTIONS = DOCUMENT_CATEGORY_OPTIONS;

export const FAQ_CATEGORY_OPTIONS = [
  { value: "attendance", label: "勤怠" },
  { value: "benefit", label: "福利厚生" },
  { value: "it", label: "ITサポート" },
  { value: "policy", label: "社内ポリシー" },
  { value: "security", label: "セキュリティ" },
  { value: "procedures", label: "申請手続き" }
] as const;

export const FAQ_TYPE_OPTIONS = [
  { value: "procedure", label: "手続き" },
  { value: "rule", label: "規則" },
  { value: "guidance", label: "ガイダンス" },
  { value: "troubleshooting", label: "トラブル対応" }
] as const;

export const PRIORITY_OPTIONS = [
  { value: "balanced", label: "バランス" },
  { value: "document-first", label: "規程優先" },
  { value: "faq-first", label: "FAQ優先" }
] as const;

export const PUBLIC_SCOPE_OPTIONS = [
  { value: "internal", label: "社内限定" },
  { value: "restricted", label: "限定公開" },
  { value: "public", label: "全社公開" }
] as const;

export const DOCUMENT_STATUS_OPTIONS = [
  { value: "processing", label: "処理中" },
  { value: "ready", label: "公開中" },
  { value: "error", label: "エラー" },
  { value: "archived", label: "アーカイブ" }
];

export const FAQ_STATUS_OPTIONS = [
  { value: "draft", label: "下書き" },
  { value: "ready", label: "公開中" },
  { value: "archived", label: "アーカイブ" }
];
