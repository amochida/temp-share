"use client";

import Image from "next/image";

/**
 * チャット画面のメインページコンポーネント。
 * - `useChatSession` で取得した状態・ハンドラを、各 UI コンポーネントへ配線する役割を担う。
 * - Next.js の Use Client コンポーネントとして動作し、ブラウザ側でのインタラクションを管理する。
 */
import ActiveFilterBadges from "@/features/chat/components/ActiveFilterBadges";
import CategorySelector from "@/features/chat/components/CategorySelector";
import ChatContainer from "@/features/chat/components/ChatContainer";
import ChatInput from "@/features/chat/components/ChatInput";
import SupportModal from "@/features/chat/components/SupportModal";
import ThreadList from "@/features/chat/components/ThreadList";
import { useChatSession } from "@/features/chat/hooks/useChatSession";
import type { ThreadSummary } from "@/shared/types/chat";
import { useCallback, useEffect, useRef, useState } from "react";

/** 画面全体の背景と文字色を統一管理するユーティリティクラス。 */
const APP_LAYOUT_CLASS = "flex h-screen min-h-0 w-full flex-col bg-surface-page text-content-primary";
/**
 * メインエリアのレイアウト定義。
 * - モバイルでは縦一列、lg ブレークポイント以降はサイドバー＋メインの二列構成に切り替える。
 */
const CONTENT_LAYOUT_CLASS =
  "flex min-h-0 flex-1 flex-col lg:grid lg:grid-cols-[220px_minmax(0,1fr)] lg:grid-rows-1 lg:gap-px";
/** メッセージ領域＋入力領域を包む共通の背景。 */
const MAIN_COLUMN_CLASS = "flex min-h-0 flex-1 flex-col bg-surface-panel";
/** フィルタバー・バッジ欄に適用する背景スタイル。 */
const HEADER_SECTION_CLASS = "flex flex-col gap-2 bg-surface-panel px-3 py-2";

// ------------------------------------------------------------
// 画面コンポーネント
// ------------------------------------------------------------
/**
 * チャットページを描画するルートコンポーネント。
 * 初心者でも追えるよう、状態取得 → ハンドラ定義 → JSX の流れで記述している。
 */
export default function Home() {
  // ----------------------------------------------------------------------------------
  // useChatSession から取得できるチャット全体の状態と操作関数
  // ----------------------------------------------------------------------------------
  const {
    threads,
    activeThreadId,
    messages,
    input,
    isSending,
    threadFeaturesEnabled,
    filterOptions,
    filters,
    maxThreads,
    sendCurrentMessage,
    setInput,
    createThread,
    selectThread,
    deleteThread,
    rateMessage,
    toggleDocumentCategory,
    toggleDepartment,
    setPriority,
    setAnswerMode,
    resetAllFilters,
    clearDocumentCategories,
    clearDepartments,
    resetPriority,
    filterBadges,
    removeFilterBadge
  } = useChatSession();

  // ----------------------------------------------------------------------------------
  // ローカルステート: モーダル・フィルタパネルなど UI 固有の状態をここで管理する
  // ----------------------------------------------------------------------------------
  const [modalType, setModalType] = useState<"feedback" | "policy" | null>(null); // どのサポートモーダルを表示中か。null なら非表示。
  type FilterPaneKey = "mode" | "department" | "document" | "priority" | null;
  const [openFilterPane, setOpenFilterPane] = useState<FilterPaneKey>(null); // どのフィルタパネルが開いているか。null なら全て閉じる。
  const isModalOpen = modalType !== null; // モーダル表示中かどうかで背面 UI の操作可否を切り替える。
  const closeModal = useCallback(() => setModalType(null), []);
  const closeFilterPane = useCallback(() => setOpenFilterPane(null), []);

  const filterBarRef = useRef<HTMLDivElement | null>(null); // outside click 判定に利用する参照。
  const bottomRef = useRef<HTMLDivElement | null>(null); // メッセージ末尾を参照し、スクロール制御に使う。

  // ----------------------------------------------------------
  // エフェクト: 最新メッセージへスクロール
  // ----------------------------------------------------------
  useEffect(() => {
    // 新しいメッセージが追加されるたびに、リスト末尾まで自動スクロールさせる。
    const sentinel = bottomRef.current;
    if (!sentinel) return;

    const scrollContainer = sentinel.closest("[data-chat-scroll-container]") as HTMLElement | null;
    if (scrollContainer) {
      const targetTop = scrollContainer.scrollHeight;
      if (typeof scrollContainer.scrollTo === "function") {
        scrollContainer.scrollTo({ top: targetTop, behavior: "smooth" });
      } else {
        scrollContainer.scrollTop = targetTop;
      }
      return;
    }

    sentinel.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
  }, [messages]);

  // ----------------------------------------------------------
  // エフェクト: フィルタパネルの外側クリック/ESCで閉じる
  // ----------------------------------------------------------
  useEffect(() => {
    const handleClickAway = (event: MouseEvent) => {
      if (!filterBarRef.current) return;
      if (event.target instanceof Node && filterBarRef.current.contains(event.target)) return;
      closeFilterPane();
    };
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        closeFilterPane();
        closeModal();
      }
    };

    // フィルタバーの外側クリックと ESC キーで開いている UI を閉じる。
    document.addEventListener("mousedown", handleClickAway);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleClickAway);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [closeFilterPane, closeModal]);

  useEffect(() => {
    // モーダルが開いている間は body のスクロールを禁止し、背面の操作を防ぐ。
    document.body.style.overflow = isModalOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isModalOpen]);

  useEffect(() => {
    // モーダル表示時にフォーカスが既存要素に残っているとキーボード操作で予期しない挙動が出るため、一旦フォーカスを外す。
    if (!isModalOpen) return;
    const active = document.activeElement;
    if (active instanceof HTMLElement) {
      active.blur();
    }
  }, [isModalOpen]);

  // ----------------------------------------------------------
  // ハンドラ群
  // ----------------------------------------------------------
  /** メッセージ送信ボタン押下時の処理。非同期処理の結果は呼び出し元で待たせずに fire-and-forget 形式で呼ぶ。 */
  const handleSend = useCallback(() => {
    sendCurrentMessage().catch(() => {
      /* 内部でエラー処理済み */
    });
  }, [sendCurrentMessage]);

  /** 新規スレッド作成ボタン押下時の処理。エラーが発生した場合は簡易アラートでユーザーに知らせる。 */
  const handleCreateThread = useCallback(() => {
    createThread().catch((error) => {
      const message = error instanceof Error ? error.message : "スレッド作成に失敗しました";
      alert(message);
    });
  }, [createThread]);

  /** スレッド選択時に呼び出される。選択後は開いていたフィルタパネルを閉じて UI をリセットする。 */
  const handleSelectThread = useCallback(
    (thread: ThreadSummary) => {
      closeFilterPane();
      selectThread(thread).catch((error) => {
        console.error("Failed to select thread", error);
      });
    },
    [closeFilterPane, selectThread]
  );

  /** スレッド削除ボタン押下時の処理。内部では非同期 API を呼び出すため void として fire-and-forget。 */
  const handleDeleteThread = useCallback(
    (threadId: string) => {
      deleteThread(threadId).catch((error) => {
        console.error("Failed to delete thread", error);
      });
    },
    [deleteThread]
  );

  /** Good/Bad バッジ押下時の処理。裏側では `useChatSession` が即時にローカル状態を更新してくれる。 */
  const handleRating = useCallback(
    (messageId: string, rating: "good" | "bad") => {
      rateMessage(messageId, rating).catch((error) => {
        console.error("Failed to rate message", error);
      });
    },
    [rateMessage]
  );

  const handleSetPriority = useCallback(
    (value: string) => {
      setPriority(value);
      closeFilterPane();
    },
    [closeFilterPane, setPriority]
  );

  const handleClearDepartments = useCallback(() => {
    clearDepartments();
    closeFilterPane();
  }, [clearDepartments, closeFilterPane]);

  const handleClearDocumentCategories = useCallback(() => {
    clearDocumentCategories();
    closeFilterPane();
  }, [clearDocumentCategories, closeFilterPane]);

  // ----------------------------------------------------------
  // JSX
  // ----------------------------------------------------------
  // ----------------------------------------------------------
  // JSX: UI 描画
  // ----------------------------------------------------------
  // モーダル表示中は背面のクリックが効かないようにするため、pointer-events を無効化するクラスを付与する。
  const interactionClass = isModalOpen ? "pointer-events-none select-none opacity-60" : "";

  return (
    <>
      <div className={APP_LAYOUT_CLASS}>
        <div className={`flex h-full min-h-0 flex-col ${interactionClass}`} aria-hidden={isModalOpen}>
          {/* シンプルなヘッダ。ロゴ画像は Next/Image で最適化される。 */}
          <header className="flex items-center bg-support-neutral px-2 py-2 text-support-on_right">
            <Image src="/logo.svg" alt="Staff RAG" width={140 * 1.4} height={28 * 1.4} className="h-10 w-auto" />
          </header>

          <div className={CONTENT_LAYOUT_CLASS}>
            <div className="hidden h-full min-h-0 lg:flex">
              {/* サイドバー（スレッド一覧）は PC レイアウトでのみ表示。 */}
              <ThreadList
                threads={threads}
                activeThreadId={activeThreadId}
                maxThreads={maxThreads}
                interactionsDisabled={!threadFeaturesEnabled}
                onSelect={handleSelectThread}
                onCreate={handleCreateThread}
                onDelete={handleDeleteThread}
                onOpenFeedback={() => setModalType("feedback")}
                onOpenPolicy={() => setModalType("policy")}
              />
            </div>

            <main className={MAIN_COLUMN_CLASS}>
              {/* フィルタ群とカテゴリ選択をまとめた上部エリア。PC レイアウトのみ固定表示。 */}
              <header ref={filterBarRef} className={`${HEADER_SECTION_CLASS} hidden lg:block flex-shrink-0`}>
                <CategorySelector
                  filters={filters}
                  options={filterOptions}
                  openPane={openFilterPane}
                  onTogglePane={(pane) => setOpenFilterPane((prev) => (prev === pane ? null : pane))}
                  onToggleDepartment={toggleDepartment}
                  onToggleDocumentCategory={toggleDocumentCategory}
                  onSetPriority={handleSetPriority}
                  onSetAnswerMode={(mode) => {
                    setAnswerMode(mode);
                    closeFilterPane();
                  }}
                  onClearDepartments={handleClearDepartments}
                  onClearDocumentCategories={handleClearDocumentCategories}
                  onResetPriority={() => {
                    resetPriority();
                    closeFilterPane();
                  }}
                />
              </header>

              {filterBadges.length > 0 && (
                /*
                 * いずれかのフィルタが有効な場合のみ、選択済みバッジを表示する。
                 * PC レイアウト限定で表示しており、モバイルの導線改善は別タスクで検討予定。
                 */
                <div className="hidden lg:block flex-shrink-0">
                  <ActiveFilterBadges
                    badges={filterBadges}
                    onRemove={removeFilterBadge}
                  />
                </div>
              )}

              <div className="flex-1 min-h-0 overflow-hidden px-3 pb-0">
                <ChatContainer
                  className="h-full"
                  messages={messages}
                  onRate={handleRating}
                  ref={bottomRef}
                  isLoading={isSending}
                />
              </div>

              {/* 入力ボックスは常に最下段に固定し、スクロールが長くなっても操作導線を維持する。 */}
              <ChatInput value={input} onChange={setInput} onSubmit={handleSend} isSending={isSending} />
            </main>
          </div>
        </div>
      </div>

      {modalType && <SupportModal type={modalType} onClose={closeModal} />}
    </>
  );
}
