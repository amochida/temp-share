import { Buffer } from "buffer";
import { NextRequest, NextResponse } from "next/server";

const FASTAPI_BASE_URL = process.env.FASTAPI_INTERNAL_URL ?? "http://127.0.0.1:8000/api";
const FALLBACK_USER = {
  id: process.env.DEV_USER_ID ?? "guest-user",
  email: process.env.DEV_USER_EMAIL ?? "",
  department: process.env.DEV_USER_DEPARTMENT ?? ""
};
const HOP_HEADERS = new Set(["connection", "keep-alive", "transfer-encoding", "content-length", "accept-encoding"]);

type RouteParams = { path?: string[] };

type Handler = (request: NextRequest, context: { params: RouteParams }) => Promise<NextResponse>;

const handler: Handler = async (request, { params }) => {
  const targetUrl = buildTargetUrl(params?.path, request.nextUrl.searchParams);
  const headers = buildForwardHeaders(request);
  const { body, stripContentType } = await buildRequestBody(request);
  if (stripContentType) {
    headers.delete("content-type");
  }

  const response = await fetch(targetUrl, {
    method: request.method,
    headers,
    body,
    redirect: "manual"
  });

  return await buildProxyResponse(response);
};

export const GET: Handler = handler;
export const POST: Handler = handler;
export const PUT: Handler = handler;
export const PATCH: Handler = handler;
export const DELETE: Handler = handler;
export const OPTIONS: Handler = handler;
export const HEAD: Handler = handler;

function buildTargetUrl(pathSegments: string[] | undefined, searchParams: URLSearchParams): string {
  const normalizedBase = FASTAPI_BASE_URL.replace(/\/+$/, "");
  const pathPart = pathSegments && pathSegments.length > 0 ? `/${pathSegments.join("/")}` : "";
  const searchPart = decodeQueryParams(searchParams);
  return `${normalizedBase}${pathPart}${searchPart}`;
}

function buildForwardHeaders(request: NextRequest): Headers {
  const headers = new Headers();
  request.headers.forEach((value, key) => {
    if (!HOP_HEADERS.has(key.toLowerCase())) {
      headers.set(key, value);
    }
  });
  if (!headers.get("x-user-id")) {
    headers.set("X-User-Id", FALLBACK_USER.id);
  }
  if (!headers.get("x-user-email")) {
    headers.set("X-User-Email", FALLBACK_USER.email);
  }
  if (!headers.get("x-user-department")) {
    headers.set("X-User-Department", FALLBACK_USER.department);
  }
  return headers;
}

async function buildRequestBody(
  request: NextRequest
): Promise<{ body?: BodyInit; stripContentType?: boolean }> {
  const method = request.method.toUpperCase();
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") {
    return {};
  }
  const contentType = request.headers.get("content-type") ?? "";
  if (contentType.includes("multipart/form-data")) {
    const form = await request.formData();
    return { body: cloneFormData(form), stripContentType: true };
  }
  if (contentType.includes("application/x-www-form-urlencoded")) {
    const form = await request.formData();
    if (form.has("p")) {
      const encoded = form.get("p");
      if (typeof encoded === "string") {
        return { body: rebuildUrlEncoded(encoded) };
      }
    }
    const params = new URLSearchParams();
    form.forEach((value, key) => {
      if (typeof value === "string") {
        params.append(key, value);
      }
    });
    return { body: params.toString() };
  }
  if (contentType.includes("application/json")) {
    const text = await request.text();
    if (!text) {
      return { body: "{}" };
    }
    try {
      const parsed = JSON.parse(text) as { p?: string };
      if (parsed && typeof parsed.p === "string") {
        return { body: decodeBase64(parsed.p) };
      }
      return { body: text };
    } catch {
      return { body: text };
    }
  }
  const arrayBuffer = await request.arrayBuffer();
  return arrayBuffer.byteLength ? { body: arrayBuffer } : {};
}

function cloneFormData(source: FormData): FormData {
  const target = new FormData();
  source.forEach((value, key) => {
    if (value instanceof File) {
      target.append(key, value, value.name);
    } else {
      target.append(key, value);
    }
  });
  return target;
}

function decodeQueryParams(searchParams: URLSearchParams): string {
  const encoded = searchParams.get("p");
  if (!encoded) {
    const clone = new URLSearchParams(searchParams);
    clone.delete("p");
    const query = clone.toString();
    return query ? `?${query}` : "";
  }
  try {
    const raw = Buffer.from(decodeURIComponent(encoded), "base64").toString("utf-8");
    const decoded = JSON.parse(raw) as Record<string, string[]>;
    const params = new URLSearchParams();
    Object.entries(decoded).forEach(([key, values]) => {
      values.forEach((value) => params.append(key, value));
    });
    return params.toString() ? `?${params.toString()}` : "";
  } catch {
    return "";
  }
}

function rebuildUrlEncoded(encoded: string): string {
  try {
    const raw = Buffer.from(encoded, "base64").toString("utf-8");
    const decoded = JSON.parse(raw) as Record<string, string | string[]>;
    const params = new URLSearchParams();
    Object.entries(decoded).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        value.forEach((item) => params.append(key, String(item)));
      } else {
        params.append(key, String(value));
      }
    });
    return params.toString();
  } catch {
    return "";
  }
}

function decodeBase64(value: string): string {
  return Buffer.from(value, "base64").toString("utf-8");
}

async function buildProxyResponse(source: Response): Promise<NextResponse> {
  const headers = new Headers();
  source.headers.forEach((value, key) => {
    if (!HOP_HEADERS.has(key.toLowerCase())) {
      headers.set(key, value);
    }
  });
  const contentType = headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const text = await source.text();
    const encoded = Buffer.from(text, "utf-8").toString("base64");
    return NextResponse.json({ p: encoded }, { status: source.status, headers });
  }
  const buffer = await source.arrayBuffer();
  return new NextResponse(buffer, { status: source.status, headers });
}
