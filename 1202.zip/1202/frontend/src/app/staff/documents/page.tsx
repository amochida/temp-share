"use client";

/**
 * スタッフ向けドキュメント管理画面（一覧ページ）。
 * 既存機能は維持しつつ、余白と装飾を最小限に抑えたフラットデザインへ刷新する。
 */
import { useCallback, useMemo, type ChangeEvent } from "react";
import Link from "next/link";
import { createDocumentSearchInitialState, useDocumentSearch } from "@/features/staff/documents/hooks/useDocumentSearch";
import type { DocumentStatus, PublicScope } from "@/shared/types/staff";
import {
  DEPARTMENT_OPTIONS,
  DOCUMENT_TYPE_OPTIONS,
  PUBLIC_SCOPE_OPTIONS,
  DOCUMENT_STATUS_OPTIONS
} from "@/features/staff/constants/options";
import {
  INPUT_BASE_CLASS,
  PRIMARY_BUTTON_CLASS,
  SECONDARY_BUTTON_CLASS,
  SECTION_HEADING_CLASS,
  SUPPORT_TEXT_CLASS
} from "@/shared/styles/classNames";
import SelectableFilterSection, { type FilterOption } from "@/features/staff/components/SelectableFilterSection";
import FilterFormCard from "@/shared/components/FilterFormCard";
import { createValueLabelMap } from "@/shared/utils/options";
import { useInfiniteScroll } from "@/shared/hooks/useInfiniteScroll";

const DOCUMENT_STATUS_LABEL_MAP = createValueLabelMap(DOCUMENT_STATUS_OPTIONS);
const PUBLIC_SCOPE_LABEL_MAP = createValueLabelMap(PUBLIC_SCOPE_OPTIONS);
const DOCUMENT_TYPE_LABEL_MAP = createValueLabelMap(DOCUMENT_TYPE_OPTIONS);

export default function DocumentListPage() {
  const {
    formState,
    setFormState,
    items,
    total,
    loading,
    error,
    handleSubmit,
    loadMore,
    hasMore,
    toggleDepartment,
    toggleDocumentType,
    togglePublicScope,
    toggleStatus,
    clearDepartments,
    clearDocumentTypes,
    clearPublicScopes,
    clearStatuses
  } = useDocumentSearch(); // useDocumentSearch: ドキュメント一覧の絞り込みとページングを担当するカスタムフック

  /**
   * テキストボックスの値を状態へ反映するユーティリティ。
   * - key には `q` または `semantic_query` を渡し、同じ処理を共通化している。
   */
  const handleTextChange = (key: "q" | "semantic_query") =>
    (event: ChangeEvent<HTMLInputElement>) => {
      setFormState((prev) => ({ ...prev, [key]: event.target.value }));
    };
  const statusOptionList: FilterOption[] = useMemo(
    () => DOCUMENT_STATUS_OPTIONS.map(({ value, label }) => ({ value, label })),
    []
  );

  /** フィルタ条件を完全に初期化し、初心者でもリセット手順が分かるようにする。 */
  const resetConditions = () => {
    setFormState(createDocumentSearchInitialState());
  };

  /** IntersectionObserver から呼ばれ、まだ読み込み中でないときだけ次ページを取得する。 */
  const handleLoadMore = useCallback(() => {
    if (!loading) {
      loadMore();
    }
  }, [loadMore, loading]);
  const observerOptions = useMemo(() => ({ rootMargin: "200px" }), []);
  const intersectionRef = useInfiniteScroll(handleLoadMore, observerOptions);

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex-1 overflow-auto">
        <div className="space-y-3 text-sm text-content-tertiary">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className={SECTION_HEADING_CLASS}>ドキュメント管理</h2>
              <p className={SUPPORT_TEXT_CLASS}>新規登録、検索、編集を行います。</p>
            </div>
            <Link href="/staff/documents/new" className={`${PRIMARY_BUTTON_CLASS} inline-flex items-center`}>
              新規ドキュメント登録
            </Link>
          </div>

          <FilterFormCard
            onSubmit={handleSubmit}
            actions={
              <>
                <button
                  type="submit"
                  className={PRIMARY_BUTTON_CLASS}
                  disabled={loading}
                >
                  {loading ? "検索中..." : "検索"}
                </button>
                <button
                  type="button"
                  className={SECONDARY_BUTTON_CLASS}
                  onClick={resetConditions}
                >
                  条件をリセット
                </button>
              </>
            }
          >
            <div className="grid gap-2 md:grid-cols-2">
              <SelectableFilterSection
                title="部門コード"
                options={DEPARTMENT_OPTIONS}
                selected={formState.department_codes}
                onToggle={toggleDepartment}
                onClear={clearDepartments}
                className="md:col-span-2"
              />

              <SelectableFilterSection
                title="ドキュメント種別"
                options={DOCUMENT_TYPE_OPTIONS}
                selected={formState.document_types}
                onToggle={toggleDocumentType}
                onClear={clearDocumentTypes}
                className="md:col-span-2"
              />

              <SelectableFilterSection
                title="公開範囲"
                options={PUBLIC_SCOPE_OPTIONS}
                selected={formState.public_scopes}
                onToggle={(value) => togglePublicScope(value as PublicScope)}
                onClear={clearPublicScopes}
                className="md:col-span-2"
              />

              <SelectableFilterSection
                title="ステータス"
                options={statusOptionList}
                selected={formState.statuses}
                onToggle={(value) => toggleStatus(value as DocumentStatus)}
                onClear={clearStatuses}
                className="md:col-span-2"
              />

          <div className="flex flex-col space-y-1">
            <label className="font-semibold">テキスト検索</label>
            <input
              className={INPUT_BASE_CLASS}
              value={formState.q}
              onChange={handleTextChange("q")}
              placeholder="タイトル・URIから一致検索"
            />
          </div>

          <div className="flex flex-col space-y-1 md:col-span-2">
            <label className="font-semibold">意味検索キーワード</label>
            <input
              className={INPUT_BASE_CLASS}
              value={formState.semantic_query}
              onChange={handleTextChange("semantic_query")}
              placeholder="例: 休暇申請の提出期限"
            />
            <p className={SUPPORT_TEXT_CLASS}>
              テキスト検索と意味検索の両方を指定すると結果を統合して表示します。
            </p>
          </div>
        </div>
          </FilterFormCard>

      {error && <p className="bg-red-100 px-2 py-2 text-sm text-red-700">{error}</p>}

      <div className="overflow-x-auto bg-surface-panel border border-surface-border rounded-lg">
        <div className="flex items-center justify-between px-3 py-2 text-xs text-content-subtle">
          <span>合計 {total} 件</span>
        </div>
        <table className="min-w-full text-left text-sm text-content-tertiary">
          <thead className="bg-surface-muted text-content-tertiary">
            <tr>
              <th className="px-3 py-2">タイトル</th>
              <th className="px-3 py-2">種別</th>
              <th className="px-3 py-2">部門</th>
              <th className="px-3 py-2">公開範囲</th>
              <th className="px-3 py-2">ステータス</th>
              <th className="px-3 py-2">更新日時</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={item.id} className={index % 2 === 0 ? "bg-surface-panel" : "bg-surface-muted"}>
                <td className="px-3 py-2">
                  <Link
                    href={`/staff/documents/${item.id}`}
                    className="font-semibold text-brand-primary hover:underline"
                  >
                    {item.title}
                  </Link>
                </td>
                <td className="px-3 py-2">{item.type ? DOCUMENT_TYPE_LABEL_MAP[item.type] ?? item.type : "-"}</td>
                <td className="px-3 py-3">{item.department_code ?? "-"}</td>
                <td className="px-3 py-3">{item.public_scope ? PUBLIC_SCOPE_LABEL_MAP[item.public_scope] ?? item.public_scope : "-"}</td>
                <td className="px-3 py-3 text-content-secondary">
                  {item.status ? DOCUMENT_STATUS_LABEL_MAP[item.status] ?? item.status : "-"}
                </td>
                <td className="px-3 py-3 text-content-subtle">{new Date(item.updated_at).toLocaleString()}</td>
              </tr>
            ))}
            {!items.length && !loading && (
              <tr>
                <td colSpan={6} className="px-3 py-6 text-center text-content-subtle">
                  条件に一致するドキュメントがありません。
                </td>
              </tr>
            )}
          </tbody>
        </table>
        {loading && (
          <p className="px-3 py-2 text-xs text-content-subtle">読み込み中...</p>
        )}
      </div>

      {hasMore && <div ref={intersectionRef} className="h-6" />}
    </div>
  </div>
</div>
  );
}
