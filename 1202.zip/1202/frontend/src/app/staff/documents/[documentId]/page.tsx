"use client";

/**
 * ドキュメント詳細の閲覧・更新・削除ページ。フラットな配色へ刷新する。
 */
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { deleteDocument, fetchDocument, updateDocument } from "@/features/staff/documents/api/documentsApi";
import type { DocumentRecord, DocumentStatus, PublicScope, RegistrationType } from "@/shared/types/staff";
import {
  DEPARTMENT_OPTIONS,
  DOCUMENT_TYPE_OPTIONS,
  PUBLIC_SCOPE_OPTIONS,
  DOCUMENT_STATUS_OPTIONS
} from "@/features/staff/constants/options";
import {
  INPUT_BASE_CLASS,
  PRIMARY_BUTTON_CLASS,
  SECONDARY_BUTTON_CLASS,
  TERTIARY_TEXT_BUTTON_CLASS,
  SECTION_HEADING_CLASS,
  SUPPORT_TEXT_CLASS
} from "@/shared/styles/classNames";
import { createValueLabelMap } from "@/shared/utils/options";

interface PageProps {
  params: { documentId: string };
}

const REGISTRATION_OPTIONS: RegistrationType[] = ["manual", "auto"];
const STATUS_FALLBACK: DocumentStatus = "ready";
const SCOPE_FALLBACK: PublicScope = "internal";
const DOCUMENT_TYPE_LABEL_MAP = createValueLabelMap(DOCUMENT_TYPE_OPTIONS);

function findDocumentTypeLabel(value?: string | null): string | null {
  if (!value) return null;
  return DOCUMENT_TYPE_LABEL_MAP[value] ?? null;
}

function resolveDocumentTypeValue(valueOrLabel?: string | null): string {
  if (!valueOrLabel) return "";
  if (DOCUMENT_TYPE_LABEL_MAP[valueOrLabel]) {
    return valueOrLabel;
  }
  const matched = DOCUMENT_TYPE_OPTIONS.find((option) => option.label === valueOrLabel);
  return matched?.value ?? "";
}

export default function DocumentDetailPage({ params }: PageProps) {
  const router = useRouter();
  const [record, setRecord] = useState<DocumentRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [form, setForm] = useState({
    title: "",
    department_code: "",
    document_type: "",
    registration_type: "manual" as RegistrationType,
    is_auto_import_target: false,
    source_uri: "",
    public_scope: SCOPE_FALLBACK,
    status: STATUS_FALLBACK
  });

  useEffect(() => {
    const bootstrap = async () => {
      setLoading(true);
      setError(null);
      try {
        const doc = await fetchDocument(params.documentId);
        setRecord(doc);
        setForm({
          title: doc.title,
          department_code: doc.department_code ?? "",
          document_type: resolveDocumentTypeValue(doc.type),
          registration_type: doc.registration_type,
          is_auto_import_target: doc.is_auto_import_target,
          source_uri: doc.source_uri ?? "",
          public_scope: doc.public_scope,
          status: doc.status
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : "詳細を取得できませんでした");
      } finally {
        setLoading(false);
      }
    };
    bootstrap();
  }, [params.documentId]);

  const handleChange = <K extends keyof typeof form>(key: K, value: typeof form[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      const documentTypeLabel = findDocumentTypeLabel(form.document_type);
      const payload = {
        title: form.title,
        department_code: form.department_code || null,
        document_type: documentTypeLabel ?? null,
        registration_type: form.registration_type,
        is_auto_import_target: form.is_auto_import_target,
        source_uri: form.source_uri || null,
        public_scope: form.public_scope,
        status: form.status
      };
      const updated = await updateDocument(params.documentId, payload, selectedFile ?? undefined);
      setRecord(updated);
      setForm({
        title: updated.title,
        department_code: updated.department_code ?? "",
        document_type: resolveDocumentTypeValue(updated.type),
        registration_type: updated.registration_type,
        is_auto_import_target: updated.is_auto_import_target,
        source_uri: updated.source_uri ?? "",
        public_scope: updated.public_scope,
        status: updated.status
      });
      setSelectedFile(null);
      setMessage("更新しました");
      if (selectedFile && updated.id !== params.documentId) {
        router.replace(`/staff/documents/${updated.id}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "更新に失敗しました");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("このドキュメントを削除しますか？")) {
      return;
    }
    try {
      await deleteDocument(params.documentId);
      router.push("/staff/documents");
    } catch (err) {
      setError(err instanceof Error ? err.message : "削除に失敗しました");
    }
  };

  const updatedAt = useMemo(() => (record ? new Date(record.updated_at).toLocaleString() : ""), [record]);

  if (loading) {
    return <p className={SUPPORT_TEXT_CLASS}>読み込み中...</p>;
  }

  if (!record) {
    return <p className="text-sm text-red-600">ドキュメントが見つかりませんでした。</p>;
  }

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex-1 overflow-auto">
        <div className="space-y-3 text-sm text-content-tertiary">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className={SECTION_HEADING_CLASS}>{record.title}</h2>
              <p className={SUPPORT_TEXT_CLASS}>最終更新: {updatedAt}</p>
            </div>
            <button
              type="button"
              onClick={handleDelete}
              className="bg-red-100 px-3 py-1 text-sm font-semibold text-red-600 hover:text-brand-accent rounded-lg"
            >
              削除
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-2 bg-surface-panel px-3 py-3 border border-surface-border rounded-lg">
            <div className="grid gap-2 md:grid-cols-2">
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">タイトル *</label>
                <input
                  required
                  className={INPUT_BASE_CLASS}
                  value={form.title}
                  onChange={(event) => handleChange("title", event.target.value)}
                />
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">部門コード</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.department_code ?? ""}
                  onChange={(event) => handleChange("department_code", event.target.value)}
                >
                  <option value="">未選択</option>
                  {DEPARTMENT_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">ドキュメント種別</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.document_type ?? ""}
                  onChange={(event) => handleChange("document_type", event.target.value)}
                >
                  <option value="">未選択</option>
                  {DOCUMENT_TYPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">登録区分</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.registration_type}
                  onChange={(event) => handleChange("registration_type", event.target.value as RegistrationType)}
                >
                  {REGISTRATION_OPTIONS.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2 md:col-span-2">
                <input
                  id="auto-import"
                  type="checkbox"
                  className="accent-brand-primary"
                  checked={form.is_auto_import_target}
                  onChange={(event) => handleChange("is_auto_import_target", event.target.checked)}
                />
                <label htmlFor="auto-import" className="text-sm text-content-tertiary">
                  自動インポート対象に設定する
                </label>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">原本URL</label>
                <input
                  className={INPUT_BASE_CLASS}
                  value={form.source_uri ?? ""}
                  onChange={(event) => handleChange("source_uri", event.target.value)}
                />
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">公開範囲</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.public_scope ?? SCOPE_FALLBACK}
                  onChange={(event) => handleChange("public_scope", event.target.value as PublicScope)}
                >
                  {PUBLIC_SCOPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">ステータス</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.status ?? STATUS_FALLBACK}
                  onChange={(event) => handleChange("status", event.target.value as DocumentStatus)}
                >
                  {DOCUMENT_STATUS_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1 md:col-span-2">
                <label className="font-semibold">ドキュメントファイル</label>
                <input
                  type="file"
                  accept=".pdf,.txt,.md,.docx,.pptx"
                  className="text-sm"
                  onChange={(event) => setSelectedFile(event.target.files?.[0] ?? null)}
                />
                <p className={SUPPORT_TEXT_CLASS}>
                  新しいファイルを選択すると既存ファイルを差し替えます。未選択の場合は現状を維持します。
                </p>
                {selectedFile ? (
                  <p className="text-xs text-content-subtle">選択中: {selectedFile.name}</p>
                ) : null}
              </div>
            </div>

            {error && <p className="bg-red-100 px-2 py-2 text-sm text-red-700">{error}</p>}
            {message && <p className="bg-emerald-100 px-2 py-2 text-sm text-emerald-700">{message}</p>}

            <div className="flex items-center gap-2">
              <button
                type="submit"
                className={PRIMARY_BUTTON_CLASS}
                disabled={saving}
              >
                {saving ? "保存中..." : "保存"}
              </button>
              <button
                type="button"
                className={SECONDARY_BUTTON_CLASS}
                onClick={() => router.push("/staff/documents")}
              >
                一覧へ戻る
              </button>
            </div>
          </form>

        </div>
      </div>
    </div>
  );
}
