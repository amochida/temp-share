"use client";

/**
 * ドキュメント新規登録フォーム。装飾を最小限にしたフラットなレイアウトへ更新する。
 */
import { DEPARTMENT_OPTIONS, DOCUMENT_TYPE_OPTIONS, PUBLIC_SCOPE_OPTIONS } from "@/features/staff/constants/options";
import { createDocument } from "@/features/staff/documents/api/documentsApi";
import {
  INPUT_BASE_CLASS,
  PRIMARY_BUTTON_CLASS,
  SECONDARY_BUTTON_CLASS,
  SECTION_HEADING_CLASS,
  SUPPORT_TEXT_CLASS
} from "@/shared/styles/classNames";
import type { PublicScope, RegistrationType } from "@/shared/types/staff";
import { useRouter } from "next/navigation";
import { useState } from "react";

const REGISTRATION_OPTIONS: RegistrationType[] = ["manual", "auto"];
const SCOPE_FALLBACK: PublicScope = "internal";

function findDocumentTypeLabel(value?: string | null): string | null {
  if (!value) return null;
  const option = DOCUMENT_TYPE_OPTIONS.find((item) => item.value === value);
  return option?.label ?? null;
}

export default function DocumentCreatePage() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [departmentCode, setDepartmentCode] = useState("");
  const [documentType, setDocumentType] = useState("");
  const [registrationType, setRegistrationType] = useState<RegistrationType>("manual");
  const [isAutoImport, setIsAutoImport] = useState(false);
  const [sourceUri, setSourceUri] = useState("");
  const [publicScope, setPublicScope] = useState<PublicScope>(SCOPE_FALLBACK);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (!file) {
      setError("ファイルを選択してください");
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("title", title);
      if (departmentCode) formData.append("department_code", departmentCode);
      const documentTypeLabel = findDocumentTypeLabel(documentType);
      if (documentTypeLabel) formData.append("document_type", documentTypeLabel);
      formData.append("registration_type", registrationType);
      formData.append("is_auto_import_target", String(isAutoImport));
      if (sourceUri) formData.append("source_uri", sourceUri);
      formData.append("public_scope", publicScope);
      formData.append("file", file);

      const response = await createDocument(formData);
      setSuccess("ドキュメントを登録しました");
      setTimeout(() => {
        router.push(`/staff/documents/${response.document_id}`);
      }, 800);
    } catch (err) {
      setError(err instanceof Error ? err.message : "登録に失敗しました");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex-1 overflow-auto">
        <div className="space-y-3 text-sm text-content-tertiary">
          <div className="flex items-center justify-between text-sm">
            <h2 className={SECTION_HEADING_CLASS}>新規ドキュメント登録</h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-2 bg-surface-panel px-3 py-3 border border-surface-border rounded-lg">
            <div className="grid gap-2 md:grid-cols-2">
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">タイトル *</label>
                <input
                  required
                  className={INPUT_BASE_CLASS}
                  value={title}
                  onChange={(event) => setTitle(event.target.value)}
                />
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">部門コード</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={departmentCode}
                  onChange={(event) => setDepartmentCode(event.target.value)}
                >
                  <option value="">未選択</option>
                  {DEPARTMENT_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">ドキュメント種別</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={documentType}
                  onChange={(event) => setDocumentType(event.target.value)}
                >
                  <option value="">未選択</option>
                  {DOCUMENT_TYPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">登録区分</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={registrationType}
                  onChange={(event) => setRegistrationType(event.target.value as RegistrationType)}
                >
                  {REGISTRATION_OPTIONS.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2 md:col-span-2">
                <input
                  id="auto-import"
                  type="checkbox"
                  className="accent-brand-primary"
                  checked={isAutoImport}
                  onChange={(event) => setIsAutoImport(event.target.checked)}
                />
                <label htmlFor="auto-import" className="text-sm text-content-tertiary">
                  自動インポート対象に設定する
                </label>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">原本URL</label>
                <input
                  className={INPUT_BASE_CLASS}
                  value={sourceUri}
                  onChange={(event) => setSourceUri(event.target.value)}
                />
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">公開範囲</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={publicScope}
                  onChange={(event) => setPublicScope(event.target.value as PublicScope)}
                >
                  {PUBLIC_SCOPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1 md:col-span-2">
                <label className="font-semibold">ドキュメントファイル *</label>
                <input
                  required
                  type="file"
                  accept=".pdf,.txt,.xlsx,.docx,.pptx"
                  className="text-sm"
                  onChange={(event) => setFile(event.target.files?.[0] ?? null)}
                />
                <p className={SUPPORT_TEXT_CLASS}>PDF / TXT / Word(.docx) / Excel(.xlsx) / PPT(.pptx)に対応しています。</p>
              </div>
            </div>

            {error && <p className="bg-red-100 px-2 py-2 text-sm text-red-700">{error}</p>}
            {success && <p className="bg-emerald-100 px-2 py-2 text-sm text-emerald-700">{success}</p>}

            <div className="flex items-center gap-2">
              <button
                type="submit"
                className={PRIMARY_BUTTON_CLASS}
                disabled={submitting}
              >
                {submitting ? "登録中..." : "登録"}
              </button>
              <button
                type="button"
                className={SECONDARY_BUTTON_CLASS}
                onClick={() => router.back()}
              >
                キャンセル
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
