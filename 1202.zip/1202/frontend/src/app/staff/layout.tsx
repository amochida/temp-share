import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";

/** スタッフ向けページ共通レイアウト。ヘッダーとナビゲーションを提供する。 */
export default function StaffLayout({ children }: { children: ReactNode }) {
  return (
    <div className="grid min-h-screen w-screen grid-rows-[auto_1fr] bg-surface-page text-content-primary">
      <header className="border-b border-support-main/30 bg-support-neutral px-4 py-3 text-sm text-support-on_right">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Image src="/logo.svg" alt="Staff RAG" width={196} height={40} className="h-9 w-auto" />
            <div className="leading-tight">
              <h1 className="text-base font-semibold text-support-on_right">スタッフポータル</h1>
              <p className="text-xs text-support-on_right/80">ドキュメントとFAQの登録・保守を行います。</p>
            </div>
          </div>
          <nav className="flex flex-wrap items-center gap-2 text-sm font-medium">
            <Link
              href="/staff/documents"
              className="rounded-full px-3 py-1 text-support-on_right transition-colors hover:bg-support-main/30 hover:text-brand-primary"
            >
              ドキュメント管理
            </Link>
            <Link
              href="/staff/faqs"
              className="rounded-full px-3 py-1 text-support-on_right transition-colors hover:bg-support-main/30 hover:text-brand-primary"
            >
              FAQ管理
            </Link>
            <Link
              href="/"
              className="rounded-full px-3 py-1 text-support-on_right transition-colors hover:bg-support-main/30 hover:text-brand-accent"
            >
              チャットへ戻る
            </Link>
          </nav>
        </div>
      </header>
      <main className="overflow-hidden px-3 py-3">
        <div className="h-full overflow-auto">{children}</div>
      </main>
    </div>
  );
}
