import Link from "next/link";

/** スタッフポータルのトップページ。メニュータイルを表示する。 */
export default function StaffHomePage() {
  const tiles = [
    {
      href: "/staff/documents",
      title: "ドキュメント管理",
      description: "社内ドキュメントの登録・検索・編集・削除を行います。"
    },
    {
      href: "/staff/faqs",
      title: "FAQ管理",
      description: "FAQの登録・検索・改善を行います。"
    }
  ];

  return (
    <section className="grid gap-2 md:grid-cols-2">
      {tiles.map((tile) => (
        <Link
          key={tile.href}
          href={tile.href}
          className="bg-surface-panel px-3 py-3 text-sm text-content-tertiary transition-colors hover:bg-brand-primary/5 hover:text-brand-primary rounded-lg"
        >
          <h2 className="text-base font-semibold text-content-secondary">{tile.title}</h2>
          <p className="mt-1 text-sm text-content-subtle">{tile.description}</p>
        </Link>
      ))}
    </section>
  );
}
