"use client";

/**
 * スタッフ向け FAQ 管理画面。フラットな配色にリデザインする。
 */
import { useCallback, useMemo, type ChangeEvent } from "react";
import Link from "next/link";
import { createFaqSearchInitialState, useFaqSearch } from "@/features/staff/faqs/hooks/useFaqSearch";
import type { FAQScope, FAQStatus } from "@/shared/types/staff";
import {
  DEPARTMENT_OPTIONS,
  FAQ_CATEGORY_OPTIONS,
  FAQ_TYPE_OPTIONS,
  PUBLIC_SCOPE_OPTIONS,
  FAQ_STATUS_OPTIONS
} from "@/features/staff/constants/options";
import {
  INPUT_BASE_CLASS,
  PRIMARY_BUTTON_CLASS,
  SECONDARY_BUTTON_CLASS,
  SECTION_HEADING_CLASS,
  SUPPORT_TEXT_CLASS
} from "@/shared/styles/classNames";
import SelectableFilterSection, { type FilterOption } from "@/features/staff/components/SelectableFilterSection";
import FilterFormCard from "@/shared/components/FilterFormCard";
import { createValueLabelMap } from "@/shared/utils/options";
import { useInfiniteScroll } from "@/shared/hooks/useInfiniteScroll";

const FAQ_STATUS_LABEL_MAP = createValueLabelMap(FAQ_STATUS_OPTIONS);
const FAQ_SCOPE_LABEL_MAP = createValueLabelMap(PUBLIC_SCOPE_OPTIONS);
const FAQ_CATEGORY_LABEL_MAP = createValueLabelMap(FAQ_CATEGORY_OPTIONS);

export default function FAQListPage() {
  const {
    formState,
    setFormState,
    items,
    total,
    loading,
    error,
    handleSubmit,
    loadMore,
    hasMore,
    toggleDepartment,
    toggleCategory,
    toggleFaqType,
    togglePublicScope,
    toggleStatus,
    clearDepartments,
    clearCategories,
    clearFaqTypes,
    clearPublicScopes,
    clearStatuses
  } = useFaqSearch(); // useFaqSearch: FAQ 一覧の検索条件とページングを一元管理するカスタムフック

  /** FAQ画面のテキスト入力を共通処理で反映する関数。 */
  const handleTextChange = (key: "q" | "semantic_query") =>
    (event: ChangeEvent<HTMLInputElement>) => {
      setFormState((prev) => ({ ...prev, [key]: event.target.value }));
    };

  const statusOptionList: FilterOption[] = useMemo(
    () => FAQ_STATUS_OPTIONS.map(({ value, label }) => ({ value, label })),
    []
  );

  /** すべてのチェックボックスと検索文字列を初期状態へ戻す。 */
  const resetConditions = () => {
    setFormState(createFaqSearchInitialState());
  };

  /** 無限スクロールの監視対象が可視になったときに追加ロードする。 */
  const handleLoadMore = useCallback(() => {
    if (!loading) {
      loadMore();
    }
  }, [loadMore, loading]);
  const observerOptions = useMemo(() => ({ rootMargin: "200px" }), []);
  const intersectionRef = useInfiniteScroll(handleLoadMore, observerOptions);

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex-1 overflow-auto">
        <div className="space-y-3 text-sm text-content-tertiary">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className={SECTION_HEADING_CLASS}>FAQ管理</h2>
              <p className={SUPPORT_TEXT_CLASS}>FAQの登録・検索・編集を行います。</p>
            </div>
            <Link
              href="/staff/faqs/new"
              className={`${PRIMARY_BUTTON_CLASS} inline-flex items-center`}
            >
              新規FAQ登録
            </Link>
          </div>

          <FilterFormCard
            onSubmit={handleSubmit}
            actions={
              <>
                <button
                  type="submit"
                  className={PRIMARY_BUTTON_CLASS}
                  disabled={loading}
                >
                  {loading ? "検索中..." : "検索"}
                </button>
                <button
                  type="button"
                  className={SECONDARY_BUTTON_CLASS}
                  onClick={resetConditions}
                >
                  条件をリセット
                </button>
              </>
            }
          >
            <div className="grid gap-2 md:grid-cols-2">
              <SelectableFilterSection
                title="部門コード"
                options={DEPARTMENT_OPTIONS}
                selected={formState.department_codes}
                onToggle={toggleDepartment}
                onClear={clearDepartments}
                className="md:col-span-2"
              />

              <SelectableFilterSection
                title="公開範囲"
                options={PUBLIC_SCOPE_OPTIONS}
                selected={formState.public_scopes}
                onToggle={(value) => togglePublicScope(value as FAQScope)}
                onClear={clearPublicScopes}
                className="md:col-span-2"
              />

              <SelectableFilterSection
                title="カテゴリ"
                options={FAQ_CATEGORY_OPTIONS}
                selected={formState.categories}
                onToggle={toggleCategory}
                onClear={clearCategories}
                className="md:col-span-2"
              />

              <SelectableFilterSection
                title="FAQ種別"
                options={FAQ_TYPE_OPTIONS}
                selected={formState.faq_types}
                onToggle={toggleFaqType}
                onClear={clearFaqTypes}
                className="md:col-span-2"
              />

              <SelectableFilterSection
                title="ステータス"
                options={statusOptionList}
                selected={formState.statuses}
                onToggle={(value) => toggleStatus(value as FAQStatus)}
                onClear={clearStatuses}
                className="md:col-span-2"
              />

              <div className="flex flex-col space-y-1">
                <label className="font-semibold">テキスト検索</label>
                <input
                  className={INPUT_BASE_CLASS}
                  value={formState.q}
                  onChange={handleTextChange("q")}
                  placeholder="質問・回答文から検索"
                />
              </div>

              <div className="flex flex-col space-y-1 md:col-span-2">
                <label className="font-semibold">意味検索キーワード</label>
                <input
                  className={INPUT_BASE_CLASS}
                  value={formState.semantic_query}
                  onChange={handleTextChange("semantic_query")}
                  placeholder="例: 休日出勤の申請先"
                />
            <p className={SUPPORT_TEXT_CLASS}>キーワードを指定すると意味検索の対象に加えられます。</p>
              </div>
            </div>
          </FilterFormCard>

          {error && <p className="bg-red-100 px-2 py-2 text-sm text-red-700">{error}</p>}

          <div className="overflow-x-auto bg-surface-panel border border-surface-border rounded-lg">
            <div className="flex items-center justify-between px-3 py-2 text-xs text-content-subtle">
              <span>合計 {total} 件</span>
            </div>
            <table className="min-w-full text-left text-sm text-content-tertiary">
              <thead className="bg-surface-muted text-content-tertiary">
                <tr>
                  <th className="px-3 py-2">質問</th>
                  <th className="px-3 py-2">カテゴリ</th>
                  <th className="px-3 py-2">部門</th>
                  <th className="px-3 py-2">公開範囲</th>
                  <th className="px-3 py-2">ステータス</th>
                  <th className="px-3 py-2">更新日時</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={item.id} className={index % 2 === 0 ? "bg-surface-panel" : "bg-surface-muted"}>
                    <td className="px-3 py-2">
                      <Link
                        href={`/staff/faqs/${item.id}`}
                        className="font-semibold text-brand-primary hover:underline"
                      >
                        {item.question}
                      </Link>
                    </td>
                    <td className="px-3 py-3">{item.category ? FAQ_CATEGORY_LABEL_MAP[item.category] ?? item.category : "-"}</td>
                    <td className="px-3 py-3">{item.department_code ?? "-"}</td>
                    <td className="px-3 py-3">{item.public_scope ? FAQ_SCOPE_LABEL_MAP[item.public_scope] ?? item.public_scope : "-"}</td>
                    <td className="px-3 py-3 text-content-secondary">
                      {item.status ? FAQ_STATUS_LABEL_MAP[item.status] ?? item.status : "-"}
                    </td>
                    <td className="px-3 py-3 text-content-subtle">{new Date(item.updated_at).toLocaleString()}</td>
                  </tr>
                 ))}
                {!items.length && !loading && (
                  <tr>
                    <td colSpan={6} className="px-3 py-6 text-center text-content-subtle">
                      条件に一致するFAQがありません。
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {loading && <p className="px-3 py-2 text-xs text-content-subtle">読み込み中...</p>}
          </div>

          {hasMore && <div ref={intersectionRef} className="h-6" />}
        </div>
      </div>
    </div>
  );
}
