"use client";

/**
 * FAQ 詳細ページ。装飾を抑えたフラットデザインへ更新する。
 */
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { deleteFaq, fetchFaq, updateFaq } from "@/features/staff/faqs/api/faqsApi";
import type { FAQPayload, FAQRecord, FAQScope, FAQStatus } from "@/shared/types/staff";
import {
  DEPARTMENT_OPTIONS,
  FAQ_CATEGORY_OPTIONS,
  FAQ_TYPE_OPTIONS,
  PUBLIC_SCOPE_OPTIONS,
  FAQ_STATUS_OPTIONS
} from "@/features/staff/constants/options";
import {
  INPUT_BASE_CLASS,
  PRIMARY_BUTTON_CLASS,
  SECONDARY_BUTTON_CLASS,
  SECTION_HEADING_CLASS,
  SUPPORT_TEXT_CLASS
} from "@/shared/styles/classNames";

interface PageProps {
  params: { faqId: string };
}

const STATUS_FALLBACK: FAQStatus = "draft";
const SCOPE_FALLBACK: FAQScope = "internal";

export default function FAQDetailPage({ params }: PageProps) {
  const router = useRouter();
  const [record, setRecord] = useState<FAQRecord | null>(null);
  const [form, setForm] = useState<FAQPayload>({
    question: "",
    answer: "",
    department_code: "",
    category: "",
    faq_type: "",
    summary: "",
    public_scope: SCOPE_FALLBACK,
    status: STATUS_FALLBACK
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const bootstrap = async () => {
      setLoading(true);
      setError(null);
      try {
        const faq = await fetchFaq(params.faqId);
        setRecord(faq);
        setForm({
          question: faq.question,
          answer: faq.answer,
          department_code: faq.department_code ?? "",
          category: faq.category ?? "",
          faq_type: faq.type ?? "",
          summary: faq.summary ?? "",
          public_scope: faq.public_scope,
          status: faq.status
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : "詳細を取得できませんでした");
      } finally {
        setLoading(false);
      }
    };
    bootstrap();
  }, [params.faqId]);

  const handleChange = <K extends keyof FAQPayload>(key: K, value: FAQPayload[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      const payload: FAQPayload = {
        ...form,
        department_code: form.department_code || undefined,
        category: form.category || undefined,
        faq_type: form.faq_type || undefined,
        summary: form.summary || undefined
      };
      const updated = await updateFaq(params.faqId, payload);
      setRecord(updated);
      setMessage("更新しました");
    } catch (err) {
      setError(err instanceof Error ? err.message : "更新に失敗しました");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("このFAQを削除しますか？")) {
      return;
    }
    try {
      await deleteFaq(params.faqId);
      router.push("/staff/faqs");
    } catch (err) {
      setError(err instanceof Error ? err.message : "削除に失敗しました");
    }
  };

  const updatedAt = useMemo(() => (record ? new Date(record.updated_at).toLocaleString() : ""), [record]);

  if (loading) {
    return <p className="text-sm text-content-subtle">読み込み中...</p>;
  }

  if (!record) {
    return <p className="text-sm text-red-600">FAQが見つかりませんでした。</p>;
  }

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex-1 overflow-auto">
        <div className="space-y-3 text-sm text-content-tertiary">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className={SECTION_HEADING_CLASS}>FAQ詳細</h2>
              <p className="text-sm text-content-subtle">最終更新: {updatedAt}</p>
            </div>
            <button
              type="button"
              onClick={handleDelete}
              className="bg-red-100 px-3 py-1 text-sm font-semibold text-red-600 hover:text-brand-accent rounded-lg"
            >
              削除
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-2 bg-surface-panel px-3 py-3 border border-surface-border rounded-lg">
            <div className="flex flex-col space-y-1">
              <label className="font-semibold">質問 *</label>
              <textarea
                required
                className={`min-h-[80px] ${INPUT_BASE_CLASS}`}
                value={form.question}
                onChange={(event) => handleChange("question", event.target.value)}
              />
            </div>
            <div className="flex flex-col space-y-1">
              <label className="font-semibold">回答 *</label>
              <textarea
                required
                className={`min-h-[120px] ${INPUT_BASE_CLASS}`}
                value={form.answer}
                onChange={(event) => handleChange("answer", event.target.value)}
              />
            </div>
            <div className="grid gap-2 md:grid-cols-2">
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">部門コード</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.department_code ?? ""}
                  onChange={(event) => handleChange("department_code", event.target.value)}
                >
                  <option value="">未選択</option>
                  {DEPARTMENT_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">カテゴリ</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.category ?? ""}
                  onChange={(event) => handleChange("category", event.target.value)}
                >
                  <option value="">未選択</option>
                  {FAQ_CATEGORY_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">FAQ種別</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.faq_type ?? ""}
                  onChange={(event) => handleChange("faq_type", event.target.value)}
                >
                  <option value="">未選択</option>
                  {FAQ_TYPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">要約</label>
                <textarea
                  className={`min-h-[60px] ${INPUT_BASE_CLASS}`}
                  value={form.summary ?? ""}
                  onChange={(event) => handleChange("summary", event.target.value)}
                />
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">公開範囲</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.public_scope ?? SCOPE_FALLBACK}
                  onChange={(event) => handleChange("public_scope", event.target.value as FAQScope)}
                >
                  {PUBLIC_SCOPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">ステータス</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={form.status ?? STATUS_FALLBACK}
                  onChange={(event) => handleChange("status", event.target.value as FAQStatus)}
                >
                  {FAQ_STATUS_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {error && <p className="bg-red-100 px-2 py-2 text-sm text-red-700">{error}</p>}
            {message && <p className="bg-emerald-100 px-2 py-2 text-sm text-emerald-700">{message}</p>}

            <div className="flex items-center gap-2">
              <button
                type="submit"
                className={PRIMARY_BUTTON_CLASS}
                disabled={saving}
              >
                {saving ? "保存中..." : "保存"}
              </button>
              <button
                type="button"
                className="bg-surface-muted px-3 py-1 text-sm text-content-tertiary hover:text-brand-primary rounded-lg"
                onClick={() => router.push("/staff/faqs")}
              >
                一覧へ戻る
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
