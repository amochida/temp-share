"use client";

/**
 * FAQ 新規登録フォーム。余白と装飾を抑えたフラットなスタイルへ更新する。
 */
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createFaq } from "@/features/staff/faqs/api/faqsApi";
import type { FAQPayload, FAQScope, FAQStatus } from "@/shared/types/staff";
import {
  DEPARTMENT_OPTIONS,
  FAQ_CATEGORY_OPTIONS,
  FAQ_TYPE_OPTIONS,
  PUBLIC_SCOPE_OPTIONS,
  FAQ_STATUS_OPTIONS
} from "@/features/staff/constants/options";
import {
  INPUT_BASE_CLASS,
  PRIMARY_BUTTON_CLASS,
  SECONDARY_BUTTON_CLASS,
  SECTION_HEADING_CLASS,
  SUPPORT_TEXT_CLASS
} from "@/shared/styles/classNames";

const STATUS_FALLBACK: FAQStatus = "draft";
const SCOPE_FALLBACK: FAQScope = "internal";

const INITIAL_PAYLOAD: FAQPayload = {
  question: "",
  answer: "",
  department_code: "",
  category: "",
  faq_type: "",
  summary: "",
  public_scope: SCOPE_FALLBACK,
  status: STATUS_FALLBACK
};

export default function FAQCreatePage() {
  const router = useRouter();
  const [payload, setPayload] = useState<FAQPayload>({ ...INITIAL_PAYLOAD });
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleChange = <K extends keyof FAQPayload>(key: K, value: FAQPayload[K]) => {
    setPayload((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);
    setSubmitting(true);
    try {
      const response = await createFaq({
        ...payload,
        department_code: payload.department_code || undefined,
        category: payload.category || undefined,
        faq_type: payload.faq_type || undefined,
        summary: payload.summary || undefined
      });
      setSuccess("FAQを登録しました");
      setTimeout(() => {
        router.push(`/staff/faqs/${response.faq_id}`);
      }, 800);
    } catch (err) {
      setError(err instanceof Error ? err.message : "登録に失敗しました");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex-1 overflow-auto">
        <div className="space-y-3 text-sm text-content-tertiary">
          <div className="flex items-center justify-between">
            <h2 className={SECTION_HEADING_CLASS}>新規FAQ登録</h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-2 bg-surface-panel px-3 py-3 border border-surface-border rounded-lg">
            <div className="flex flex-col space-y-1">
              <label className="font-semibold">質問 *</label>
              <textarea
                required
                className={`min-h-[80px] ${INPUT_BASE_CLASS}`}
                value={payload.question}
                onChange={(event) => handleChange("question", event.target.value)}
              />
            </div>
            <div className="flex flex-col space-y-1">
              <label className="font-semibold">回答 *</label>
              <textarea
                required
                className={`min-h-[120px] ${INPUT_BASE_CLASS}`}
                value={payload.answer}
                onChange={(event) => handleChange("answer", event.target.value)}
              />
            </div>
            <div className="grid gap-2 md:grid-cols-2">
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">部門コード</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={payload.department_code ?? ""}
                  onChange={(event) => handleChange("department_code", event.target.value)}
                >
                  <option value="">未選択</option>
                  {DEPARTMENT_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">カテゴリ</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={payload.category ?? ""}
                  onChange={(event) => handleChange("category", event.target.value)}
                >
                  <option value="">未選択</option>
                  {FAQ_CATEGORY_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">FAQ種別</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={payload.faq_type ?? ""}
                  onChange={(event) => handleChange("faq_type", event.target.value)}
                >
                  <option value="">未選択</option>
                  {FAQ_TYPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">要約</label>
                <textarea
                  className={`min-h-[60px] ${INPUT_BASE_CLASS}`}
                  value={payload.summary ?? ""}
                  onChange={(event) => handleChange("summary", event.target.value)}
                />
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">公開範囲</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={payload.public_scope ?? SCOPE_FALLBACK}
                  onChange={(event) => handleChange("public_scope", event.target.value as FAQScope)}
                >
                  {PUBLIC_SCOPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col space-y-1">
                <label className="font-semibold">ステータス</label>
                <select
                  className={INPUT_BASE_CLASS}
                  value={payload.status ?? STATUS_FALLBACK}
                  onChange={(event) => handleChange("status", event.target.value as FAQStatus)}
                >
                  {FAQ_STATUS_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {error && <p className="bg-red-100 px-2 py-2 text-sm text-red-700">{error}</p>}
            {success && <p className="bg-emerald-100 px-2 py-2 text-sm text-emerald-700">{success}</p>}

            <div className="flex items-center gap-2">
              <button
                type="submit"
                className={PRIMARY_BUTTON_CLASS}
                disabled={submitting}
              >
                {submitting ? "登録中..." : "登録"}
              </button>
              <button
                type="button"
                className={SECONDARY_BUTTON_CLASS}
                onClick={() => router.back()}
              >
                キャンセル
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
