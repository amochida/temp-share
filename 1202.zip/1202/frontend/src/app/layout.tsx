import type { Metadata } from "next";
import "./globals.css";

// アプリ共通のメタ情報（タイトルや説明）を定義
export const metadata: Metadata = {
  title: "Sana Staff RAG",
  description: "スタッフ向け社内RAGチャットUI"
};

/** Next.js App Router のルートレイアウト。全ページを共通の <html>/<body> で包む。 */
export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja">
      <body className="min-h-screen w-screen bg-surface-page font-sans text-base text-content-primary antialiased">
        <div className="flex min-h-screen w-full flex-col">{children}</div>
      </body>
    </html>
  );
}
