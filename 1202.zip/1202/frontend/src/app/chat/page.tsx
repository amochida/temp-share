/* 「/chat」にアクセスされたときも、トップページ（app/page.tsx）と同じ画面を表示する。 */
export { default } from "../page";