"use client";

/**
 * Chat API クライアント。
 * Next.js から FastAPI の REST エンドポイントへ直接アクセスし、
 * UI で必要となる目的別の関数を提供する。
 */

import { apiJsonRequest, apiRequest, ApiError, encodeQueryParams } from "@/shared/api/http";
import type {
  ChatApiResponse,
  ChatAskPayload,
  ChatHistoryResponse,
  ChatSavePayload,
  ChatSaveResponse,
  FeedbackLatestResponse,
  FeedbackPayload,
  ThreadApiEntity,
  ThreadListApiResponse
} from "@/shared/types/chat";

/**
 * ネットワーク呼び出しの再試行回数のデフォルト値。
 * サーバー側が 5xx を返した場合に限り、最大 2 回の再試行を許可する。
 */
const DEFAULT_RETRY_LIMIT = 2;

/** fetch 失敗時に追加情報を持たせる独自エラー。 */
export class ChatApiError extends Error {
  status: number;
  body: string;

  constructor(status: number, body: string) {
    super(`Request failed (${status})`);
    this.name = "ChatApiError";
    this.status = status;
    this.body = body;
  }
}

/**
 * どの種類のエラーをリトライ対象にするかを判定する関数。
 * - ChatApiError で 5xx 系のみ true を返し、それ以外は即座に打ち切る。
 */
function shouldRetryDefault(error: unknown): boolean {
  if (error instanceof ChatApiError) {
    return error.status >= 500 && error.status < 600;
  }
  return true;
}

/**
 * API 呼び出しを共通的にリトライするためのラッパー関数。
 * - factory: 実際に fetch を叩く関数
 * - retries: 許容再試行回数
 * - shouldRetry: エラー内容に応じた再試行可否の判定関数
 */
async function withRetry<T>(
  factory: () => Promise<T>,
  retries = DEFAULT_RETRY_LIMIT,
  shouldRetry = shouldRetryDefault
): Promise<T> {
  let attempt = 0;
  let delayMs = 200;
  for (;;) {
    try {
      return await factory();
    } catch (error) {
      if (attempt >= retries || !shouldRetry(error)) {
        throw error;
      }
      await new Promise((resolve) => setTimeout(resolve, delayMs));
      attempt += 1;
      delayMs = Math.min(delayMs * 2, 1200);
    }
  }
}

/**
 * サイドバーに表示するスレッド一覧を取得する API 呼び出し。
 * - Next.js 側ではこの結果を `useChatSession` が保持して UI に渡す。
 */
export function fetchThreadList(): Promise<ThreadListApiResponse> {
  return apiRequest<ThreadListApiResponse>("/threads").catch((error) => {
    throw asChatApiError(error);
  });
}

/**
 * スレッド作成 API。
 * - タイトルを FormData で送信し、生成された ID を受け取る。
 */
export function createThreadRecord(title: string): Promise<ThreadApiEntity> {
  const formData = new FormData();
  if (title) {
    formData.append("title", title);
  }
  return apiRequest<ThreadApiEntity>("/threads", {
    method: "POST",
    body: formData
  }).catch((error) => {
    throw asChatApiError(error);
  });
}

/** サイドバーから削除されたスレッドをバックエンドでも削除する。 */
export function deleteThreadRecord(threadId: string): Promise<void> {
  return apiRequest<void>(`/threads/${encodeURIComponent(threadId)}`, { method: "DELETE" }).catch((error) => {
    throw asChatApiError(error);
  });
}

/**
 * LLM への問い合わせを行うメイン API。
 * - signal を渡すことで古いリクエストをキャンセルし、UI ローディングの整合性を保つ。
 */
export async function requestChatAnswer(payload: ChatAskPayload, signal?: AbortSignal): Promise<ChatApiResponse> {
  return withRetry(
    () => apiJsonRequest<ChatApiResponse>("/chat/ask", payload, { method: "POST", signal }),
    1
  ).catch((error) => {
    throw asChatApiError(error);
  });
}

/**
 * ユーザー発話と AI 応答を永続化するための API。
 * - 失敗時は呼び出し元でキュー管理し再送する設計。
 */
export async function persistChatMessages(payload: ChatSavePayload): Promise<ChatSaveResponse> {
  return withRetry(() => apiJsonRequest<ChatSaveResponse>("/chat/save", payload, { method: "POST" })).catch((error) => {
    throw asChatApiError(error);
  });
}

/** 選択中スレッドの履歴を一定件数だけ取得する。 */
export function loadChatHistory(threadId: string, limit: number): Promise<ChatHistoryResponse> {
  const search = new URLSearchParams();
  search.set("limit", String(limit));
  return apiRequest<ChatHistoryResponse>(
    `/chat/history/${encodeURIComponent(threadId)}${encodeQueryParams(search)}`
  ).catch((error) => {
    throw asChatApiError(error);
  });
}

/** Good/Bad 評価を送信する補助 API。 */
export function submitFeedback(payload: FeedbackPayload): Promise<void> {
  return apiJsonRequest<void>("/feedback", payload, { method: "POST" }).catch((error) => {
    throw asChatApiError(error);
  });
}

/**
 * あるスレッドに紐づく最新の Good/Bad 状態をまとめて取得する。
 * UI 表示時にリアルタイムで同期するための補助エンドポイント。
 */
export function fetchLatestFeedback(threadId: string): Promise<FeedbackLatestResponse> {
  const search = new URLSearchParams();
  search.set("thread_id", threadId);
  return apiRequest<FeedbackLatestResponse>(
    `/feedback/latest${encodeQueryParams(search)}`
  ).catch((error) => {
    throw asChatApiError(error);
  });
}

function asChatApiError(error: unknown): ChatApiError {
  if (error instanceof ChatApiError) {
    return error;
  }
  if (error instanceof ApiError) {
    return new ChatApiError(error.status, error.body || error.message);
  }
  if (error instanceof Error) {
    return new ChatApiError(500, error.message);
  }
  return new ChatApiError(500, "unexpected_error");
}
