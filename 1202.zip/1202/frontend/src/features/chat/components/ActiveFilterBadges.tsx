"use client";

/**
 * チャット画面のフィルタ状況をユーザーへフィードバックする UI 部品群。
 * 表示とボタン操作のみに責務を限定し、実際の状態更新はカスタムフックへ委譲する。
 */
import type { ChatFilterBadge, ChatFilterBadgeType } from "@/shared/types/chat";
import type { FC } from "react";

/** 親コンポーネントから渡されるプロパティ。 */
interface ActiveFilterBadgesProps {
  badges: ChatFilterBadge[];
  onRemove: (type: ChatFilterBadgeType, value: string) => void;
}

/**
 * 選択中のフィルタ条件をバッジ形式で表示するコンポーネント。
 * クリックで個別解除、右端ボタンで一括解除の操作を提供する。
 */
const ActiveFilterBadges: FC<ActiveFilterBadgesProps> = ({ badges, onRemove }) => {
  // バッジが存在しない場合は余計な空要素をレンダリングしない。
  if (!badges.length) return null;

  return (
    <div className="flex flex-wrap items-center gap-1 bg-surface-panel px-2 py-1 text-sm text-content-muted">
      <span className="font-semibold text-content-muted">選択中のフィルタ</span>
      {badges.map((badge) => (
        <button
          key={`${badge.type}-${badge.value}`}
          type="button"
          onClick={() => onRemove(badge.type, badge.value)}
          className="flex items-center gap-1 bg-surface-panel px-2 py-[3px] text-sm text-brand-primary hover:text-brand-accent rounded-lg"
        >
          <span>{badge.label}</span>
          <span aria-hidden>×</span>
        </button>
      ))}
    </div>
  );
};

export default ActiveFilterBadges;
