"use client";

import type { AnswerMode, ThreadFilterState } from "@/shared/types/chat";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, FilterX, Info } from "lucide-react";
import type { ReactNode } from "react";
import { useState } from "react";

/**
 * チャット画面上部に表示するカテゴリ／部門フィルタのセレクタコンポーネント。
 * - 親から受け取ったフィルタ状態をもとに、ボタン → ドロップダウン → チェックボックスを描画する。
 * - 「回答モード」「文書カテゴリ」「部門」「優先度」の 4 種類を扱うが、回答モードに応じて表示内容が変わる。
 * - 実際の状態更新は親コンポーネント（useChatSession）に委譲し、ここでは UI のみを担当する。
 */

interface Option {
  value: string;
  label: string;
}

type FilterPane = "mode" | "document" | "department" | "priority" | null;

/** 各フィルタードロップダウンの定義を統一するための型。 */
interface FilterPaneDefinition {
  key: Exclude<FilterPane, null>;
  label: string;
  summary: string;
  info: string;
  className?: string;
  onClear: () => void;
  render: () => ReactNode;
}

// 回答モードの定義。UI で表示するラベルと補足説明を一緒に管理する。
const ANSWER_MODE_OPTIONS: Array<{ value: AnswerMode; label: string; helper: string }> = [
  {
    value: "documents",
    label: "規則、マニュアルのみ",
    helper: "社内規程やマニュアルに記載された情報のみに絞って回答します。"
  },
  {
    value: "all",
    label: "なんでも回答（将来用）",
    helper: "規程だけでなくFAQや部門別情報も横断的に参照して回答します。"
  }
];

// 各フィルターのアイコン横に表示する説明テキスト。
const FILTER_INFOS = {
  document: "選択されたカテゴリのドキュメントのみを参照して回答を生成します。",
  department: "選択した部門に関連する情報を優先的に参照して回答を生成します。",
  priority: "優先度の高い情報を重視して回答内容を生成します。"
} as const;

interface CategorySelectorProps {
  filters: ThreadFilterState;
  options: {
    documentCategories: readonly Option[];
    departments: readonly Option[];
    priorities: readonly Option[];
  };
  openPane: FilterPane;
  onTogglePane: (pane: Exclude<FilterPane, null>) => void;
  onToggleDocumentCategory: (value: string) => void;
  onToggleDepartment: (value: string) => void;
  onSetPriority: (value: string) => void;
  onSetAnswerMode: (mode: AnswerMode) => void;
  onClearDocumentCategories: () => void;
  onClearDepartments: () => void;
  onResetPriority: () => void;
}

export default function CategorySelector({
  filters,
  options,
  openPane,
  onTogglePane,
  onToggleDocumentCategory,
  onToggleDepartment,
  onSetPriority,
  onSetAnswerMode,
  onClearDocumentCategories,
  onClearDepartments,
  onResetPriority
}: CategorySelectorProps) {
  // buildPaneDefinitions で動的に生成したフィルタパネルの構成情報。
  const panes = buildPaneDefinitions({
    filters,
    answerMode: filters.mode,
    options,
    onToggleDocumentCategory,
    onToggleDepartment,
    onSetPriority,
    onClearDocumentCategories,
    onClearDepartments,
    onResetPriority
  });

  const selectedMode = ANSWER_MODE_OPTIONS.find((option) => option.value === filters.mode) ?? ANSWER_MODE_OPTIONS[0];
  const modeIsOpen = openPane === "mode"; // 回答モードパネルが開いているかどうか。

  return (
    <div className="flex flex-wrap gap-2">
      <FilterButton
        label="回答モードを選択"
        summary={selectedMode.label}
        info={selectedMode.helper}
        highlight
        className="flex-none w-[260px]"
        isOpen={modeIsOpen}
        onToggle={() => onTogglePane("mode")}
        onClear={() => onSetAnswerMode("documents")}
      >
        <ModeOptions
          options={ANSWER_MODE_OPTIONS}
          selected={filters.mode}
          onSelect={(mode) => {
            onSetAnswerMode(mode);
            onTogglePane("mode");
          }}
        />
      </FilterButton>

      {panes.map((pane) => (
        <FilterButton
          key={pane.key}
          label={pane.label}
          summary={pane.summary}
          info={pane.info}
          className={pane.className}
          isOpen={openPane === pane.key}
          onToggle={() => onTogglePane(pane.key)}
          onClear={pane.onClear}
        >
          {pane.render()}
        </FilterButton>
      ))}
    </div>
  );
}

interface PaneDefinitionInput {
  filters: ThreadFilterState;
  answerMode: AnswerMode;
  options: CategorySelectorProps["options"];
  onToggleDocumentCategory: (value: string) => void;
  onToggleDepartment: (value: string) => void;
  onSetPriority: (value: string) => void;
  onClearDocumentCategories: () => void;
  onClearDepartments: () => void;
  onResetPriority: () => void;
}

/**
 * 現在の回答モードやフィルタ状態から、表示すべきフィルタパネルの一覧を生成する。
 * UI 側はこの戻り値を map しているだけなので、表示内容を変えたい場合はここを修正すればよい。
 */
function buildPaneDefinitions(config: PaneDefinitionInput): FilterPaneDefinition[] {
  const {
    filters,
    answerMode,
    options,
    onToggleDocumentCategory,
    onToggleDepartment,
    onSetPriority,
    onClearDocumentCategories,
    onClearDepartments,
    onResetPriority
  } = config;

  const panes: FilterPaneDefinition[] = [];

  // 文書カテゴリパネルは常に表示する。モードによって横幅を切り替え、余白を調整。
  panes.push({
    key: "document",
    label: "文書カテゴリを選択",
    summary: formatSummary(filters.documentCategories, options.documentCategories, "指定なし"),
    info: FILTER_INFOS.document,
    className: answerMode === "documents" ? "flex-none w-[280px]" : "flex-1",
    onClear: onClearDocumentCategories,
    render: () => (
      <OptionGrid options={options.documentCategories} selected={filters.documentCategories} onToggle={onToggleDocumentCategory} />
    )
  });

  if (answerMode === "all") {
    // なんでも回答モードのときのみ、部門と優先度のパネルも表示する。
    panes.push({
      key: "department",
      label: "部門を選択",
      summary: formatSummary(filters.departments, options.departments, "全て"),
      info: FILTER_INFOS.department,
      className: "flex-1",
      onClear: onClearDepartments,
      render: () => (
        <OptionGrid options={options.departments} selected={filters.departments} onToggle={onToggleDepartment} />
      )
    });

    panes.push({
      key: "priority",
      label: "優先度を選択",
      summary: options.priorities.find((option) => option.value === filters.priority)?.label ?? "バランス",
      info: FILTER_INFOS.priority,
      className: "flex-1",
      onClear: onResetPriority,
      render: () => (
        <PriorityOptions options={options.priorities} selected={filters.priority} onSelect={onSetPriority} />
      )
    });
  }

  return panes;
}

/**
 * 個々のフィルタボタン（ラベル + サマリ + ドロップダウン）で共通的に使う props 定義。
 * FilterButton 自体はプレゼンテーション専用で、内部の実際の選択 UI は子要素で差し込む。
 */
interface FilterButtonProps {
  label: string;
  summary: string;
  info: string;
  isOpen: boolean;
  className?: string;
  highlight?: boolean;
  onToggle: () => void;
  onClear: () => void;
  children: ReactNode;
}

/**
 * 共通のフィルタボタンコンポーネント。
 * - ボタン本体のクリックで開閉し、右上の「i」アイコンで補足説明をトグル表示する。
 * - 子要素として渡された内容をドロップダウン内にそのまま描画する構造になっている。
 */
function FilterButton({ label, summary, info, isOpen, className, highlight = false, onToggle, onClear, children }: FilterButtonProps) {
  const [infoOpen, setInfoOpen] = useState(false); // 「i」アイコン押下で補足説明を表示するかどうか。

  const handleToggle = () => {
    setInfoOpen(false); // ドロップダウンを開き直す際はツールチップを閉じて重なりを防ぐ。
    onToggle();
  };

  return (
    <div className={`relative min-w-[200px] ${className ?? "flex-1"}`}>
      <div
        className={`flex items-center gap-1 rounded-lg px-2 py-1 text-sm transition ${highlight
          ? `bg-brand-primary/40 text-brand-on ${isOpen ? "ring-1 ring-brand-on shadow-sm" : ""}`
          : `bg-surface-muted text-content-tertiary ${isOpen ? "ring-1 ring-brand-primary text-brand-primary shadow-sm" : ""}`
          }`}
      >
        <button
          type="button"
          onClick={handleToggle}
          className="flex flex-1 items-center justify-between gap-1 text-left"
          aria-expanded={isOpen}
        >
          <div>
            <p className="text-sm leading-tight">{label}</p>
            <p
              className={`truncate text-sm leading-tight ${highlight ? "text-brand-on/80" : "text-content-subtle"}`}
              title={summary}
            >
              {summary}
            </p>
          </div>
          <ChevronDown className={`h-4 w-4 transition ${isOpen ? "rotate-180" : "rotate-0"}`} />
        </button>
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            setInfoOpen((prev) => !prev);
          }}
          className={`rounded-full p-1 transition ${highlight ? "text-brand-on hover:text-brand-on/80" : "text-content-subtle hover:text-brand-primary"}`}
          aria-label={`${label}の説明を表示`}
        >
          <Info className="h-4 w-4" />
        </button>
      </div>

      {infoOpen && (
        <div className="absolute right-0 top-full z-30 mt-2 w-64 rounded bg-surface-panel px-3 py-2 text-sm text-content-tertiary shadow-lg">
          {info}
        </div>
      )}

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98, translateY: -8 }}
            animate={{ opacity: 1, scale: 1, translateY: 0 }}
            exit={{ opacity: 0, scale: 0.98, translateY: -8 }}
            transition={{ duration: 0.18 }}
            className="absolute z-20 mt-1 w-full min-w-[240px] max-w-3xl bg-surface-panel px-2 py-2 text-sm text-content-tertiary shadow-sm"
          >
            <div className="max-h-[55vh] overflow-y-auto pr-1">{children}</div>
            <div className="mt-2 flex justify-end">
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  onClear();
                }}
                className="flex items-center gap-1 px-2 py-1 text-sm text-brand-accent transition hover:text-brand-primary rounded-lg"
              >
                <FilterX className="h-4 w-4" /> クリア
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** 回答モードの選択肢に共通して使う props。 */
interface ModeOptionsProps {
  options: typeof ANSWER_MODE_OPTIONS;
  selected: AnswerMode;
  onSelect: (mode: AnswerMode) => void;
}

function ModeOptions({ options, selected, onSelect }: ModeOptionsProps) {
  return (
    <div className="grid gap-1">
      {options.map((option) => {
        const isActive = option.value === selected;
        // 将来的に開放予定の "all" モードは現状無効化しておく。
        const isDisabled = option.value === "all";
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => !isDisabled && onSelect(option.value)}
            disabled={isDisabled}
            className={`flex items-start gap-2 rounded-lg px-2 py-2 text-left text-sm transition
              ${isActive ? "bg-brand-primary/15 text-brand-primary" : "bg-surface-muted text-content-muted hover:text-brand-primary"}
              ${isDisabled ? "opacity-50 cursor-not-allowed hover:text-content-muted" : ""}
            `}
          >
            <span
              className={`mt-1 h-2 w-2 rounded-full ${isActive ? "bg-brand-primary" : "bg-content-subtle"}`}
            />
            <div>
              <p className="font-semibold leading-tight">{option.label}</p>
              <p className="text-xs text-content-subtle leading-snug">{option.helper}</p>
            </div>
          </button>
        );
      })}
    </div>
  );
}

/** チェックボックスを格子状に並べる汎用コンポーネントの props。 */
interface OptionGridProps {
  options: readonly Option[];
  selected: string[];
  onToggle: (value: string) => void;
}

function OptionGrid({ options, selected, onToggle }: OptionGridProps) {
  // 候補数に合わせて列数を変える目安を持たせ、表示整形時のクラス計算に利用する。
  const columnCount = options.length > 30 ? 3 : options.length > 12 ? 2 : 1;
  const alignmentClass = columnCount === 1 ? "justify-items-start" : "justify-items-stretch";

  return (
    <div className={`grid gap-1 grid-cols-1 ${alignmentClass}`}>
      {options.map((option) => {
        const isChecked = selected.includes(option.value);
        return (
          <label
            key={option.value}
            className={`flex cursor-pointer items-center gap-2 bg-surface-muted px-2 py-2 text-sm ${isChecked ? "text-brand-primary" : "text-content-muted"
              } w-full`}
          >
            <input
              type="checkbox"
              checked={isChecked}
              onChange={() => onToggle(option.value)}
              className="h-4 w-4 text-brand-primary focus:ring-brand-primary"
            />
            <span className="overflow-hidden text-ellipsis text-content-tertiary" title={option.label}>
              {option.label}
            </span>
          </label>
        );
      })}
    </div>
  );
}

/** 優先度ボタン群の props。単一選択（ラジオボタン代わり）で利用する。 */
interface PriorityOptionsProps {
  options: readonly Option[];
  selected: string;
  onSelect: (value: string) => void;
}

function PriorityOptions({ options, selected, onSelect }: PriorityOptionsProps) {
  return (
    <div className="grid gap-1">
      {options.map((option) => {
        const isActive = option.value === selected;
        // 選択中はラベル末尾に "選択中" を付けて視覚的なフィードバックを与える。
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => onSelect(option.value)}
            className={`flex items-center justify-between bg-surface-muted px-2 py-2 text-sm rounded-lg ${isActive ? "text-brand-primary" : "text-content-muted"
              }`}
          >
            <span>{option.label}</span>
            {isActive && <span className="text-sm text-brand-primary">選択中</span>}
          </button>
        );
      })}
    </div>
  );
}

/**
 * フィルタパネルのサマリ表記を生成する小さなヘルパー。
 * - 何も選んでいない場合は `emptyLabel` を返す。
 * - 全件選択している場合は「全て」と表示する。
 * - 2 件以下ならラベル名を列挙し、それ以上は件数表示で簡潔に示す。
 */
function formatSummary(selected: string[], options: readonly Option[], emptyLabel: string): string {
  if (!selected.length) return emptyLabel;
  if (selected.length === options.length) return "全て";
  if (selected.length <= 2) {
    return selected
      .map((value) => options.find((option) => option.value === value)?.label ?? value)
      .join("、");
  }
  return `${selected.length}件選択`;
}
