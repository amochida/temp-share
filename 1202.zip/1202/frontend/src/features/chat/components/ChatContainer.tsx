"use client";

/**
 * チャット画面のメッセージリスト領域を表すプレゼンテーションコンポーネント。
 * - `useChatSession` などから渡されたメッセージ配列をそのまま描画し、状態管理は親に委譲する。
 * - forwardRef を用いて末尾要素の参照を親へ返すことで、スクロール制御（最新メッセージへ自動移動）を実現している。
 */
import { forwardRef } from "react";
import ChatMessage from "./ChatMessage";
import type { Message } from "@/shared/types/chat";

/** ChatContainer が受け取るプロパティ。 */
interface ChatContainerProps {
  messages: Message[];
  onRate: (messageId: string, rating: "good" | "bad") => void;
  isLoading?: boolean;
  className?: string;
}

/**
 * メッセージ一覧をスクロール表示するコンポーネント。
 * forwardRef で末尾要素の参照を受け取り、親側で自動スクロールを制御できるようにしている。
 */
/**
 * ChatContainer コンポーネント本体。
 * - forwardRef によって親 (`useChatSession`) からスクロール末尾の DOM を参照できるようにする。
 */
const ChatContainer = forwardRef<HTMLDivElement, ChatContainerProps>(function ChatContainer(
  { messages, onRate, isLoading = false, className },
  bottomRef
) {
  // 親コンポーネントから追加クラスを受け取れるよう、デフォルトクラスと結合して使う。
  const baseClass = "flex h-full flex-col overflow-y-auto";
  const containerClass = className ? `${baseClass} ${className}` : baseClass;
  return (
    <section className={containerClass} data-chat-scroll-container>
      <div className="flex h-full flex-col gap-2 pr-1">
        {messages.map((message) => (
          // 個別メッセージは ChatMessage へ委譲し、このコンテナはリスト構造のみを担う。
          <ChatMessage key={message.id} message={message} onRate={onRate} />
        ))}
        {isLoading && (
          // 応答生成中は左側に淡いローディングバブルを表示。スクリーンリーダー向けに role/aria 属性も付与する。
          <div className="flex w-full justify-start" role="status" aria-live="polite">
            <div className="flex w-full max-w-[85%] justify-start sm:max-w-[70%] xl:max-w-[60%]">
              <div className="flex items-center gap-2 bg-surface-muted px-2 py-2 text-sm text-content-muted">
                <TypingIndicator />
                <span className="sr-only">AIが回答を準備しています</span>
              </div>
            </div>
          </div>
        )}
        {/* 親から forwardRef で受け取った参照をここに付与し、スクロール末尾の目印とする。 */}
        <div ref={bottomRef} />
      </div>
    </section>
  );
});

export default ChatContainer;

/**
 * AI が回答作成中であることを示す 3 点ドットの読み込み表示。
 * CSS アニメーション（animate-typing-dot）を利用して時間差で点滅させる。
 */
function TypingIndicator() {
  return (
    <div className="flex items-center gap-1" aria-hidden="true">
      <span className="h-2 w-2 bg-brand-primary/70 animate-typing-dot" />
      <span className="h-2 w-2 bg-brand-primary/70 animate-typing-dot" style={{ animationDelay: "0.2s" }} />
      <span className="h-2 w-2 bg-brand-primary/70 animate-typing-dot" style={{ animationDelay: "0.4s" }} />
    </div>
  );
}
