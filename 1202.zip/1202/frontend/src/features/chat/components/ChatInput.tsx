"use client";

import { Loader2, SendHorizontal } from "lucide-react";
import type { ChangeEvent, KeyboardEvent } from "react";
import { useEffect, useRef, useState } from "react";

/**
 * チャット入力欄コンポーネント。
 * - 画面全体の状態（value/isSending）は親から渡してもらい、ここでは UI の振る舞いに専念する。
 * - テキストエリアの高さ自動調整、Ctrl+Enter 送信などのキーボード操作を担当する。
 */

/** ChatInput が受け取るプロパティ。 */
/** ChatInput が受け取るプロパティの型。 */
interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  isSending: boolean;
}

/**
 * チャット画面下部の入力フォーム。
 * - 親 (`useChatSession` を使うコンポーネント) からバインド済みの値や送信関数を受け取る。
 */
export default function ChatInput({ value, onChange, onSubmit, isSending }: ChatInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null); // DOM 操作（自動リサイズ）に使う参照。
  const [height, setHeight] = useState("auto"); // テキストエリアの高さ。文字数に応じて更新する。

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    // 一度高さをリセットしてから scrollHeight を測定すると、改行が減った場合も縮むようになる。
    textarea.style.height = "auto";
    const nextHeight = Math.min(textarea.scrollHeight, 200); // 200px を超えたらスクロール表示に切り替え
    textarea.style.height = `${nextHeight}px`;
    setHeight(`${nextHeight}px`);
  }, [value]);

  /** Ctrl + Enter (もしくは Command + Enter) で送信。それ以外の Enter は改行扱い。 */
  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      onSubmit();
    }
  };

  /** 入力値が変化したら親コンポーネントへ即座に通知する。 */
  const handleChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    onChange(event.target.value);
  };

  return (
    <footer className="flex-shrink-0 flex flex-col gap-2 bg-surface-panel px-2 py-2">
      <div className="flex items-end gap-2">
        <textarea
          ref={textareaRef}
          className="flex-1 bg-surface-panel px-2 py-2 text-sm leading-relaxed outline-none transition focus:outline focus:outline-1 focus:outline-brand-primary border border-surface-border rounded-lg"
          placeholder="質問を入力してください (Ctrl+Enterで送信 / Enterで改行)"
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          disabled={isSending}
          rows={1}
          style={{ height, overflowY: height === "200px" ? "auto" : "hidden" }}
        />
        <button
          type="button"
          className="flex h-10 w-10 flex-none items-center justify-center bg-brand-primary text-brand-on_right transition hover:bg-brand-accent disabled:cursor-not-allowed disabled:opacity-60 rounded-lg"
          onClick={onSubmit}
          disabled={isSending || value.trim().length === 0}
        >
          {isSending ? <Loader2 className="h-5 w-5 animate-spin" /> : <SendHorizontal className="h-5 w-5" />}
          <span className="sr-only">送信</span>
        </button>
      </div>
      <span className="text-sm text-content-subtle">
        ⚠ AIの回答は必ずしも正しいとは限りません。重要な情報は原典を参照してください。
      </span>
    </footer>
  );
}
