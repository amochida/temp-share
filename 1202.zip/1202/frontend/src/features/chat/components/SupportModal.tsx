"use client";

import { type FC, useEffect, useRef } from "react";

/**
 * ユーザー支援情報（問い合わせ先・利用ポリシー）を案内するモーダル UI。
 * - 開閉状態やどの内容を表示するかは親から props で受け取り、ここは描画ロジックに集中する。
 * - モーダルのアクセシビリティ（フォーカス制御、ESC キーでの閉じる操作）も内部で面倒を見る。
 */

/** SupportModal が受け取るプロパティ。 */
interface SupportModalProps {
  type: "feedback" | "policy";
  onClose: () => void;
}

/**
 * フィードバック先や利用ポリシーを表示するモーダルコンポーネント。
 * props.type に応じて内容を切り替え、表示制御は親コンポーネントに委ねる。
 */
const SupportModal: FC<SupportModalProps> = ({ type, onClose }) => {
  const closeButtonRef = useRef<HTMLButtonElement | null>(null); // 初期フォーカスを合わせる対象。
  const title = type === "feedback" ? "フィードバックの送信先" : "利用方法・利用ポリシー";

  useEffect(() => {
    // 初回表示時に閉じるボタンへフォーカスを当て、キーボード操作で素早く閉じられるようにする。
    closeButtonRef.current?.focus();
  }, []);

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    };

    // ESC キーでモーダルを閉じられるようにする。開いている間だけイベントを登録する。
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [onClose]);

  const handleBackdropClick = () => {
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-content-primary/40 px-4 sm:px-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="support-modal-title"
      onClick={handleBackdropClick}
    >
      <div
        className="w-full max-w-xl bg-surface-panel px-4 py-4 text-sm text-content-tertiary rounded-lg shadow-md"
        onClick={(event) => event.stopPropagation()} // 背景クリックで閉じる挙動を維持しつつ、モーダル内のクリックは伝播させない。
      >
        <header className="flex items-start justify-between gap-2">
          <h2 id="support-modal-title" className="text-base font-semibold text-content-secondary">
            {title}
          </h2>
          <button
            ref={closeButtonRef}
            type="button"
            onClick={onClose}
            className="px-2 py-1 text-sm text-content-subtle hover:text-content-tertiary rounded-lg"
            aria-label="閉じる"
          >
            ×
          </button>
        </header>

        <div className="mt-3 max-h-[70vh] overflow-y-auto pr-1 text-sm text-content-tertiary">
          {type === "feedback" ? <FeedbackContent /> : <PolicyContent />}
        </div>

        <footer className="mt-4 flex justify-end">
          <button type="button" onClick={onClose} className="bg-brand-primary px-3 py-1 text-sm font-semibold text-content-inverse hover:brightness-110 rounded-lg">
            閉じる
          </button>
        </footer>
      </div>
    </div>
  );
};

export default SupportModal;

/** モーダル内でフィードバック窓口を案内するセクション。 */
const FeedbackContent: FC = () => (
  <section className="space-y-3 text-content-muted">
    <p>
      ご意見・改善提案は以下の連絡先までお寄せください。担当チームが内容を確認し、順次ご連絡いたします。
    </p>
    <div className="bg-brand-primary/10 px-3 py-3 text-content-tertiary">
      <h3 className="font-semibold text-brand-primary">CS推進部 サポートデスク</h3>
      <ul className="mt-2 space-y-1">
        <li>メール: support@example.co.jp</li>
        <li>内線: 3456 / Teams: #sana-feedback</li>
        <li>受付時間: 平日 09:00-18:00 (祝日除く)</li>
      </ul>
    </div>
  </section>
);

/** モーダル内で利用ポリシーを説明するセクション。 */
const PolicyContent: FC = () => (
  <section className="space-y-3 text-content-muted">
    <p>
      Sanaチャットの利用方法および利用ポリシーは以下のとおりです。社内規程・個人情報保護方針に従い、適切な利用をお願いします。
    </p>
    <ul className="list-disc space-y-2 pl-4 text-content-tertiary">
      <li>認証済みアカウントのみ利用可能です。第三者への共有は禁止されています。</li>
      <li>機密情報を送信する場合は、開示範囲と保存ポリシーを確認してください。</li>
      <li>回答はAI出力です。意思決定前に必ず原本資料・担当部署での確認を行ってください。</li>
      <li>不正利用や誤回答が疑われる場合は、速やかにサポートデスクへご連絡ください。</li>
    </ul>
    <div className="bg-surface-muted px-3 py-2 text-content-muted">
      詳細なマニュアルは社内Wiki
      <a
        href="https://www.google.com/"
        target="_blank"
        rel="noopener noreferrer"
        className="text-brand-primary underline hover:text-brand-accent"
      >
        Sana利用ガイド
      </a>
      を参照してください。
    </div>
  </section>
);
