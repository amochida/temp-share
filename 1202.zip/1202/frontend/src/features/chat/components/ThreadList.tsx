"use client";

import type { ThreadSummary } from "@/shared/types/chat";
import { Plus, Trash2 } from "lucide-react";

/**
 * チャット画面のサイドバーに表示するスレッド一覧コンポーネント。
 * - スレッドの選択・新規作成・削除など、ユーザーが会話を切り替える導線をまとめて提供する。
 * - 状態はすべて親から受け取り、描画とイベント発火（onSelect/onCreate/onDelete）のみ担当するプレゼンテーション層。
 */

interface ThreadListProps {
  threads: ThreadSummary[];
  activeThreadId?: string | null;
  maxThreads: number;
  interactionsDisabled?: boolean;
  onSelect: (thread: ThreadSummary) => void;
  onCreate: () => void;
  onDelete: (threadId: string) => void;
  onOpenFeedback: () => void;
  onOpenPolicy: () => void;
}

export default function ThreadList({
  threads,
  activeThreadId,
  maxThreads,
  interactionsDisabled = false,
  onSelect,
  onCreate,
  onDelete,
  onOpenFeedback,
  onOpenPolicy
}: ThreadListProps) {
  // スレッド数が上限未満、かつ操作が許可されている場合のみ「新規」ボタンを有効化する。
  const canCreate = !interactionsDisabled && threads.length < maxThreads;

  const handleSelect = (thread: ThreadSummary) => {
    if (interactionsDisabled) return;
    onSelect(thread);
  };

  const handleCreate = () => {
    if (interactionsDisabled) return;
    onCreate();
  };

  const handleDelete = (threadId: string) => {
    if (interactionsDisabled) return;
    onDelete(threadId);
  };

  return (
    <aside className="flex h-full min-h-0 w-full flex-col bg-brand-primary p-2 text-brand-on_right lg:w-[220px] lg:border-r lg:border-brand-primary/30">
      {/* 上部ヘッダ: 見出し + 新規作成ボタン。 */}
      <header className="flex items-center justify-between text-sm">
        <div>
          <h2 className="font-semibold text-brand-on_right">スレッド</h2>
          <p className="text-sm text-brand-on/80">最大 {maxThreads} 件</p>
        </div>
        <button
          type="button"
          className={`flex items-center gap-1 px-2 py-1 text-sm font-medium rounded-lg ${canCreate
            ? "bg-brand-on_right/15 text-brand-on_right hover:text-brand-accent"
            : "cursor-not-allowed bg-brand-on_right/15 text-brand-on_right/60"
            }`}
          onClick={handleCreate}
          disabled={!canCreate}
        >
          <Plus className="h-3 w-3" /> 新規
        </button>
      </header>

      <div className="mt-2 flex-1 min-h-0 overflow-y-auto space-y-1">
        {threads.length === 0 ? (
          <p className="bg-brand-on_right/10 px-2 py-4 text-sm text-brand-on_right/90">
            現在はスレッド作成できません。<br />スレッド作成は今後リリース予定の機能です。
          </p>
        ) : (
          threads.map((thread) => {
            const isActive = thread.id === activeThreadId;
            return (
              <article
                key={thread.id}
                className={`flex flex-col gap-1 bg-brand-on_right/10 px-2 py-2 text-sm transition-colors rounded-lg ${isActive ? "bg-brand-on_right/20" : ""
                  }`}
              >
                <button
                  type="button"
                  onClick={() => handleSelect(thread)}
                  disabled={interactionsDisabled}
                  className={`flex-1 text-left ${interactionsDisabled ? "cursor-not-allowed opacity-60" : ""}`}
                >
                  <h3 className="text-sm font-semibold leading-tight text-brand-on_right">{thread.title}</h3>
                  <p className="mt-1 line-clamp-2 text-sm text-brand-on_right/80">{thread.lastMessage || "(メッセージなし)"}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-brand-on_right/70">
                    <span>{thread.updatedAt}</span>
                    {thread.isDraft && (
                      <span className="rounded bg-brand-on_right/20 px-1 text-xs text-brand-on_right">下書き</span>
                    )}
                  </div>
                </button>
                <button
                  type="button"
                  className={`ml-auto flex h-5 w-5 items-center justify-center rounded-lg ${interactionsDisabled
                    ? "cursor-not-allowed text-brand-on_right/40"
                    : "text-brand-on_right/70 hover:text-brand-accent"
                    }`}
                  onClick={() => handleDelete(thread.id)}
                  aria-label="スレッドを削除"
                  disabled={interactionsDisabled}
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </article>
            );
          })
        )}
      </div>

      <footer className="mt-2 space-y-1 text-sm text-brand-on_right/80">
        {/* サポートモーダルを呼び出すリンク群。 */}
        <button
          type="button"
          className="text-left underline underline-offset-2 hover:text-brand-accent rounded-lg"
          onClick={onOpenFeedback}
        >
          フィードバックや改善要望はこちら
        </button>
        <button
          type="button"
          className="text-left underline underline-offset-2 hover:text-brand-accent rounded-lg"
          onClick={onOpenPolicy}
        >
          利用方法・利用ポリシーはこちら
        </button>
      </footer>
    </aside>
  );
}
