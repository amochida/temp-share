"use client";

/**
 * チャットメッセージの表示コンポーネント。
 * 役割に応じて左右へ配置するだけのシンプルな構造にしている。
 */
import type { Citation, Message } from "@/shared/types/chat";
import { Check, Copy, ThumbsDown, ThumbsUp } from "lucide-react";
import Image from "next/image";
import { memo, useEffect, useState, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import rehypeSanitize from "rehype-sanitize";
import remarkGfm from "remark-gfm";

/** ChatMessage で扱うプロパティ。評価ボタンは任意。 */
interface ChatMessageProps {
  message: Message;
  onRate?: (messageId: string, rating: "good" | "bad") => void;
}

const ChatMessage = memo(function ChatMessage({ message, onRate }: ChatMessageProps) {
  // 発言者に応じて左右の配置や色味を切り替える。
  const isUser = message.role === "user";
  const isInitialAssistantMessage = !isUser && message.id === "welcome";
  const wrapperWidthClass = "w-full max-w-[85%] sm:max-w-[70%] xl:max-w-[60%]";
  const rowAlignmentClass = isUser ? "justify-end" : "justify-start";
  const bubbleAlignmentClass = isUser ? "items-end" : "items-start";
  const userBubbleClass = "whitespace-pre-wrap break-words bg-brand-primary/15 px-3 py-2 text-sm text-brand-primary md:text-base rounded-lg";
  const assistantBubbleClass = "break-words bg-surface-muted px-3 py-2 text-sm text-content-secondary md:text-base leading-relaxed rounded-lg";

  const bubbleClass = isUser ? userBubbleClass : assistantBubbleClass;
  const bubbleAlignment = isUser ? "self-end" : "self-start";
  const assistantMarkdown = message.content?.trimStart() ?? "";

  return (
    <div className={`flex w-full ${rowAlignmentClass}`}>
      <div className={`flex ${wrapperWidthClass} flex-col gap-3 ${bubbleAlignmentClass}`}>
        <div className={`${bubbleClass} ${bubbleAlignment}`}>
          {isUser ? (
            message.content
          ) : (
            <div className="flex items-start gap-2">
              <span className="mt-0.5 inline-flex h-7 w-7 flex-shrink-0 overflow-hidden rounded-full bg-white" aria-hidden="true">
                <Image src="/assistant.svg" alt="" width={28} height={28} className="h-full w-full object-contain" />
              </span>
              {/* アシスタントの本文は Markdown として表示し、リンクは新規タブで開く。 */}
              <ReactMarkdown
                className="min-w-0 flex-1 whitespace-normal [&_*]:break-words [&>p]:mb-3 [&>p:last-child]:mb-0 [&>ul]:list-disc [&>ul]:pl-5 [&>ol]:list-decimal [&>ol]:pl-5 [&>pre]:overflow-x-auto [&>pre]:rounded-md [&>pre]:bg-surface-panel [&>pre]:p-3"
                remarkPlugins={[remarkGfm as any]}
                rehypePlugins={[rehypeSanitize]}
                components={{
                  a: (props) => <a {...props} target="_blank" rel="noopener noreferrer" />
                }}
              >
                {assistantMarkdown}
              </ReactMarkdown>
            </div>
          )}
        </div>

        {!isUser && renderCitations(message.citations)}

        {!isUser && onRate && !isInitialAssistantMessage && (
          <div className="flex items-center gap-2 text-sm text-content-subtle" role="group" aria-label="回答の評価">
            <FeedbackButton
              ariaLabel="Good"
              isActive={message.rating === "good"}
              activeClassName="bg-brand-accent/20 text-brand-accent rounded-lg"
              inactiveClassName="bg-surface-panel text-content-subtle hover:text-brand-accent"
              icon={<ThumbsUp className="h-3 w-3" aria-hidden="true" />}
              onClick={() => onRate(message.id, "good")}
            />
            <FeedbackButton
              ariaLabel="Bad"
              isActive={message.rating === "bad"}
              activeClassName="bg-brand-primary/20 text-brand-primary rounded-lg"
              inactiveClassName="bg-surface-panel text-content-subtle hover:text-brand-primary"
              icon={<ThumbsDown className="h-3 w-3" aria-hidden="true" />}
              onClick={() => onRate(message.id, "bad")}
            />
            <CopyMessageButton content={message.content} />
          </div>
        )}
      </div>
    </div>
  );
});

export default ChatMessage;

/** 引用情報が存在する場合にリスト表示する補助関数。 */
function renderCitations(citations?: Citation[]) {
  if (!citations || citations.length === 0) return null;
  return (
    <div className="bg-surface-muted px-2 py-2 text-sm text-content-tertiary">
      <p className="font-semibold">出典</p>
      <ul className="mt-1 space-y-1 pl-4">
        {citations.map((citation) => (
          <li key={citation.chunkId} className="list-disc">
            <span className="font-medium">{formatSourceLabel(citation.source)}：</span>
            <span className="ml-1 text-content-secondary">{renderCitationTitle(citation)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function renderCitationTitle(citation: Citation): ReactNode {
  const label = citation.title ?? "名称未設定";
  const sourceUri = citation.sourceUri?.trim();
  if (!sourceUri) {
    return label;
  }
  if (isWebLink(sourceUri)) {
    return (
      <a href={sourceUri} target="_blank" rel="noopener noreferrer" className="text-brand-primary underline-offset-2 hover:underline">
        {label}
      </a>
    );
  }
  return (
    <>
      {label}
      <span className="ml-1 text-xs text-content-tertiary">（{sourceUri}）</span>
    </>
  );
}

function isWebLink(value: string): boolean {
  const normalized = value.toLowerCase();
  return normalized.startsWith("http://") || normalized.startsWith("https://");
}

function formatSourceLabel(source?: string): string {
  if (!source) return "出典";
  if (source.startsWith("documents")) {
    return "規程参照";
  }
  if (source.startsWith("faqs")) {
    return "FAQ参照";
  }
  return "出典";
}

/** 評価ボタンをレンダリングする際のパラメータ。 */
interface FeedbackButtonProps {
  ariaLabel: string;
  isActive: boolean;
  activeClassName: string;
  inactiveClassName: string;
  icon: ReactNode;
  onClick: () => void;
}

/**
 * Good / Bad の評価ボタン。色やアイコンを引数で受け取り、押下状態を共通化する。
 */
function FeedbackButton({
  ariaLabel,
  isActive,
  activeClassName,
  inactiveClassName,
  icon,
  onClick
}: FeedbackButtonProps) {
  // 標準のボタン外観とフォーカスリングを baseClass にまとめ、状態に応じて色味を付け替える。
  const baseClass =
    "flex items-center gap-1 px-2 py-1 text-sm font-medium transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brand-primary";
  const stateClass = isActive ? activeClassName : inactiveClassName;
  return (
    <button type="button" aria-label={ariaLabel} aria-pressed={isActive} className={`${baseClass} ${stateClass}`} onClick={onClick}>
      {icon}
      <span className="sr-only">{ariaLabel}</span>
    </button>
  );
}

/**
 * メッセージ本文をクリップボードへコピーする補助ボタン。
 * Navigator API が使えない環境向けに古典的な textarea コピーも用意し、利用者へのフィードバックとして状態表示を行う。
 */
function CopyMessageButton({ content }: { content: string }) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const timer = setTimeout(() => setCopied(false), 1500);
    return () => clearTimeout(timer);
  }, [copied]);

  useEffect(() => {
    setCopied(false);
  }, [content]);

  const copyWithFallback = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
      return navigator.clipboard.writeText(content);
    }
    return new Promise<void>((resolve, reject) => {
      try {
        const textarea = document.createElement("textarea");
        textarea.value = content;
        textarea.setAttribute("readonly", "");
        textarea.style.position = "absolute";
        textarea.style.left = "-9999px";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  };

  const handleCopy = () => {
    copyWithFallback()
      .then(() => setCopied(true))
      .catch((error) => {
        console.warn("failed to copy message", error);
        setCopied(false);
      });
  };

  return (
    <button
      type="button"
      onClick={handleCopy}
      className="flex items-center gap-1 px-2 py-1 text-sm text-content-subtle transition hover:text-brand-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brand-primary rounded-lg"
      aria-label="メッセージをコピー"
    >
      {copied ? <Check className="h-3 w-3" aria-hidden="true" /> : <Copy className="h-3 w-3" aria-hidden="true" />}
      <span>{copied ? "コピー済" : "コピー"}</span>
    </button>
  );
}
