"use client";

/**
 * チャット画面全体の状態管理を担うカスタムフック。
 * スレッド一覧取得、メッセージ送受信、フィルタ保持など UI に必要なロジックを集約する。
 */
import {
  createThreadRecord,
  deleteThreadRecord,
  fetchLatestFeedback as fetchLatestFeedbackApi,
  fetchThreadList,
  loadChatHistory,
  persistChatMessages,
  requestChatAnswer,
  submitFeedback as submitFeedbackApi
} from "@/features/chat/api/chatApi";
import { DEPARTMENT_OPTIONS, DOCUMENT_CATEGORY_OPTIONS, PRIORITY_OPTIONS } from "@/features/chat/constants/filterOptions";
import {
  buildFilterBadges,
  buildFilterPayload,
  buildHistoryPayload,
  deriveThreadTitle,
  generateMessageId,
  INITIAL_MESSAGES,
  mapApiCitations,
  mapHistory,
  mapThreadSummary,
  serializeCitations
} from "@/features/chat/utils/chatHelpers";
import {
  createDefaultFilters,
  DEFAULT_FILTER_STATE,
  DRAFT_FILTER_KEY,
  ensureDraftEntry,
  loadFilterStore,
  removeStorageKey,
  saveFilterStore,
  THREAD_FILTER_STORAGE_KEY,
  type ThreadFilterStore
} from "@/features/chat/utils/filterStore";
import type {
  AnswerMode,
  ChatAskPayload,
  ChatFilterBadge,
  ChatFilterBadgeType,
  ChatSavePayload,
  FeedbackPayload,
  Message,
  ThreadApiEntity,
  ThreadFilterState,
  ThreadSummary
} from "@/shared/types/chat";
import { toggleListValue } from "@/shared/utils/arrayHelpers";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

// ----------------------------------------------------------------------------------
// 定数定義: チャットフロー全体で使い回す閾値や localStorage 用のキーをまとめて管理する。
// ----------------------------------------------------------------------------------
const MAX_THREADS = 5; // ユーザーが保持できるスレッドの上限。フロント側で制御し API に過負荷をかけない。
const MAX_HISTORY_LIMIT = 200; // 過去メッセージを何件まで読み戻すかの上限値。履歴 API 呼び出し時にも利用。
const HISTORY_CONTEXT_LENGTH = 10; // LLM に送る履歴の最大件数。長すぎる履歴はここで切り詰める。
const THREAD_FEATURE_FLAG = process.env.NEXT_PUBLIC_ENABLE_THREADS ?? "";
const THREAD_FEATURES_ENABLED = THREAD_FEATURE_FLAG === "1" || THREAD_FEATURE_FLAG.toLowerCase() === "true";

const departmentOptions = DEPARTMENT_OPTIONS; // Select コンポーネントに表示する部門候補。
const documentCategoryOptions = DOCUMENT_CATEGORY_OPTIONS; // 文書カテゴリの候補。

/** useChatSession フックが返す値の一覧。画面側はこの形を前提にして状態を描画する。 */
export interface UseChatSessionResult {
  threads: ThreadSummary[];
  activeThreadId: string | null;
  activeThread: ThreadSummary | null;
  messages: Message[];
  input: string;
  isSending: boolean;
  threadFeaturesEnabled: boolean;
  statusLabel: string;
  filterOptions: {
    departments: typeof departmentOptions;
    documentCategories: typeof documentCategoryOptions;
    priorities: typeof PRIORITY_OPTIONS;
  };
  filters: ThreadFilterState;
  isInitialized: boolean;
  maxThreads: number;
  hasThreads: boolean;
  sendCurrentMessage: () => Promise<void>;
  setInput: (value: string) => void;
  createThread: () => Promise<void>;
  selectThread: (thread: ThreadSummary) => Promise<void>;
  deleteThread: (threadId: string) => Promise<void>;
  rateMessage: (messageId: string, rating: "good" | "bad") => Promise<void>;
  toggleDocumentCategory: (value: string) => void;
  toggleDepartment: (value: string) => void;
  setPriority: (value: string) => void;
  setAnswerMode: (mode: AnswerMode) => void;
  resetAllFilters: () => void;
  clearDocumentCategories: () => void;
  clearDepartments: () => void;
  resetPriority: () => void;
  filterBadges: ChatFilterBadge[];
  removeFilterBadge: (type: ChatFilterBadgeType, value: string) => void;
}

/**
 * チャット画面で利用する状態と操作関数をまとめて提供するカスタムフック。
 * ルートコンポーネントから呼び出し、戻り値を必要な子コンポーネントへ渡す想定。
 */
export function useChatSession(): UseChatSessionResult {
  // ------------------------------------------------------------
  // React state: 画面全体で共有するリアクティブな値
  // ------------------------------------------------------------
  const [threads, setThreads] = useState<ThreadSummary[]>([]); // サイドバーに表示するスレッド一覧。最新順に並び替える。
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null); // 現在選択されているスレッドの ID。null は未選択を表す。
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES); // メッセージログ。初期値として案内メッセージを 1 件表示。
  const [input, setInput] = useState(""); // テキストエリアの入力内容。双方向バインドで更新する。
  const [isSending, setIsSending] = useState(false); // メッセージ送信中フラグ。二重送信や UI のローディング表示に利用。

  // localStorage と同期させるフィルタ辞書。キーはスレッド ID、値はそのスレッド専用のフィルタ状態。
  const [threadFilters, setThreadFilters] = useState<ThreadFilterStore>({
    [DRAFT_FILTER_KEY]: createDefaultFilters()
  });
  const [filters, setFilters] = useState<ThreadFilterState>(createDefaultFilters()); // 画面上で現在表示しているフィルタ。activeThreadId と連動して入れ替わる。

  // 下記の状態は副作用の実行制御に使う内部フラグ群。
  const [filterStoreHydrated, setFilterStoreHydrated] = useState(false); // localStorage からの復元が完了したかどうか。完了前は保存を行わない。
  const [initialized, setInitialized] = useState(false); // 初期ロード（スレッド一覧取得）が完了したか。UI のスケルトン表示などに使える。

  // ref は「再レンダリングを引き起こさない共有メモリ」として扱う。
  const flushInProgressRef = useRef(false); // 永続化処理が実行中かどうか。true の間は新しい flush を走らせない。
  const pendingSavesRef = useRef<ChatSavePayload[]>([]); // まだサーバーへ送っていない保存リクエストのキュー。
  const activeFetchSignal = useRef<AbortController | null>(null); // 最新の ask API 呼び出しを中断するための AbortController。
  const filterStoreSourceKeyRef = useRef<string | null>(null); // localStorage 読み込み時に使用したキーを保存し、後で掃除する。

  const currentFilterKey = activeThreadId ?? DRAFT_FILTER_KEY; // 現在表示中スレッドに紐づくフィルタ辞書のキー。draft の場合は特殊キーを使う。

  /**
   * DB に保存されている最新の評価状態を取得し、画面上のメッセージへ反映する。
   * - Good/Bad はそのまま表示し、cancel は null（未評価）として扱う。
   */
  const refreshLatestRatings = useCallback(
    async (threadId: string) => {
      if (!threadId) return;
      try {
        const response = await fetchLatestFeedbackApi(threadId);
        if (!response.items?.length) {
          return;
        }
        const ratingMap = response.items.reduce<Record<string, Message["rating"]>>((acc, item) => {
          acc[item.assistant_message_id] = item.rating === "cancel" ? null : item.rating;
          return acc;
        }, {});
        setMessages((prev) =>
          prev.map((message) => {
            if (message.role !== "assistant") {
              return message;
            }
            if (!(message.id in ratingMap)) {
              return message;
            }
            const normalized = ratingMap[message.id];
            if (message.rating === normalized) {
              return message;
            }
            return { ...message, rating: normalized };
          })
        );
      } catch (error) {
        console.error("Failed to fetch latest feedback", error);
      }
    },
    [setMessages]
  );

  /**
   * メモリ上に溜めている保存リクエストをまとめて送信する。
   * - ネットワークエラー時はキューに戻し、次回 flush で再試行する。
   * - 同時実行を避けるため、実行中フラグでガードしている。
   */
  /**
   * 未送信の保存要求を一括でサーバーへ送る補助関数。
   * - ネットワーク障害があった場合はキューへ戻し、次回呼び出しで再試行する。
   * - `flushInProgressRef` を使って同時実行を防ぎ、状態競合を回避している。
   */
  const flushPendingSaves = useCallback(async () => {
    if (flushInProgressRef.current) return;
    if (pendingSavesRef.current.length === 0) return;
    flushInProgressRef.current = true;
    try {
      const queue = [...pendingSavesRef.current];
      pendingSavesRef.current = [];
      for (const payload of queue) {
        // 1 ペイロードずつ順番に送信し、エラーになった場合のみキューへ戻す。
        try {
          await persistChatMessages(payload);
        } catch (error) {
          console.error("Failed to persist chat payload", error);
          pendingSavesRef.current.push(payload);
        }
      }
    } finally {
      flushInProgressRef.current = false;
    }
  }, []);

  // 定期的にキューを掃除するタイマー。ブラウザを閉じる直前などこぼれた保存要求が出ないようにする。
  useEffect(() => {
    if (typeof window === "undefined") return;
    const timer = window.setInterval(() => {
      flushPendingSaves().catch(() => {
        /* flush 内でログ済み */
      });
    }, 5000);
    return () => window.clearInterval(timer);
  }, [flushPendingSaves]);

  // 初回レンダリング時に localStorage からフィルタ辞書を復元する。復元完了までは保存処理を抑制する。
  useEffect(() => {
    const { store, sourceKey } = loadFilterStore();
    setThreadFilters(store);
    filterStoreSourceKeyRef.current = sourceKey;
    setFilterStoreHydrated(true);
  }, []);

  // threadFilters が更新されたタイミングで localStorage へ即座に書き戻す。復元前は実行しない。
  useEffect(() => {
    if (!filterStoreHydrated) {
      return;
    }
    const persisted = saveFilterStore(threadFilters);
    if (persisted) {
      if (filterStoreSourceKeyRef.current && filterStoreSourceKeyRef.current !== THREAD_FILTER_STORAGE_KEY) {
        removeStorageKey(filterStoreSourceKeyRef.current);
      }
      filterStoreSourceKeyRef.current = THREAD_FILTER_STORAGE_KEY;
    }
  }, [threadFilters, filterStoreHydrated]);

  // アプリ起動時の初期化。スレッド一覧を取得し、最初のスレッドを自動選択して履歴を読み込む。
  useEffect(() => {
    if (!THREAD_FEATURES_ENABLED) {
      setThreads([]);
      setMessages(INITIAL_MESSAGES);
      setActiveThreadId(null);
      setInitialized(true);
      return;
    }

    let cancelled = false;

    const initialize = async () => {
      try {
        const data = await fetchThreadList();
        if (cancelled) return;
        const items = data.items ?? [];
        if (!items.length) {
          setThreads([]);
          setMessages(INITIAL_MESSAGES);
          setActiveThreadId(null);
          setInitialized(true);
          return;
        }
        const summaries = items.map((item) =>
          mapThreadSummary({
            id: String(item?.id ?? ""),
            title: item?.title ?? undefined,
            updated_at: item?.updated_at ?? undefined
          })
        );
        setThreads(summaries);
        const firstThread = summaries[0];
        setActiveThreadId(firstThread.id);
        const history = await loadChatHistory(firstThread.id, MAX_HISTORY_LIMIT); // ローカル表示用の履歴を取得
        if (!cancelled) {
          setMessages(mapHistory(history.items));
          refreshLatestRatings(firstThread.id).catch((error) => {
            console.error("Failed to refresh latest ratings", error);
          });
        }
      } catch (error) {
        if (!cancelled) {
          console.error("Failed to initialize chat session", error);
          setThreads([]);
          setMessages(INITIAL_MESSAGES);
        }
      } finally {
        if (!cancelled) {
          setInitialized(true);
        }
      }
    };

    // 初回レンダリング時にスレッド一覧と履歴をまとめてロードする。
    initialize();

    return () => {
      // コンポーネントがアンマウントされた場合は、進行中のリクエストを中断してメモリリークを防ぐ。
      cancelled = true;
      if (activeFetchSignal.current) {
        activeFetchSignal.current.abort();
        activeFetchSignal.current = null;
      }
    };
  }, [refreshLatestRatings]);

  // アクティブスレッドが切り替わった際にフィルタの表示値を更新する。
  const activeThread = useMemo(
    () => threads.find((thread) => thread.id === activeThreadId) ?? null,
    [threads, activeThreadId]
  );

  useEffect(() => {
    // activeThreadId が変わると currentFilterKey も変わる。該当するフィルタが保存されていれば復元し、なければ初期値を生成する。
    if (!filterStoreHydrated) {
      return;
    }
    const stored = threadFilters[currentFilterKey];
    if (stored) {
      setFilters(stored);
      return;
    }
    const fallback = createDefaultFilters();
    setFilters(fallback);
    setThreadFilters((prev) => ({ ...prev, [currentFilterKey]: fallback }));
  }, [currentFilterKey, threadFilters, filterStoreHydrated]);

  const updateFiltersState = useCallback(
    (updater: (prev: ThreadFilterState) => ThreadFilterState) => {
      // setState の関数型更新を利用し、最新の値を渡す。戻り値はそのまま画面表示用フィルタに反映される。
      setFilters((prev) => {
        const next = updater(prev);
        // 同時にスレッドごとの辞書も更新。spread でコピーすることでイミュータブルに保つ。
        setThreadFilters((store) => ({ ...store, [currentFilterKey]: next }));
        return next;
      });
    },
    [currentFilterKey]
  );

  const hasThreads = threads.length > 0; // true のときだけ一覧に履歴が存在する。
  const statusLabel = isSending ? "応答生成中..." : "待機中"; // 上部ステータス表示用の文言。
  const filterOptions = useMemo(
    () =>
      ({
        departments: departmentOptions,
        documentCategories: documentCategoryOptions,
        priorities: PRIORITY_OPTIONS
      }) as const,
    []
  ); // useMemo でオブジェクト参照を固定し、子コンポーネントの不要な再レンダリングを防ぐ。
  /**
   * スレッド ID が未確定な場合に新規スレッドを作成し、以降の送信で利用できる ID を返す。
   * - 既存スレッドを選択中で draft でなければ、その ID をそのまま返す。
   * - draft の場合は API を叩いて本物のスレッドを作成し、ローカル状態を置き換える。
   * - スレッド数が上限に達している場合はエラーを投げ、呼び出し元でアラート表示する。
   */
  const ensureThread = useCallback(
    async (title: string) => {
      if (activeThreadId) {
        const current = threads.find((thread) => thread.id === activeThreadId);
        if (current && !current.isDraft) {
          return activeThreadId;
        }

        if (current && current.isDraft) {
          const created = await createThreadRecord(title);
          const persistedId = created.id;
          setThreads((prev) => {
            const others = prev.filter((thread) => thread.id !== activeThreadId);
            const summary = mapThreadSummary(created, {
              title,
              lastMessage: current.lastMessage,
              updatedAt: new Date().toLocaleString(),
              department: current.department,
              documentType: current.documentType,
              isDraft: false
            });
            return [summary, ...others];
          });
          setThreadFilters((prev) => {
            const next = { ...prev };
            const storedFilters = { ...(next[activeThreadId] ?? createDefaultFilters()) };
            delete next[activeThreadId];
            next[persistedId] = storedFilters;
            return ensureDraftEntry(next);
          });
          setActiveThreadId(persistedId);
          return persistedId;
        }
      }

      if (threads.length >= MAX_THREADS) {
        throw new Error(`最大${MAX_THREADS}件まで作成できます`);
      }

      const created = await createThreadRecord(title);
      const summary = mapThreadSummary(created, {
        title,
        lastMessage: "まだ会話がありません",
        updatedAt: new Date().toLocaleString(),
        department: filters.departments[0] ?? departmentOptions[0].value,
        documentType: (filters.documentCategories[0] ?? DEFAULT_FILTER_STATE.documentCategories[0]) ?? documentCategoryOptions[0].value,
        isDraft: false
      });
      setThreads((prev) => [summary, ...prev]);
      setActiveThreadId(summary.id);
      setThreadFilters((prev) => {
        const next = { ...prev };
        const draftFilters = { ...(next[DRAFT_FILTER_KEY] ?? createDefaultFilters()) };
        next[summary.id] = draftFilters;
        delete next[DRAFT_FILTER_KEY];
        return ensureDraftEntry(next);
      });
      return summary.id;
    },
    [activeThreadId, createThreadRecord, filters, threads]
  );

  /**
   * 入力欄のテキストをサーバーへ送信し、LLM からの回答を受け取ってメッセージログに反映する。
   * - 送信中フラグで二重送信を抑止し、UI もローディング表示に切り替える。
   * - スレッド作成、ユーザーメッセージの挿入、LLM リクエスト、応答の保存までを一連で行う。
   */
  const sendCurrentMessage = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isSending) return;

    setIsSending(true);
    setInput("");

    const titleCandidate = deriveThreadTitle(trimmed);
    try {
      const threadId = await ensureThread(titleCandidate);
      const createdAt = new Date();
      const userMessage: Message = {
        id: generateMessageId(),
        role: "user",
        content: trimmed,
        createdAt: createdAt.toISOString(),
        citations: []
      };

      setMessages((prev) => [...prev, userMessage]);

      setThreads((prev) => {
        const existing = prev.find((thread) => thread.id === threadId);
        const summary = mapThreadSummary(
          { id: threadId, title: existing?.title, updated_at: new Date().toISOString() },
          {
            title: existing?.title && existing.title !== "新しい問い合わせ" ? existing.title : titleCandidate,
            lastMessage: trimmed,
            updatedAt: new Date().toLocaleString(),
            isDraft: false
          }
        );
        const others = prev.filter((thread) => thread.id !== threadId);
        return [summary, ...others];
      });

      const filterPayload = buildFilterPayload(filters);
      const askPayload: ChatAskPayload = {
        thread_id: threadId,
        query: trimmed,
        history: buildHistoryPayload([...messages, userMessage], HISTORY_CONTEXT_LENGTH),
        ...(filterPayload ? { filters: filterPayload } : {})
      };

      const abortController = new AbortController();
      if (activeFetchSignal.current) {
        activeFetchSignal.current.abort();
      }
      activeFetchSignal.current = abortController;

      const response = await requestChatAnswer(askPayload, abortController.signal);
      const assistantMessage: Message = {
        id: response.query_id,
        role: "assistant",
        content: response.answer,
        citations: mapApiCitations(response.citations),
        rating: null,
        queryId: response.query_id,
        promptType: response.prompt_type,
        createdAt: new Date().toISOString(),
        sourcesUsed: response.sources_used ?? []
      };

      setMessages((prev) => [...prev, assistantMessage]);

      setThreads((prev) => {
        const existing = prev.find((thread) => thread.id === threadId);
        const summary = existing
          ? {
            ...existing,
            title:
              existing.title && existing.title !== "新しい問い合わせ"
                ? existing.title
                : titleCandidate,
            lastMessage: assistantMessage.content || existing.lastMessage,
            updatedAt: new Date().toLocaleString()
          }
          : mapThreadSummary(
            { id: threadId, updated_at: new Date().toISOString() },
            {
              title: titleCandidate,
              lastMessage: assistantMessage.content,
              updatedAt: new Date().toLocaleString(),
              isDraft: false
            }
          );
        const others = prev.filter((thread) => thread.id !== threadId);
        return [summary, ...others];
      });

      const savePayload: ChatSavePayload = {
        thread_id: threadId,
        messages: [
          {
            id: userMessage.id,
            role: userMessage.role,
            content: userMessage.content,
            created_at: createdAt.toISOString(),
            citations: serializeCitations(userMessage.citations)
          },
          {
            id: assistantMessage.id,
            role: assistantMessage.role,
            content: assistantMessage.content,
            created_at: assistantMessage.createdAt ?? new Date().toISOString(),
            citations: serializeCitations(assistantMessage.citations)
          }
        ]
      };

      pendingSavesRef.current.push(savePayload);
      flushPendingSaves().catch(() => {
        /* flush 内でログ済み */
      });
    } catch (error) {
      console.error("Failed to complete chat request", error);
      setMessages((prev) => [
        ...prev,
        {
          id: generateMessageId(),
          role: "assistant",
          content: "回答の取得に失敗しました。時間をおいて再度お試しください。",
          rating: null
        }
      ]);
    } finally {
      setIsSending(false);
    }
  }, [input, isSending, ensureThread, filters, messages, flushPendingSaves]);

  /**
   * ユーザーが「新規スレッド」ボタンを押したときに呼ばれるハンドラ。
   * - API 呼び出しは行わず、draft スレッドをローカルに追加する。
   * - 初期フィルタは現在選択中のスレッドの値をコピーすることで連続操作をしやすくする。
   */
  const createThread = useCallback(async () => {
    if (!THREAD_FEATURES_ENABLED) {
      throw new Error("現在はスレッド管理機能を利用できません");
    }
    if (threads.length >= MAX_THREADS) {
      throw new Error(`スレッドは最大 ${MAX_THREADS} 件まで作成できます`);
    }
    const draftId = `draft-${generateMessageId()}`;
    const summary: ThreadSummary = {
      id: draftId,
      title: "新しい問い合わせ",
      lastMessage: "まだ会話がありません",
      updatedAt: new Date().toLocaleString(),
      department: filters.departments[0] ?? departmentOptions[0].value,
      documentType: (filters.documentCategories[0] ?? DEFAULT_FILTER_STATE.documentCategories[0]) ?? documentCategoryOptions[0].value,
      isDraft: true
    };
    setThreads((prev) => [summary, ...prev]);
    setActiveThreadId(summary.id);
    setMessages(INITIAL_MESSAGES);
    const initialFilters: ThreadFilterState = {
      mode: filters.mode,
      documentCategories: [...filters.documentCategories],
      departments: [...filters.departments],
      priority: filters.priority
    };
    setFilters(initialFilters);
    setThreadFilters((prev) => ensureDraftEntry({ ...prev, [summary.id]: initialFilters }));
  }, [filters, threads.length]);

  /**
   * サイドバーで別のスレッドが選択されたときに呼び出される。
   * - 選択 ID を更新し、フィルタ辞書にまだ存在しなければ初期値をセットする。
   * - draft の場合は履歴 API を呼ばず、既定メッセージを表示する。
   */
  const selectThreadHandler = useCallback(
    async (thread: ThreadSummary) => {
      if (!THREAD_FEATURES_ENABLED) {
        return;
      }
      setActiveThreadId(thread.id);
      setThreadFilters((prev) => {
        if (prev[thread.id]) {
          return ensureDraftEntry(prev);
        }
        return ensureDraftEntry({ ...prev, [thread.id]: createDefaultFilters() });
      });
      if (thread.isDraft) {
        setMessages(INITIAL_MESSAGES);
        return;
      }
      try {
        const history = await loadChatHistory(thread.id, MAX_HISTORY_LIMIT);
        setMessages(mapHistory(history.items));
        await refreshLatestRatings(thread.id);
      } catch (error) {
        console.error("Failed to load history", error);
        setMessages(INITIAL_MESSAGES);
      }
    },
    [refreshLatestRatings]
  );

  /**
   * 指定したスレッドを削除する。
   * - draft でなければサーバーにも削除リクエストを送る。
   * - 削除後はリストから取り除き、必要であれば次のスレッドを自動選択する。
   * - activeThreadId 自体が削除された場合の挙動を詳細にハンドリングしている点が肝。
   */
  const deleteThreadHandler = useCallback(
    async (threadId: string) => {
      if (!THREAD_FEATURES_ENABLED) {
        return;
      }
      const target = threads.find((thread) => thread.id === threadId);
      if (!target) {
        return;
      }

      if (!target.isDraft) {
        try {
          await deleteThreadRecord(threadId);
        } catch (error) {
          console.error("Failed to delete thread", error);
        }
      }

      const remaining = threads.filter((thread) => thread.id !== threadId);
      setThreads(remaining);
      setThreadFilters((prev) => {
        if (!(threadId in prev)) {
          return ensureDraftEntry(prev);
        }
        const { [threadId]: _removed, ...rest } = prev;
        return ensureDraftEntry(rest);
      });

      if (activeThreadId !== threadId) {
        return;
      }

      if (!remaining.length) {
        setActiveThreadId(null);
        setMessages(INITIAL_MESSAGES);
        setFilters(createDefaultFilters());
        return;
      }

      const nextThread = remaining[0];
      setActiveThreadId(nextThread.id);
      if (nextThread.isDraft) {
        setMessages(INITIAL_MESSAGES);
        return;
      }

      try {
        const history = await loadChatHistory(nextThread.id, MAX_HISTORY_LIMIT);
        setMessages(mapHistory(history.items));
        await refreshLatestRatings(nextThread.id);
      } catch (error) {
        console.error("Failed to load history after deletion", error);
        setMessages(INITIAL_MESSAGES);
      }
    },
    [activeThreadId, deleteThreadRecord, loadChatHistory, refreshLatestRatings, threads]
  );

  /**
   * メッセージに対する Good/Bad 評価をトグルし、サーバーへ送信する。
   * - まずローカル状態を即時に更新し、UI の反映を優先する。
   * - その後にコンテキスト情報を整備してフィードバック API を呼ぶ。
   */
  const rateMessage = useCallback(
    async (messageId: string, rating: "good" | "bad") => {
      const targetIndex = messages.findIndex((message) => message.id === messageId);
      if (targetIndex === -1) {
        return;
      }

      const target = messages[targetIndex];
      if (target.role !== "assistant" || !activeThreadId) {
        return;
      }

      const isCancelling = target.rating === rating;
      const nextRating = isCancelling ? null : rating;

      setMessages((prev) =>
        prev.map((message) =>
          message.id === messageId && message.role === "assistant"
            ? {
              ...message,
              rating: nextRating,
            }
            : message
        )
      );

      // 直前のユーザーメッセージを見つけて文脈情報として保存する。
      const precedingUser = [...messages]
        .slice(0, targetIndex)
        .reverse()
        .find((message) => message.role === "user");

      // 評価対象メッセージの直前 HISTORY_CONTEXT_LENGTH 件を抜き出し、バックエンドの分析に活用する。
      const contextStart = Math.max(0, targetIndex - HISTORY_CONTEXT_LENGTH);
      const contextMessages = messages
        .slice(contextStart, targetIndex)
        .map((message) => ({ role: message.role, content: message.content }));

      const payload: FeedbackPayload = {
        thread_id: activeThreadId,
        assistant_message_id: target.id,
        user_message: precedingUser?.content ?? "",
        assistant_message: target.content,
        rating: isCancelling ? "cancel" : rating,
        ...(contextMessages.length ? { context_messages: contextMessages } : {})
      };

      try {
        await submitFeedbackApi(payload);
      } catch (error) {
        console.error("Failed to submit feedback", error);
      }
    },
    [activeThreadId, messages]
  );

  const toggleDocumentCategory = useCallback(
    (value: string) => {
      // toggleListValue は配列に値が存在すれば削除、なければ追加するユーティリティ。
      updateFiltersState((prev) => ({
        ...prev,
        documentCategories: toggleListValue(prev.documentCategories, value)
      }));
    },
    [updateFiltersState]
  );

  const toggleDepartment = useCallback(
    (value: string) => {
      updateFiltersState((prev) => ({
        ...prev,
        departments: toggleListValue(prev.departments, value)
      }));
    },
    [updateFiltersState]
  );

  const setPriority = useCallback(
    (value: string) => {
      updateFiltersState((prev) => ({ ...prev, priority: value }));
    },
    [updateFiltersState]
  );

  const setAnswerMode = useCallback(
    (mode: AnswerMode) => {
      updateFiltersState((prev) => {
        if (prev.mode === mode) {
          return prev;
        }
        // documents モードへ戻す場合は部門・優先度の絞り込みをリセットする（バックエンドでも無視されるため）。
        const next: ThreadFilterState = {
          ...prev,
          mode,
          documentCategories: [...prev.documentCategories],
          departments: mode === "documents" ? [] : [...prev.departments],
          priority: mode === "documents" ? "balanced" : prev.priority
        };
        return next;
      });
    },
    [updateFiltersState]
  );

  const clearDocumentCategories = useCallback(() => {
    updateFiltersState((prev) => ({ ...prev, documentCategories: [] }));
  }, [updateFiltersState]);

  const clearDepartments = useCallback(() => {
    updateFiltersState((prev) => ({ ...prev, departments: [] }));
  }, [updateFiltersState]);

  const resetPriority = useCallback(() => {
    updateFiltersState((prev) => ({ ...prev, priority: "balanced" }));
  }, [updateFiltersState]);

  // 現在のフィルタ設定を UI 上のバッジ表現へ変換する。useMemo で不要な再計算を防ぐ。
  const filterBadges = useMemo<ChatFilterBadge[]>(() => buildFilterBadges(filters), [filters]);

  const removeFilterBadge = useCallback(
    (type: ChatFilterBadgeType, value: string) => {
      // バッジをクリックしたときは、該当するフィルタだけを解除する。
      switch (type) {
        case "mode":
          setAnswerMode("documents");
          break;
        case "department":
          toggleDepartment(value);
          break;
        case "document":
          toggleDocumentCategory(value);
          break;
        case "priority":
          resetPriority();
          break;
      }
    },
    [setAnswerMode, toggleDepartment, toggleDocumentCategory, resetPriority]
  );

  const resetAllFilters = useCallback(() => {
    updateFiltersState(() => createDefaultFilters());
  }, [updateFiltersState]);

  return {
    threads,
    activeThreadId,
    activeThread,
    messages,
    input,
    isSending,
    threadFeaturesEnabled: THREAD_FEATURES_ENABLED,
    statusLabel,
    filterOptions,
    filters,
    maxThreads: MAX_THREADS,
    hasThreads,
    isInitialized: initialized,
    sendCurrentMessage,
    setInput,
    createThread,
    selectThread: selectThreadHandler,
    deleteThread: deleteThreadHandler,
    rateMessage,
    toggleDocumentCategory,
    toggleDepartment,
    setPriority,
    setAnswerMode,
    resetAllFilters,
    clearDocumentCategories,
    clearDepartments,
    resetPriority,
    filterBadges,
    removeFilterBadge
  };
}
