"use client";

import { nanoid } from "nanoid";
import {
  DEPARTMENT_OPTIONS,
  DOCUMENT_CATEGORY_OPTIONS,
  PRIORITY_OPTIONS
} from "@/features/chat/constants/filterOptions";
import type {
  ChatApiCitation,
  ChatAskPayload,
  ChatAskPayloadFilters,
  ChatFilterBadge,
  ChatFilterBadgeType,
  ChatHistoryItem,
  Message,
  ThreadApiEntity,
  ThreadFilterState,
  ThreadSummary
} from "@/shared/types/chat";

const departmentOptions = DEPARTMENT_OPTIONS;
const documentCategoryOptions = DOCUMENT_CATEGORY_OPTIONS;

/** チャット画面で初期表示するウェルカムメッセージ。 */
export const INITIAL_MESSAGES: Message[] = [
  {
    id: "welcome",
    role: "assistant",
    content: "こんにちは。検索したい内容や確認したい規程を入力してください。"
  }
];

/**
 * ユーザー入力からスレッドタイトルを導出する。
 * - 空文字列の場合は「新しい問い合わせ」という既定タイトルをつける。
 * - 長過ぎる場合は 40 文字で打ち切り点を追加する。
 */
export function deriveThreadTitle(text: string): string {
  const stripped = text.trim();
  if (!stripped) {
    return "新しい問い合わせ";
  }
  const MAX_LENGTH = 40;
  return stripped.length > MAX_LENGTH ? `${stripped.slice(0, MAX_LENGTH)}…` : stripped;
}

/**
 * メッセージIDを UUID 形式で生成する。
 * - ブラウザの crypto.randomUUID が使える場合はそれを利用。
 * - 互換環境では getRandomValues で RFC4122 風の文字列を生成する。
 * - それも不可の場合は nanoid で一意性を担保する。
 */
export function generateMessageId(): string {
  const cryptoObj = typeof globalThis !== "undefined" ? (globalThis.crypto as Crypto | undefined) : undefined;
  if (cryptoObj?.randomUUID) {
    return cryptoObj.randomUUID();
  }
  if (cryptoObj?.getRandomValues) {
    const bytes = new Uint8Array(16);
    cryptoObj.getRandomValues(bytes);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const toHex = (b: number) => b.toString(16).padStart(2, "0");
    return (
      `${toHex(bytes[0])}${toHex(bytes[1])}${toHex(bytes[2])}${toHex(bytes[3])}-` +
      `${toHex(bytes[4])}${toHex(bytes[5])}-` +
      `${toHex(bytes[6])}${toHex(bytes[7])}-` +
      `${toHex(bytes[8])}${toHex(bytes[9])}-` +
      `${toHex(bytes[10])}${toHex(bytes[11])}${toHex(bytes[12])}${toHex(bytes[13])}${toHex(bytes[14])}${toHex(bytes[15])}`
    );
  }
  return `uuid-${nanoid()}`;
}

/**
 * API から受け取ったスレッド情報を UI 表示用の ThreadSummary へ変換する。
 */
export function mapThreadSummary(
  thread: Partial<ThreadApiEntity> & { id: string },
  overrides: Partial<ThreadSummary> = {}
): ThreadSummary {
  const defaultDepartment = departmentOptions[0]?.value ?? "";
  const defaultDocCategory = documentCategoryOptions[0]?.value ?? "";
  return {
    id: thread.id,
    title: overrides.title ?? thread.title ?? "新しい問い合わせ",
    lastMessage: overrides.lastMessage ?? "まだ会話がありません",
    updatedAt: overrides.updatedAt ?? new Date(thread.updated_at ?? Date.now()).toLocaleString(),
    department: overrides.department ?? defaultDepartment,
    documentType: overrides.documentType ?? defaultDocCategory,
    isDraft: overrides.isDraft ?? false
  };
}

/**
 * バックエンドからの引用情報を UI で扱いやすい構造に変換する。
 */
export function mapApiCitations(items?: ChatApiCitation[] | null) {
  if (!items || items.length === 0) return [];
  return items
    .filter((citation) => Boolean(citation.document_id || citation.faq_id))
    .map((citation) => ({
      documentId: citation.document_id ? String(citation.document_id) : "",
      chunkId: citation.chunk_id ? String(citation.chunk_id) : nanoid(),
      title: citation.title ?? undefined,
      snippet: citation.snippet ?? undefined,
      faqId: citation.faq_id ? String(citation.faq_id) : undefined,
      score: citation.score ?? undefined,
      source: citation.source ?? undefined,
      sourceUri: citation.source_uri ?? undefined
    }));
}

/** UI 側で保持している引用情報をサーバーへ送る形式に戻す。 */
export function serializeCitations(citations?: Message["citations"]): ChatApiCitation[] {
  if (!citations || citations.length === 0) {
    return [];
  }
  return citations.map((citation) => ({
    document_id: citation.documentId,
    chunk_id: citation.chunkId,
    faq_id: citation.faqId ?? null,
    title: citation.title ?? null,
    snippet: citation.snippet ?? null,
    score: citation.score ?? null,
    source: citation.source ?? null,
    source_uri: citation.sourceUri ?? null
  }));
}

/**
 * LLM へ渡す会話履歴（直近 N 件）を生成する。
 * - user/assistant のみを対象にし、system メッセージ等は除外する。
 */
export function buildHistoryPayload(
  messages: Message[],
  limit: number
): ChatAskPayload["history"] {
  return messages
    .filter((message) => message.role === "user" || message.role === "assistant")
    .slice(-limit)
    .map((message) => ({ role: message.role, content: message.content }));
}

/** FastAPI の履歴レスポンスを UI 表示用の Message 配列へマップする。 */
export function mapHistory(items: ChatHistoryItem[]): Message[] {
  if (!items.length) {
    return INITIAL_MESSAGES;
  }
  return items.map((item) => ({
    id: String(item.id),
    role: item.role,
    content: item.content ?? "",
    queryId: item.query_id ?? undefined,
    rating: null,
    citations: mapApiCitations(item.citations),
    createdAt: item.created_at ? new Date(item.created_at).toLocaleString() : undefined
  }));
}

/**
 * 現在のフィルタ状態を /chat/ask の filters ペイロードへ詰め替える。
 * - documents モードの場合は document_category のみ送信。
 * - all モードの場合は departments/priority も付与する。
 */
export function buildFilterPayload(filters: ThreadFilterState): ChatAskPayloadFilters | undefined {
  const payload: ChatAskPayloadFilters = {
    answer_mode: filters.mode
  };

  if (filters.documentCategories.length) {
    payload.document_category = filters.documentCategories.map(
      (value) => documentCategoryOptions.find((option) => option.value === value)?.label ?? value
    );
  }
  if (filters.mode === "all") {
    if (filters.departments.length) {
      payload.department = filters.departments;
    }
    if (filters.priority && filters.priority !== "balanced") {
      payload.priority = filters.priority;
    }
  }

  return payload;
}

/** 画面上部のバッジ表示用にフィルタ状態を整形するヘルパー。 */
export function buildFilterBadges(filters: ThreadFilterState): ChatFilterBadge[] {
  const badges: ChatFilterBadge[] = [
    ...mapToBadges(filters.departments, departmentOptions, "department"),
    ...mapToBadges(filters.documentCategories, documentCategoryOptions, "document")
  ];

  if (filters.mode === "all") {
    badges.unshift({ type: "mode", value: "all", label: "なんでも回答" });
  }

  if (filters.priority !== "balanced") {
    const priorityLabel = PRIORITY_OPTIONS.find((option) => option.value === filters.priority)?.label ?? filters.priority;
    badges.push({ type: "priority", value: filters.priority, label: priorityLabel });
  }

  return badges;
}

/** mapToBadges: value の配列と選択肢一覧からバッジを生成する。 */
function mapToBadges(
  values: string[],
  options: readonly { value: string; label: string }[],
  type: ChatFilterBadgeType
): ChatFilterBadge[] {
  return values.map((value) => {
    const label = options.find((option) => option.value === value)?.label ?? value;
    return { value, label, type };
  });
}
