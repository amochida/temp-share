"use client";

import { DEFAULT_DOCUMENT_CATEGORY_SELECTION } from "@/features/chat/constants/filterOptions";
import type { AnswerMode, ThreadFilterState } from "@/shared/types/chat";

/** draft スレッド（未保存状態）のフィルタを区別するための特殊キー。 */
export const DRAFT_FILTER_KEY = "__draft__";

// フィルタ情報を localStorage に保存する際のキー。環境（dev/prod）ごとに接尾辞を変えている。
const THREAD_FILTER_STORAGE_NAMESPACE = "sana-thread-filters";
const THREAD_FILTER_STORAGE_VERSION = "v1";
const THREAD_FILTER_RUNTIME_ENV = (process.env.NEXT_PUBLIC_APP_ENV ?? process.env.NODE_ENV ?? "development").toLowerCase();
const THREAD_FILTER_ENV_SUFFIX = THREAD_FILTER_RUNTIME_ENV === "production" ? "prod" : "dev";
export const THREAD_FILTER_STORAGE_KEY = `${THREAD_FILTER_STORAGE_NAMESPACE}-${THREAD_FILTER_ENV_SUFFIX}-${THREAD_FILTER_STORAGE_VERSION}`;

const DEFAULT_PRIORITY = "balanced";
const DEFAULT_DOCUMENTS_MODE: AnswerMode = "documents";
const DEFAULT_DOCUMENT_CATEGORIES = [...DEFAULT_DOCUMENT_CATEGORY_SELECTION];

export const DEFAULT_FILTER_STATE: ThreadFilterState = {
  mode: DEFAULT_DOCUMENTS_MODE,
  documentCategories: DEFAULT_DOCUMENT_CATEGORIES,
  departments: [],
  priority: DEFAULT_PRIORITY
};

/** localStorage から復元したフィルタ辞書と、実際に読み込んだキー。 */
export interface LoadedFilterStore {
  store: ThreadFilterStore;
  sourceKey: string | null;
}

export type ThreadFilterStore = Record<string, ThreadFilterState>;

/** `ThreadFilterState` の初期値を生成する。 */
export function createDefaultFilters(): ThreadFilterState {
  return {
    mode: DEFAULT_DOCUMENTS_MODE,
    documentCategories: [...DEFAULT_DOCUMENT_CATEGORY_SELECTION],
    departments: [],
    priority: DEFAULT_PRIORITY
  };
}

/**
 * localStorage からフィルタの辞書を復元する。
 * - SSR では window が無いので空の draft のみ返す。
 */
export function loadFilterStore(): LoadedFilterStore {
  if (typeof window === "undefined") {
    return { store: { [DRAFT_FILTER_KEY]: createDefaultFilters() }, sourceKey: null };
  }

  const store = loadFromKey(THREAD_FILTER_STORAGE_KEY);
  if (store) {
    return { store, sourceKey: THREAD_FILTER_STORAGE_KEY };
  }

  return { store: { [DRAFT_FILTER_KEY]: createDefaultFilters() }, sourceKey: null };
}

/** 現在の辞書を localStorage へ書き戻す。 */
export function saveFilterStore(store: ThreadFilterStore): boolean {
  if (typeof window === "undefined") {
    return false;
  }
  try {
    const sanitized = sanitizeFilterStore(store);
    window.localStorage.setItem(THREAD_FILTER_STORAGE_KEY, JSON.stringify(sanitized));
    return true;
  } catch (error) {
    console.warn("Failed to persist filters", error);
    return false;
  }
}

/** 古いキーを削除するためのヘルパー。 */
export function removeStorageKey(key: string): void {
  if (typeof window === "undefined") {
    return;
  }
  try {
    window.localStorage.removeItem(key);
  } catch (error) {
    console.warn(`Failed to remove filter cache ${key}`, error);
  }
}

/**
 * 下書き用のキーが必ず存在するように辞書を補正する。
 * - フィルタ UI では draft 状態から操作を始めるため欠かせない。
 */
export function ensureDraftEntry(store: ThreadFilterStore): ThreadFilterStore {
  if (store[DRAFT_FILTER_KEY]) {
    return store;
  }
  return { ...store, [DRAFT_FILTER_KEY]: createDefaultFilters() };
}

/** localStorage の生データを型安全な ThreadFilterState へ変換する。 */
export function migrateFilterEntry(entry: any): ThreadFilterState {
  if (!entry || typeof entry !== "object" || !Array.isArray(entry.documentCategories)) {
    return createDefaultFilters();
  }

  const docCategories = entry.documentCategories.length ? entry.documentCategories : [];
  const modeValue = typeof entry.mode === "string" ? entry.mode : DEFAULT_DOCUMENTS_MODE;
  const normalizedMode: AnswerMode = modeValue === "documents" || modeValue === "policy" ? DEFAULT_DOCUMENTS_MODE : "all";
  return {
    mode: normalizedMode,
    documentCategories: docCategories,
    departments: Array.isArray(entry.departments) ? entry.departments : [],
    priority: typeof entry.priority === "string" ? entry.priority : DEFAULT_PRIORITY
  };
}

/** localStorage から JSON を読み出し、辞書として復元する。 */
function loadFromKey(key: string): ThreadFilterStore | null {
  if (typeof window === "undefined") {
    return null;
  }
  const stored = window.localStorage.getItem(key);
  if (!stored) {
    return null;
  }

  try {
    const parsed = JSON.parse(stored) as Record<string, any>;
    const migrated = Object.fromEntries(
      Object.entries(parsed).map(([entryKey, value]) => [entryKey, migrateFilterEntry(value)])
    );
    return ensureDraftEntry(migrated);
  } catch (error) {
    console.warn(`Failed to parse cached filters from ${key}`, error);
    return null;
  }
}

/** 保存時に初期値と同じエントリを間引き、無駄な書き込みを避ける。 */
function sanitizeFilterStore(store: ThreadFilterStore): ThreadFilterStore {
  const entries = Object.entries(store).filter(([, value]) => {
    if (!value) return false;
    return (
      value.mode !== DEFAULT_DOCUMENTS_MODE ||
      value.documentCategories.length > 0 ||
      value.departments.length > 0 ||
      value.priority !== DEFAULT_PRIORITY
    );
  });

  const sanitized = Object.fromEntries(entries);
  return ensureDraftEntry(sanitized);
}
