"use client";

/**
 * 複数選択可能なフィルタセクションを共通化したコンポーネント。
 * ラベル・クリアボタン・チェックボックス群の構成がスタッフ画面で繰り返し登場するため、
 * 同じ見た目と挙動を保ったまま再利用できるようにしている。
 */
import type { FC } from "react";
import { TERTIARY_TEXT_BUTTON_CLASS } from "@/shared/styles/classNames";

/** フィルタで扱う選択肢の定義。 */
export interface FilterOption {
  value: string;
  label: string;
}

interface SelectableFilterSectionProps {
  /** セクションタイトル（例: 部門コード）。 */
  title: string;
  /** 表示する選択肢の一覧。 */
  options: readonly FilterOption[];
  /** 現在選択されている値。 */
  selected: readonly string[];
  /** チェックボックスが切り替わったときに呼び出される。 */
  onToggle: (value: string) => void;
  /** クリアボタン押下時のハンドラ。 */
  onClear: () => void;
  /** 親レイアウトに合わせて列幅を調整したいときに指定。 */
  className?: string;
}

const SelectableFilterSection: FC<SelectableFilterSectionProps> = ({ title, options, selected, onToggle, onClear, className }) => {
  return (
    <section className={`space-y-1 ${className ?? ""}`}>
      <header className="flex items-center justify-between">
        <span className="font-semibold text-content-secondary">{title}</span>
        <button type="button" className={TERTIARY_TEXT_BUTTON_CLASS} onClick={onClear}>
          クリア
        </button>
      </header>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <label key={option.value} className="flex items-center gap-1 text-sm text-content-tertiary">
            <input
              type="checkbox"
              className="accent-brand-primary"
              checked={selected.includes(option.value)}
              onChange={() => onToggle(option.value)}
            />
            <span>{option.label}</span>
          </label>
        ))}
      </div>
    </section>
  );
};

export default SelectableFilterSection;
