"use client";

/**
 * ドキュメント管理画面から呼び出す API ライブラリ。
 * 生成された OpenAPI 型に基づき、FastAPI の REST エンドポイントを直接叩く。
 */
import { apiJsonRequest, apiRequest, ApiError, encodeQueryParams } from "@/shared/api/http";
import type {
  DocumentListResponse,
  DocumentRecord,
  DocumentSearchParams,
  DocumentUpdatePayload,
  DocumentUploadResponse
} from "@/shared/types/staff";

/** `DocumentUpdatePayload` と差し替えファイルから FormData を構築する。 */
function buildDocumentFormData(payload: DocumentUpdatePayload, file: File): FormData {
  const formData = new FormData();
  formData.append("title", payload.title);
  if (payload.department_code !== undefined && payload.department_code !== null) {
    formData.append("department_code", payload.department_code);
  }
  if (payload.document_type) formData.append("document_type", payload.document_type);
  formData.append("registration_type", payload.registration_type);
  formData.append("is_auto_import_target", String(payload.is_auto_import_target));
  if (payload.source_uri) formData.append("source_uri", payload.source_uri);
  formData.append("public_scope", payload.public_scope);
  if (payload.status) formData.append("status", payload.status);
  formData.append("file", file);
  return formData;
}

/**
 * ドキュメント検索。
 * GET パラメータでフィルタ・ページネーションを渡して FastAPI を直接呼ぶ。
 */
export function fetchDocuments(params: DocumentSearchParams = {}): Promise<DocumentListResponse> {
  const search = buildDocumentSearchParams(params);
  const path = `/documents${encodeQueryParams(search)}`;
  return apiRequest<DocumentListResponse>(path).catch((error) => {
    throw asStaffApiError(error);
  });
}

/** ドキュメント詳細を取得する。詳細画面の初期描画で利用。 */
export function fetchDocument(documentId: string): Promise<DocumentRecord> {
  return apiRequest<DocumentRecord>(`/documents/${encodeURIComponent(documentId)}`).catch((error) => {
    throw asStaffApiError(error);
  });
}

/** 新規ドキュメントをアップロードする。ファイル本体の multipart 送信を担当。 */
export function createDocument(formData: FormData): Promise<DocumentUploadResponse> {
  return apiRequest<DocumentUploadResponse>("/documents/upload", {
    method: "POST",
    body: formData
  }).catch((error) => {
    throw asStaffApiError(error);
  });
}

/**
 * ドキュメントのメタ情報を更新する。必要に応じてファイル差し替えも同じ関数で扱う。
 */
export function updateDocument(
  documentId: string,
  payload: DocumentUpdatePayload,
  file?: File
): Promise<DocumentRecord> {
  if (file) {
    const formData = buildDocumentFormData(payload, file);
    return apiRequest<DocumentRecord>(`/documents/${encodeURIComponent(documentId)}/replace`, {
      method: "PUT",
      body: formData
    }).catch((error) => {
      throw asStaffApiError(error);
    });
  }

  return apiJsonRequest<DocumentRecord>(`/documents/${encodeURIComponent(documentId)}`, payload, {
    method: "PUT"
  }).catch((error) => {
    throw asStaffApiError(error);
  });
}

/** ドキュメントを削除する。成功時は 204 を想定し、副作用は返さない。 */
export function deleteDocument(documentId: string): Promise<void> {
  return apiRequest<void>(`/documents/${encodeURIComponent(documentId)}`, { method: "DELETE" }).catch((error) => {
    throw asStaffApiError(error);
  });
}

function appendList(search: URLSearchParams, key: string, values?: string[]) {
  values?.forEach((value) => {
    if (value) {
      search.append(key, value);
    }
  });
}

function buildDocumentSearchParams(params: DocumentSearchParams): URLSearchParams | undefined {
  const search = new URLSearchParams();
  appendList(search, "department_codes", params.department_codes);
  appendList(search, "document_types", params.document_types);
  appendList(search, "public_scopes", params.public_scopes);
  appendList(search, "statuses", params.statuses);
  if (params.q) {
    search.set("q", params.q);
  }
  if (params.semantic_query) {
    search.set("semantic_query", params.semantic_query);
  }
  if (typeof params.limit === "number") {
    search.set("limit", String(params.limit));
  }
  if (typeof params.offset === "number") {
    search.set("offset", String(params.offset));
  }
  return search.toString() ? search : undefined;
}

function asStaffApiError(error: unknown): Error {
  if (error instanceof ApiError) {
    return new Error(error.body || error.message);
  }
  if (error instanceof Error) {
    return error;
  }
  return new Error("unexpected_error");
}
