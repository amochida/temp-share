"use client";

/**
 * ドキュメント管理画面の検索ロジック。
 * 共通のページネーション制御フック（usePaginatedSearch）を利用して
 * 冗長な状態管理を排除し、フィルタ操作のみに集中できるよう整理する。
 */
import { fetchDocuments } from "@/features/staff/documents/api/documentsApi";
import type {
  DocumentRecord,
  DocumentSearchParams,
  DocumentStatus,
  PublicScope
} from "@/shared/types/staff";
import { usePaginatedSearch } from "@/shared/hooks/usePaginatedSearch";
import { toggleListValue } from "@/shared/utils/arrayHelpers";
import { useCallback, type Dispatch, type FormEvent, type SetStateAction } from "react";

export interface DocumentSearchFormState {
  department_codes: string[];
  document_types: string[];
  public_scopes: PublicScope[];
  statuses: DocumentStatus[];
  q: string;
  semantic_query: string;
}

const DEFAULT_PAGE_SIZE = 20;

export const createDocumentSearchInitialState = (): DocumentSearchFormState => ({
  department_codes: [],
  document_types: [],
  public_scopes: [],
  statuses: [],
  q: "",
  semantic_query: ""
});

/**
 * formState をそのまま代入すると参照が共有されてしまうため、
 * usePaginatedSearch で扱いやすいよう深めのコピーを返す。
 */
const cloneDocumentState = (state: DocumentSearchFormState): DocumentSearchFormState => ({
  ...state,
  department_codes: [...state.department_codes],
  document_types: [...state.document_types],
  public_scopes: [...state.public_scopes],
  statuses: [...state.statuses]
});

export interface UseDocumentSearchResult {
  formState: DocumentSearchFormState;
  setFormState: Dispatch<SetStateAction<DocumentSearchFormState>>;
  appliedState: DocumentSearchFormState;
  items: DocumentRecord[];
  total: number;
  loading: boolean;
  error: string | null;
  handleSubmit: (event?: FormEvent<HTMLFormElement>) => void;
  loadMore: () => void;
  hasMore: boolean;
  toggleDepartment: (value: string) => void;
  toggleDocumentType: (value: string) => void;
  togglePublicScope: (value: PublicScope) => void;
  toggleStatus: (value: DocumentStatus) => void;
  clearDepartments: () => void;
  clearDocumentTypes: () => void;
  clearPublicScopes: () => void;
  clearStatuses: () => void;
}

export function useDocumentSearch(pageSize: number = DEFAULT_PAGE_SIZE): UseDocumentSearchResult {
  const buildParams = useCallback(
    (state: DocumentSearchFormState): DocumentSearchParams => ({
      department_codes: state.department_codes.length ? state.department_codes : undefined,
      document_types: state.document_types.length ? state.document_types : undefined,
      public_scopes: state.public_scopes.length ? state.public_scopes : undefined,
      statuses: state.statuses.length ? state.statuses : undefined,
      q: state.q || undefined,
      semantic_query: state.semantic_query || undefined
    }),
    []
  );

  const fetcher = useCallback(
    (state: DocumentSearchFormState, { offset, limit }: { offset: number; limit: number }) =>
      fetchDocuments({ ...buildParams(state), offset, limit }),
    [buildParams]
  );

  const {
    formState,
    setFormState,
    appliedState,
    items,
    total,
    loading,
    error,
    handleSubmit,
    loadMore,
    hasMore
  } = usePaginatedSearch<DocumentSearchFormState, DocumentRecord>({
    initialState: createDocumentSearchInitialState,
    fetcher,
    pageSize,
    cloneState: cloneDocumentState
  });

  /** 部門チェックボックスのオン/オフを切り替える。 */
  const toggleDepartment = useCallback((value: string) => {
    setFormState((prev) => ({ ...prev, department_codes: toggleListValue(prev.department_codes, value) }));
  }, [setFormState]);

  /** ドキュメント種別のチェック状態を更新。 */
  const toggleDocumentType = useCallback((value: string) => {
    setFormState((prev) => ({ ...prev, document_types: toggleListValue(prev.document_types, value) }));
  }, [setFormState]);

  /** 公開範囲のラベルをクリックした際のトグル。 */
  const togglePublicScope = useCallback((value: PublicScope) => {
    setFormState((prev) => ({ ...prev, public_scopes: toggleListValue(prev.public_scopes, value) }));
  }, [setFormState]);

  /** ステータス項目のトグル。 */
  const toggleStatus = useCallback((value: DocumentStatus) => {
    setFormState((prev) => ({ ...prev, statuses: toggleListValue(prev.statuses, value) }));
  }, [setFormState]);

  const clearDepartments = useCallback(() => {
    setFormState((prev) => ({ ...prev, department_codes: [] }));
  }, [setFormState]);

  const clearDocumentTypes = useCallback(() => {
    setFormState((prev) => ({ ...prev, document_types: [] }));
  }, [setFormState]);

  const clearPublicScopes = useCallback(() => {
    setFormState((prev) => ({ ...prev, public_scopes: [] }));
  }, [setFormState]);

  const clearStatuses = useCallback(() => {
    setFormState((prev) => ({ ...prev, statuses: [] }));
  }, [setFormState]);

  return {
    formState,
    setFormState,
    appliedState,
    items,
    total,
    loading,
    error,
    handleSubmit,
    loadMore,
    hasMore,
    toggleDepartment,
    toggleDocumentType,
    togglePublicScope,
    toggleStatus,
    clearDepartments,
    clearDocumentTypes,
    clearPublicScopes,
    clearStatuses
  };
}
