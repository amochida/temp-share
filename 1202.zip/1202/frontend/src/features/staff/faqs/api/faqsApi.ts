"use client";

/**
 * FAQ 管理画面専用の API ラッパー。
 * FastAPI の REST エンドポイントをそのまま叩き、画面からは目的ベースで利用できるように整理する。
 */
import { apiJsonRequest, apiRequest, ApiError, encodeQueryParams } from "@/shared/api/http";
import type { FAQListResponse, FAQPayload, FAQRecord, FAQSearchParams, FAQUploadResponse } from "@/shared/types/staff";

/** FAQ 検索。 */
export function fetchFaqs(params: FAQSearchParams = {}): Promise<FAQListResponse> {
  const search = buildFaqSearchParams(params);
  const path = `/faqs${encodeQueryParams(search)}`;
  return apiRequest<FAQListResponse>(path).catch((error) => {
    throw asFaqError(error);
  });
}

/** FAQ 詳細を取得する。詳細画面の初期化で利用。 */
export function fetchFaq(faqId: string): Promise<FAQRecord> {
  return apiRequest<FAQRecord>(`/faqs/${encodeURIComponent(faqId)}`).catch((error) => {
    throw asFaqError(error);
  });
}

/** FAQ を新規登録する。フォームデータで送信。 */
export function createFaq(payload: FAQPayload): Promise<FAQUploadResponse> {
  const body = buildFaqFormBody(payload);
  return apiRequest<FAQUploadResponse>("/faqs/upload", {
    method: "POST",
    body
  }).catch((error) => {
    throw asFaqError(error);
  });
}

/** FAQ を更新する。 */
export function updateFaq(faqId: string, payload: FAQPayload): Promise<FAQRecord> {
  return apiJsonRequest<FAQRecord>(`/faqs/${encodeURIComponent(faqId)}`, payload, {
    method: "PUT"
  }).catch((error) => {
    throw asFaqError(error);
  });
}

/** FAQ を削除する。成功時 204 を想定し、本文は利用しない。 */
export function deleteFaq(faqId: string): Promise<void> {
  return apiRequest<void>(`/faqs/${encodeURIComponent(faqId)}`, { method: "DELETE" }).catch((error) => {
    throw asFaqError(error);
  });
}

function buildFaqSearchParams(params: FAQSearchParams): URLSearchParams | undefined {
  const search = new URLSearchParams();
  appendList(search, "department_codes", params.department_codes);
  appendList(search, "categories", params.categories);
  appendList(search, "faq_types", params.faq_types);
  appendList(search, "public_scopes", params.public_scopes);
  appendList(search, "statuses", params.statuses);
  if (params.q) {
    search.set("q", params.q);
  }
  if (params.semantic_query) {
    search.set("semantic_query", params.semantic_query);
  }
  if (typeof params.limit === "number") {
    search.set("limit", String(params.limit));
  }
  if (typeof params.offset === "number") {
    search.set("offset", String(params.offset));
  }
  return search.toString() ? search : undefined;
}

function appendList(search: URLSearchParams, key: string, values?: string[]) {
  values?.forEach((value) => {
    if (value) {
      search.append(key, value);
    }
  });
}

function buildFaqFormBody(payload: FAQPayload): URLSearchParams {
  const body = new URLSearchParams();
  body.set("question", payload.question);
  body.set("answer", payload.answer);
  if (payload.department_code) {
    body.set("department_code", payload.department_code);
  }
  if (payload.category) {
    body.set("category", payload.category);
  }
  if (payload.faq_type) {
    body.set("faq_type", payload.faq_type);
  }
  if (payload.summary) {
    body.set("summary", payload.summary);
  }
  body.set("public_scope", payload.public_scope ?? "internal");
  body.set("status_value", payload.status ?? "draft");
  return body;
}

function asFaqError(error: unknown): Error {
  if (error instanceof ApiError) {
    return new Error(error.body || error.message);
  }
  if (error instanceof Error) {
    return error;
  }
  return new Error("unexpected_error");
}
