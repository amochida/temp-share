"use client";

/**
 * FAQ 管理画面の検索フック。usePaginatedSearch を利用して
 * ページネーションやエラーハンドリングの重複を排除している。
 */
import { fetchFaqs } from "@/features/staff/faqs/api/faqsApi";
import type { FAQRecord, FAQScope, FAQSearchParams, FAQStatus } from "@/shared/types/staff";
import { usePaginatedSearch } from "@/shared/hooks/usePaginatedSearch";
import { toggleListValue } from "@/shared/utils/arrayHelpers";
import { useCallback, type Dispatch, type FormEvent, type SetStateAction } from "react";

export interface FaqSearchFormState {
  department_codes: string[];
  categories: string[];
  faq_types: string[];
  public_scopes: FAQScope[];
  statuses: FAQStatus[];
  q: string;
  semantic_query: string;
}

const DEFAULT_PAGE_SIZE = 20;

export const createFaqSearchInitialState = (): FaqSearchFormState => ({
  department_codes: [],
  categories: [],
  faq_types: [],
  public_scopes: [],
  statuses: [],
  q: "",
  semantic_query: ""
});

/** usePaginatedSearch で安全に扱うため、配列を都度コピーするヘルパー。 */
const cloneFaqState = (state: FaqSearchFormState): FaqSearchFormState => ({
  ...state,
  department_codes: [...state.department_codes],
  categories: [...state.categories],
  faq_types: [...state.faq_types],
  public_scopes: [...state.public_scopes],
  statuses: [...state.statuses]
});

export interface UseFaqSearchResult {
  formState: FaqSearchFormState;
  setFormState: Dispatch<SetStateAction<FaqSearchFormState>>;
  appliedState: FaqSearchFormState;
  items: FAQRecord[];
  total: number;
  loading: boolean;
  error: string | null;
  handleSubmit: (event?: FormEvent<HTMLFormElement>) => void;
  loadMore: () => void;
  hasMore: boolean;
  toggleDepartment: (value: string) => void;
  toggleCategory: (value: string) => void;
  toggleFaqType: (value: string) => void;
  togglePublicScope: (value: FAQScope) => void;
  toggleStatus: (value: FAQStatus) => void;
  clearDepartments: () => void;
  clearCategories: () => void;
  clearFaqTypes: () => void;
  clearPublicScopes: () => void;
  clearStatuses: () => void;
}

export function useFaqSearch(pageSize: number = DEFAULT_PAGE_SIZE): UseFaqSearchResult {
  const buildParams = useCallback(
    (state: FaqSearchFormState): FAQSearchParams => ({
      department_codes: state.department_codes.length ? state.department_codes : undefined,
      categories: state.categories.length ? state.categories : undefined,
      faq_types: state.faq_types.length ? state.faq_types : undefined,
      public_scopes: state.public_scopes.length ? state.public_scopes : undefined,
      statuses: state.statuses.length ? state.statuses : undefined,
      q: state.q || undefined,
      semantic_query: state.semantic_query || undefined
    }),
    []
  );

  const fetcher = useCallback(
    (state: FaqSearchFormState, { offset, limit }: { offset: number; limit: number }) =>
      fetchFaqs({ ...buildParams(state), offset, limit }),
    [buildParams]
  );

  const {
    formState,
    setFormState,
    appliedState,
    items,
    total,
    loading,
    error,
    handleSubmit,
    loadMore,
    hasMore
  } = usePaginatedSearch<FaqSearchFormState, FAQRecord>({
    initialState: createFaqSearchInitialState,
    fetcher,
    pageSize,
    cloneState: cloneFaqState
  });

  /** 部門チェックボックスで呼び出されるトグル。 */
  const toggleDepartment = useCallback((value: string) => {
    setFormState((prev) => ({ ...prev, department_codes: toggleListValue(prev.department_codes, value) }));
  }, [setFormState]);

  /** FAQカテゴリの選択状態を切り替える。 */
  const toggleCategory = useCallback((value: string) => {
    setFormState((prev) => ({ ...prev, categories: toggleListValue(prev.categories, value) }));
  }, [setFormState]);

  /** FAQ種別（手続き/規則など）のトグル。 */
  const toggleFaqType = useCallback((value: string) => {
    setFormState((prev) => ({ ...prev, faq_types: toggleListValue(prev.faq_types, value) }));
  }, [setFormState]);

  /** 公開範囲のチェック状態を更新。 */
  const togglePublicScope = useCallback((value: FAQScope) => {
    setFormState((prev) => ({ ...prev, public_scopes: toggleListValue(prev.public_scopes, value) }));
  }, [setFormState]);

  /** ステータス（公開中/下書きなど）のトグル。 */
  const toggleStatus = useCallback((value: FAQStatus) => {
    setFormState((prev) => ({ ...prev, statuses: toggleListValue(prev.statuses, value) }));
  }, [setFormState]);

  const clearDepartments = useCallback(() => {
    setFormState((prev) => ({ ...prev, department_codes: [] }));
  }, [setFormState]);

  const clearCategories = useCallback(() => {
    setFormState((prev) => ({ ...prev, categories: [] }));
  }, [setFormState]);

  const clearFaqTypes = useCallback(() => {
    setFormState((prev) => ({ ...prev, faq_types: [] }));
  }, [setFormState]);

  const clearPublicScopes = useCallback(() => {
    setFormState((prev) => ({ ...prev, public_scopes: [] }));
  }, [setFormState]);

  const clearStatuses = useCallback(() => {
    setFormState((prev) => ({ ...prev, statuses: [] }));
  }, [setFormState]);

  return {
    formState,
    setFormState,
    appliedState,
    items,
    total,
    loading,
    error,
    handleSubmit,
    loadMore,
    hasMore,
    toggleDepartment,
    toggleCategory,
    toggleFaqType,
    togglePublicScope,
    toggleStatus,
    clearDepartments,
    clearCategories,
    clearFaqTypes,
    clearPublicScopes,
    clearStatuses
  };
}
