/**
 * PostCSS のプラグイン定義。
 * Tailwind CSS が提供するネスティング対応プラグインを明示的に読み込むことで、
 * Docker ビルド時に `postcss-nesting` を参照して失敗する問題を防ぐ。
 */

module.exports = {
  plugins: {
    "tailwindcss/nesting": {},
    tailwindcss: {},
    autoprefixer: {}
  }
};
