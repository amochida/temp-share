import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const requireModule = createRequire(import.meta.url);

const [command = "build", ...rest] = process.argv.slice(2);

const env = { ...process.env };
const wasmPath = requireModule.resolve("@next/swc-wasm-nodejs/wasm_bg.wasm");
env.SWC_BINARY_PATH = env.SWC_BINARY_PATH ?? wasmPath;
env.NEXT_FORCE_SWC_WASM = env.NEXT_FORCE_SWC_WASM ?? "1";
const setupRelative = path.relative(process.cwd(), path.join(__dirname, "setup-swc-wasm.cjs"));
const setupHook = setupRelative.startsWith(".") ? setupRelative : `./${setupRelative}`;
const requireFlag = `--require ${setupHook}`;
env.NODE_OPTIONS = env.NODE_OPTIONS ? `${env.NODE_OPTIONS} ${requireFlag}` : requireFlag;

const nextBin = path.join(process.cwd(), "node_modules", ".bin", process.platform === "win32" ? "next.cmd" : "next");
const child = spawn(nextBin, [command, ...rest], {
  stdio: "inherit",
  env,
  shell: process.platform === "win32"
});

child.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
  } else {
    process.exit(code ?? 0);
  }
});
