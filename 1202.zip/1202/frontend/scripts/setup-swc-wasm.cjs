const { createRequire } = require("node:module");

if (!process.versions.webcontainer) {
  process.versions.webcontainer = "1";
}

const requireModule = createRequire(__filename);
if (!process.env.SWC_BINARY_PATH) {
  try {
    process.env.SWC_BINARY_PATH = requireModule.resolve("@next/swc-wasm-nodejs/wasm_bg.wasm");
  } catch (error) {
    console.warn("[setup-swc-wasm] Failed to resolve @next/swc-wasm-nodejs:", error);
  }
}
