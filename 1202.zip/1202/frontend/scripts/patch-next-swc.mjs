import fs from "node:fs";
import path from "node:path";

const targets = [
  "node_modules/next/dist/build/swc/index.js",
  "node_modules/next/dist/esm/build/swc/index.js"
];

for (const relative of targets) {
  const file = path.join(process.cwd(), relative);
  if (!fs.existsSync(file)) {
    continue;
  }
  let content = fs.readFileSync(file, "utf8");
  if (content.includes("NEXT_FORCE_SWC_WASM")) {
    continue;
  }
  content = content.replace(
    "const disableWasmFallback = process.env.NEXT_DISABLE_SWC_WASM;",
    "const disableWasmFallback = process.env.NEXT_DISABLE_SWC_WASM;\n        const forceWasmFallback = Boolean(process.env.NEXT_FORCE_SWC_WASM);"
  );
  content = content.replace(
    "const shouldLoadWasmFallbackFirst = !disableWasmFallback && unsupportedPlatform && useWasmBinary || isWebContainer;",
    "const shouldLoadWasmFallbackFirst = forceWasmFallback || !disableWasmFallback && unsupportedPlatform && useWasmBinary || isWebContainer;"
  );
  content = content.replace(
    'lastNativeBindingsLoadErrorCode = "unsupported_target";',
    'lastNativeBindingsLoadErrorCode = forceWasmFallback ? "force_wasm" : "unsupported_target";'
  );
  content = content.replace(
    "        }\n        // Trickle down loading `fallback` bindings:",
    "        }\n        if (forceWasmFallback) {\n            return logLoadFailure(attempts, true);\n        }\n        // Trickle down loading `fallback` bindings:"
  );
  fs.writeFileSync(file, content, "utf8");
}
