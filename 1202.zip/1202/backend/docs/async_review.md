## 1. 全体サマリ
FastAPI ルーターとサービス層はおおむね「Web 経路前提の async 設計」に沿っており、重い I/O は foundation / infrastructure 層の非同期ラッパーへ逃がす方針が守られています。今回優先したいポイントは、(A) Web 経路での `asyncio.run` 排除と、(B) `await` を伴わない `async def` を同期関数へ戻して読みやすくすることです。`rag/retriever.PgHybridRetriever` の同期 API は実際にはどこからも呼ばれておらず、削除しても挙動には影響しません。また、`app.py` や `foundation/authentication.py` のイベントフック／依存関数はすべて同期処理なので `def` に戻した方が FastAPI の期待と一致します。一方で、ドキュメント解析や reranker ロードを `asyncio.to_thread` へ逃がす案は将来の性能改善候補としてメモだけ残し、今回は手を入れない扱いにします。

## 2. 問題・改善ポイント一覧
- [HIGH] `rag/retriever.py` `PgHybridRetriever.get_relevant_documents` が `asyncio.run(self._search(...))` を持つが、同期 API を必要とする箇所は存在せず、FastAPI から誤用するとイベントループエラーになる。→ 今回の改修で削除し、`aget_relevant_documents` のみを公開する。
- [MEDIUM] `service/text_processing.py:402-520` アップロード解析の大半が同期 I/O（Docling / pandas / LibreOffice）で、イベントループを長時間占有する。→ 中長期課題としてメモ化（今回は実装しない）。
- [MEDIUM] `rag/reranker.py:206-257` `_load_reranker` が同期ロードのままなので初回アクセスでブロックする。→ こちらも将来 `asyncio.to_thread` で逃がす余地があるが、本改修では触らない。
- [LOW] `app.py:74-107` `startup_event` / `shutdown_event` / `healthcheck` は同期処理しか行わず `await` も無い。→ `def` に戻してシンプルにする。
- [LOW] `foundation/authentication.py:64-100` `get_user_context` も同期 `yield` のみで完結しており、`async def` にしておく利点が無い。→ 通常のジェネレータに戻す。

## 3. 詳細解説 & 修正案
### 3.1 `asyncio.run` を排除する（A）
`PgHybridRetriever` の同期 API は以下の通りです。
- 実装: `rag/retriever.py:222-238` にて `asyncio.run(self._search(query))` を呼び出す。
- 呼び出し箇所: `rg` で全体検索すると、定義以外には存在しません（= 実際には未使用）。
- 想定ユースケース: 「バッチや CLI から同期的に使う」ためのフォールバックというコメントがありますが、今回の前提では Web 経路以外を考慮しなくてよい、かつ新しい API を増やしたくありません。

考えられる選択肢:
1. **メソッド自体を削除**する。呼び出し箇所が無いので変更範囲は最小で済み、FastAPI から誤用される心配も消える。
2. メソッドを残して `RuntimeError` を投げるダミー化。誤用検知はできますが、不要な公開 API が残るため可読性が下がる。
3. 別案（専用イベントループを作る等）は、async 慣れしていないと理解が難しいうえ、新しい `asyncio` テクニックを増やしたくないという方針に反する。

前提と制約（Web 経路のみ、シンプルさ重視、新ファイル不可）を満たす最小変更は **①削除** です。`langchain` 実装に合わせる必要がなければ同期版を残す理由はなく、`aget_relevant_documents` のみを公開する方が読みやすくなります。

**Before**（`rag/retriever.py` 抜粋）
```python
    async def aget_relevant_documents(...):
        return await self._search(query)

    def get_relevant_documents(self, query: str) -> list[Document]:
        return asyncio.run(self._search(query))
```
**After（案）**
```python
    async def aget_relevant_documents(...):
        return await self._search(query)
    # get_relevant_documents は削除（公開 API も非同期版のみに統一）
```
この変更で `asyncio.run` はリポジトリから消え、FastAPI のリクエスト処理が誤って同期 API を呼んで落ちるパスも無くなります。テストや将来のバッチ用途が必要になった場合でも、明示的に `asyncio.run(pipeline())` を呼んで `aget_relevant_documents` を利用すれば済むため、アプリ本体に同期ラッパーを抱える必要はありません。

### 3.2 `async def` → `def` への書き換え可否（B）
対象は `app.py` の 3 関数と `foundation/authentication.py` の `get_user_context` です。どれも内部で外部 I/O を行わず、同期処理しかありません。FastAPI は **同期関数もサポートしており、必要に応じてスレッドプール実行**に切り替えてくれるため、`async def` で残す意味はありません。

1. `app.py` の `startup_event` / `shutdown_event`
   - 実装は単に `DatabaseConnectionPool.initialize/close` を呼ぶだけで `await` が無い。
   - 同期 `def` へ戻しても FastAPI がそのまま呼び出してくれる。
   - **After** 例:
     ```python
     @app.on_event("startup")
     def startup_event() -> None:
         DatabaseConnectionPool.initialize()

     @app.on_event("shutdown")
     def shutdown_event() -> None:
         DatabaseConnectionPool.close()
     ```
2. `app.py` の `healthcheck`
   - 定数 `{"status": "ok"}` を返すだけ。同期関数で十分。
   - **After** 例:
     ```python
     @app.get("/api/healthz", tags=["health"])
     def healthcheck() -> dict[str, str]:
         return {"status": "ok"}
     ```
3. `foundation/authentication.py` の `get_user_context`
   - `yield` で `UserContext` を返し、`bind_user_id` / `reset_user_id` を同期で実行している。
   - `async def` である必要は無く、通常のジェネレータ依存に戻すと FastAPI の `Depends` からも自然に扱える。
   - **After** 例（概略）:
     ```python
     def get_user_context(...):
         if user_id is None and settings.environment != "production":
             ...
             try:
                 yield context
             finally:
                 reset_user_id(token)
             return
         ...
         try:
             yield context
         finally:
             reset_user_id(token)
     ```
   - 変更はシグネチャを `async def` → `def` に切り替えるだけで済み、挙動は変わりません。

これらを同期関数に戻すことで、「async/await が出てくるのは実際に `await` が必要な場所だけ」という前提が強化され、コードを読むときに迷いません。

### 3.3 ドキュメント解析の同期 I/O（C: 今回はメモのみ）
`service/text_processing.py:402-520` では Docling / pandas / LibreOffice などをすべてイベントループ内で同期的に呼んでおり、アップロードサイズによっては FastAPI ワーカーが長時間ブロックされます。性能観点では `asyncio.to_thread` で逃がすか、処理を別プロセスに切り出す余地がありますが、今回の優先順位では理解しやすさを優先し、実装変更は行わない方針で問題ありません。将来チューニングする際は `async def` のまま `await asyncio.to_thread(_build_chunks_sync, ...)` のように挟み込むと対応できます。

### 3.4 reranker ロードの同期化（C: 今回はメモのみ）
`rag/reranker.py:206-257` の `_load_reranker` も同期ロードのままなので初回アクセスは時間がかかりますが、リクエストが 50〜100 程度であれば許容範囲です。将来改善したい場合は `asyncio.to_thread(CrossEncoder, ...)` でロードをスレッド化するか、`startup` イベントで `to_thread` 付きで先に読む方法が考えられます。今回は記録だけ残し、実装は据え置きで問題ありません。

## 4. 追加のリファクタ提案（任意）
1. reranker / Docling まわりの `asyncio.to_thread` 化は上記 3.3/3.4 の通り「将来の性能チューニング候補」として残すだけにしておき、現時点ではコードを増やさない。
2. `PgHybridRetriever` をもし LangChain の `BaseRetriever` に寄せたい場合でも、まずは `aget_relevant_documents` のみ公開して「async が必要な場面でのみ import できる」方針を徹底する。その後どうしても同期版が必要になったら、別モジュール（既存ファイル内）で `asyncio.run` を呼ぶスクリプトを用意する方が安全。
