import pytest

from backend.infrastructure.embedding_client import EMBEDDING_DIM, EmbeddingError, compute_embeddings


@pytest.mark.asyncio
async def test_compute_embeddings_falls_back_when_failure():
    """デフォルト埋め込み取得が失敗した場合に EmbeddingError になる。"""

    async def failing_embedding(texts):  # pragma: no cover - executed in test
        raise RuntimeError("network unavailable")

    with pytest.raises(EmbeddingError):
        await compute_embeddings(["テスト"], embedding_func=failing_embedding)


@pytest.mark.asyncio
async def test_compute_embeddings_falls_back_on_dimension_mismatch():
    """返却ベクトルの次元が想定外の場合にエラーを返す。"""

    async def mismatched_embedding(texts):  # pragma: no cover - executed in test
        return [[0.1, 0.2] for _ in texts]

    with pytest.raises(EmbeddingError):
        await compute_embeddings(["テスト"], embedding_func=mismatched_embedding)


@pytest.mark.asyncio
async def test_compute_embeddings_accepts_valid_dimension():
    """所定次元のベクトルであればそのまま受理する。"""

    async def valid_embedding(texts):  # pragma: no cover - executed in test
        return [[0.1] * EMBEDDING_DIM for _ in texts]

    vectors = await compute_embeddings(["テスト"], embedding_func=valid_embedding)
    assert len(vectors) == 1
    assert isinstance(vectors[0], list)
    assert len(vectors[0]) == EMBEDDING_DIM
