import pytest

from backend.api.documents.schema import DocumentListQuery
from backend.service import documents_service


@pytest.mark.parametrize(
    "query_kwargs",
    [
        {
            "department_codes": ["HR"],
            "document_types": ["policy"],
            "public_scopes": ["internal"],
            "statuses": ["ready"],
            "q": "manual",
        },
        {
            "department_codes": [],
            "document_types": [],
            "public_scopes": [],
            "statuses": [],
            "q": None,
        },
    ],
)
def test_build_where_clause_handles_filters(query_kwargs: dict) -> None:
    query = DocumentListQuery(**query_kwargs)
    where_clause, params = documents_service._build_where_clause(query)

    if any(query_kwargs.values()):
        assert where_clause.startswith("WHERE")
        assert params, "expected bound parameters when filters are provided"
    else:
        assert where_clause == ""
        assert params == []

    if query_kwargs.get("q"):
        assert "ILIKE" in where_clause
        assert params[-2:] == ["%manual%", "%manual%"]
