import json
from datetime import datetime, timezone
from uuid import uuid4

import pytest

from backend.foundation.authentication import UserContext
from backend.api.feedback.schema import FeedbackContextMessage, FeedbackCreateRequest
from backend.service import feedback_service


@pytest.mark.asyncio
async def test_create_feedback_inserts_snapshot(monkeypatch):
    """フィードバック作成時にDB挿入とコンテキスト保存が行われることを検証する。"""
    feedback_id = uuid4()
    created_at = datetime.now(timezone.utc)

    captured_params = {}

    async def fake_run_in_transaction_async(handler):
        """トランザクション実行を模倣し、スタブコネクションを渡す。"""
        class DummyCursor:
            """カーソルAPIを最小限再現するテスト用クラス。"""

            def __enter__(self):
                """コンテキストマネージャ開始時に自身を返す。"""
                return self

            def __exit__(self, exc_type, exc, tb):
                """例外を伝搬させるため False を返す。"""
                return False

            def execute(self, sql, params):
                """実行されたSQLとパラメータを記録する。"""
                captured_params["sql"] = sql.strip()
                captured_params["params"] = params

            def fetchone(self):
                """INSERT 後に返される行データをスタブする。"""
                return {"id": feedback_id, "created_at": created_at}

        class DummyConn:
            """`cursor()` メソッドだけを提供する簡易接続オブジェクト。"""
            def cursor(self):
                """テスト用カーソルを返す。"""
                return DummyCursor()

        return handler(DummyConn())

    monkeypatch.setattr(
        feedback_service.DatabaseConnectionPool,
        "run_in_transaction_async",
        fake_run_in_transaction_async,
    )

    payload = FeedbackCreateRequest(
        thread_id=uuid4(),
        assistant_message_id=uuid4(),
        user_message="ユーザー質問",
        assistant_message="AI回答",
        rating="good",
        context_messages=[
            FeedbackContextMessage(role="user", content="過去の質問"),
            FeedbackContextMessage(role="assistant", content="過去の回答"),
        ],
    )
    user = UserContext({"user_id": "dev-user"})

    record = await feedback_service.create_feedback(payload, user=user)

    assert record.id == feedback_id
    assert record.created_at == created_at
    assert captured_params["params"][2] == payload.assistant_message_id
    assert "assistant_message_id" in captured_params["sql"].lower()

    context_dump = captured_params["params"][6]
    assert isinstance(context_dump, str)
    parsed = json.loads(context_dump)
    assert parsed[0]["role"] == "user"
    assert parsed[1]["content"] == "過去の回答"


@pytest.mark.asyncio
async def test_list_latest_feedback_returns_rows(monkeypatch):
    """最新評価 API 用のサービス関数が SQL を実行し結果を整形することを確認する。"""

    captured: dict[str, object] = {}
    assistant_message_id = uuid4()

    async def fake_fetch_all_async(sql, params):
        captured["sql"] = sql.strip().lower()
        captured["params"] = params
        return [
            {"assistant_message_id": assistant_message_id, "rating": "bad"},
        ]

    monkeypatch.setattr(
        feedback_service.DatabaseConnectionPool,
        "fetch_all_async",
        fake_fetch_all_async,
    )

    thread_id = uuid4()
    user = UserContext({"user_id": "dev-user"})

    records = await feedback_service.list_latest_feedback(thread_id, user=user)

    assert len(records) == 1
    assert records[0].assistant_message_id == assistant_message_id
    assert records[0].rating == "bad"
    assert "distinct on" in captured["sql"]
    assert captured["params"] == ("dev-user", thread_id)
