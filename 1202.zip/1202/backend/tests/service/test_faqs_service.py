from backend.api.faqs.schema import FAQListQuery
from backend.service import faqs_service


def test_build_where_clause_includes_public_scope_and_statuses() -> None:
    query = FAQListQuery(
        department_codes=["IT"],
        categories=["policy"],
        faq_types=["rule"],
        public_scopes=["restricted"],
        statuses=["ready"],
        q="手順",
    )

    where_clause, params = faqs_service._build_where_clause(query)

    assert "f.public_scope = ANY" in where_clause
    assert "f.status = ANY" in where_clause
    assert params[0] == ["IT"]
    assert params[-2:] == ["%手順%", "%手順%"]
