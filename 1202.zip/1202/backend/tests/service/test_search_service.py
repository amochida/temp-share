import pytest

from backend.api.search.schema import DocumentSearchRequest, FAQSearchRequest
from backend.service import search_service


@pytest.mark.asyncio
async def test_search_documents_hybrid(monkeypatch):
    """検索エンジンから返った行をハイブリッドソースとして返す。"""

    async def fake_search(**kwargs):  # pragma: no cover - stub
        return [{"document_id": "1111", "score": 0.8}]

    monkeypatch.setattr(search_service, "search_documents_hybrid", fake_search)

    request = DocumentSearchRequest(text_query="就業", limit=5)
    results = await search_service.search_documents(request)

    assert results and results[0]["source"] == "hybrid"


@pytest.mark.asyncio
async def test_search_faqs_handles_errors(monkeypatch):
    """FAQ検索で例外が出た場合も適切に伝搬する。"""

    async def failing_search(**kwargs):  # pragma: no cover - stub
        raise RuntimeError("failed")

    monkeypatch.setattr(search_service, "search_faqs_hybrid", failing_search)

    request = FAQSearchRequest(text_query="Q1", limit=3)
    with pytest.raises(RuntimeError):
        await search_service.search_faqs(request)
