import io

import pytest
from starlette.datastructures import UploadFile

from backend.rag.ingestion import (
    UnsupportedDocumentTypeError,
    build_hybrid_chunks_from_upload,
)


@pytest.mark.asyncio
async def test_build_hybrid_chunks_supports_txt() -> None:
    upload = UploadFile(filename="sample.txt", file=io.BytesIO(b"hello\nworld"))

    chunks = await build_hybrid_chunks_from_upload(upload, max_chars=100)

    assert len(chunks) == 1
    assert chunks[0].page_start == 1
    assert chunks[0].page_end == 1
    assert "hello" in chunks[0].content
    assert "world" in chunks[0].content


@pytest.mark.asyncio
async def test_build_hybrid_chunks_rejects_unsupported_extension() -> None:
    upload = UploadFile(filename="data.csv", file=io.BytesIO(b"a,b"))

    with pytest.raises(UnsupportedDocumentTypeError):
        await build_hybrid_chunks_from_upload(upload)
