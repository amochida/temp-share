from datetime import datetime, timezone
from uuid import uuid4

import pytest
from pydantic import ValidationError

from backend.api.chat.schema import ChatCitation, ChatHistoryTurn, ChatQueryRequest, ChatSaveRequest
from backend.infrastructure.embedding_client import EmbeddingError
from backend.foundation.authentication import UserContext
from backend.service import chat_service
from backend.service.chat_service import OrchestratorConfig


@pytest.mark.asyncio
async def test_ask_question_returns_answer(monkeypatch):
    """run_rag_pipeline の結果が ChatAnswer へ写像されることを検証する。"""

    async def fake_rag_pipeline(*, payload, user, doc_filters, faq_filters):  # pragma: no cover - stub
        citations = [
            {
                "title": "就業規則",
                "snippet": "第10条",
                "document_id": uuid4(),
                "chunk_id": uuid4(),
                "origin": "documents",
                "score": 0.9,
            }
        ]
        config = OrchestratorConfig(
            retrieval_mode="docs_only",
            sources=["documents"],
            weight_map={"documents": 1.0, "faqs": 0.0},
        )
        chat_citations = [ChatCitation(**item) for item in citations]
        return "回答本文", chat_citations, "qa", config

    monkeypatch.setattr(chat_service, "run_rag_pipeline", fake_rag_pipeline)

    payload = ChatQueryRequest(
        query="有給休暇を取得したい",
        history=[ChatHistoryTurn(role="user", content="こんにちは")],
    )
    user = UserContext({"user_id": "tester"})

    answer = await chat_service.ask_question(payload, user=user)

    assert answer.answer == "回答本文"
    assert answer.sources_used == ["documents"]
    assert answer.prompt_type == "qa"
    assert answer.citations[0].title == "就業規則"


@pytest.mark.asyncio
async def test_ask_question_returns_error_when_embedding_fails(monkeypatch):
    """run_rag_pipeline が EmbeddingError を送出した場合の処理を検証する。"""

    async def failing_pipeline(*args, **kwargs):  # pragma: no cover - stub
        raise EmbeddingError("failed")

    monkeypatch.setattr(chat_service, "run_rag_pipeline", failing_pipeline)

    payload = ChatQueryRequest(query="テスト", history=[])
    user = UserContext({"user_id": "dev-user"})

    answer = await chat_service.ask_question(payload, user=user)

    assert answer.prompt_type == "error"
    assert "申し訳ありません" in answer.answer


def test_chat_save_request_requires_uuid():
    """チャット保存リクエストで UUID 以外を指定すると ValidationError になる。"""

    payload = {
        "thread_id": str(uuid4()),
        "messages": [
            {
                "id": "not-a-uuid",
                "role": "user",
                "content": "RAGとは?",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        ],
    }

    with pytest.raises(ValidationError):
        ChatSaveRequest.parse_obj(payload)
