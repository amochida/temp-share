import pytest

from backend.rag.text import estimate_token_count

def test_estimate_token_count_handles_empty():
    """トークン数推定が空文字と通常文字列の双方で動作することを検証する。"""
    assert estimate_token_count("") == 0
    assert estimate_token_count("one two three") == 3
