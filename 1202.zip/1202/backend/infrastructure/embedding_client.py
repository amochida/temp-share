"""LLM ベンダー依存を隠蔽した埋め込み（Embedding）生成クライアント。

RAG パイプラインが必要とする「テキスト → ベクトル」の処理を一本化し、
呼び出し側が OpenAI / Azure / Ollama などのベンダー差分を意識せずに

    await compute_embeddings(["本文1", "本文2", ...])

のように利用できることを目的としている。

内部では LangChain の Embeddings 実装（AzureOpenAIEmbeddings / OllamaEmbeddings など）
を利用するが、リトライ制御・レスポンス検証・PgVector への整形などの運用まわりは
このモジュールで一元的に管理する。
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import time
from collections.abc import Mapping, Sequence
from typing import Any

try:  # pragma: no cover - optional dependency (openai)
    from openai import AsyncAzureOpenAI
except ImportError:  # pragma: no cover - openai がインストールされていない場合
    AsyncAzureOpenAI = None  # type: ignore[assignment]

from backend.foundation.database import PgVector
from backend.foundation.llm_client import LLMError, get_langchain_embeddings
from backend.foundation.logging import configure_logging
from backend.foundation.settings import settings

# 埋め込み関連の挙動を可視化する構造化ロガー。
logger = configure_logging(__name__)
# プロバイダ設定で決まる埋め込み次元数。DB カラムと一致しないと永続化できない。
EMBEDDING_DIM = settings.llm.embedding_dimension
# LLM 呼び出しリトライ戦略。障害時に指数的ディレイで再試行する。
EMBEDDING_RETRY_ATTEMPTS = int(os.getenv("EMBEDDING_RETRY_ATTEMPTS", "3"))
EMBEDDING_RETRY_DELAY = float(os.getenv("EMBEDDING_RETRY_DELAY", "0.5"))

class EmbeddingError(RuntimeError):
    """埋め込み API 呼び出しで検知した異常を示すアプリ専用例外。"""


# LLM プロバイダへ一括で埋め込みリクエストを送る公開関数。
async def compute_embeddings(
    texts: Sequence[str],
    *,
    embedding_func=None,
) -> list[list[float]]:
    """Convert multiple texts into embedding vectors in a unified way.

    LangChain の Embeddings 実装（Azure / Ollama など）を内部で呼び出し、
    以下の責務を担うユーティリティ関数:

      * 空入力は即座に空リストを返す
      * LLM プロバイダへのリトライ制御
      * レスポンス件数の検証（テキスト数とベクトル数）
      * ベクトル次元数の検証（EMBEDDING_DIM との一致確認）
      * PgVector への正規化変換

    これにより、呼び出し側はベンダー差分やエラー処理を意識せずに
    「安定した Embedding API」として利用できる。

    Args:
        texts (Sequence[str]):
            ベクトル化したい文字列の配列。空の場合は空リストを返す。
        embedding_func (Callable[..., Awaitable[Sequence[Sequence[float]]]] | None):
            カスタムの埋め込み実装を差し込みたい場合に使うフック。
            指定しない場合は LangChain の Embeddings(embed_documents) を利用する。

    Returns:
        list[PgVector]:
            pgvector カラムにそのまま保存可能な長さ EMBEDDING_DIM のベクトル配列。
            入力 `texts` の順序は保証される。

    Raises:
        EmbeddingError:
            埋め込みプロバイダの呼び出しに失敗した場合や、
            レスポンス数／次元数が期待値と異なる場合。
    """
    if not texts:
        return []

    async def _default_embedding(targets: Sequence[str]) -> tuple[list[list[float]], dict[str, int | None] | None]:
        """プロバイダに応じた埋め込み生成と使用トークン取得を行う。"""

        provider = (settings.llm.provider or "").strip().lower()
        if provider == "azure":
            return await _azure_embeddings_with_usage(targets)

        # Ollama など usage 情報を返さないプロバイダは LangChain 実装を利用
        embeddings = get_langchain_embeddings()

        def _run() -> list[list[float]]:
            return list(embeddings.embed_documents(list(targets)))

        loop = asyncio.get_running_loop()
        vectors = await loop.run_in_executor(None, _run)
        return vectors, None

    usage_info: dict[str, int | None] | None = None
    start_ts = time.monotonic()

    for attempt in range(1, EMBEDDING_RETRY_ATTEMPTS + 1):
        try:
            if embedding_func is not None:
                vectors = list(await embedding_func(list(texts)))
                usage_info = None
            else:
                vectors, usage_info = await _default_embedding(list(texts))
            break
        except LLMError as exc:
            # LLM プロバイダ側のエラー（ネットワーク・APIエラーなど）
            if attempt == EMBEDDING_RETRY_ATTEMPTS:
                logger.error(
                    "埋め込みプロバイダの呼び出しに失敗しました",
                    extra={"error": str(exc), "count": len(texts)},
                )
                raise EmbeddingError("embedding provider call failed") from exc

            logger.warning(
                "埋め込みプロバイダ呼び出しをリトライ",
                extra={"attempt": attempt, "max": EMBEDDING_RETRY_ATTEMPTS, "error": str(exc)},
            )
            await asyncio.sleep(EMBEDDING_RETRY_DELAY * attempt)
        except Exception as exc:
            # LangChain 以外も含めた予期せぬ例外をキャッチし、
            # EmbeddingError として上位へ引き上げる。
            logger.error(
                "埋め込み処理で予期しないエラー",
                extra={"error": str(exc), "count": len(texts)},
            )
            raise EmbeddingError("embedding request failed") from exc
    else:  # ループを抜けられない場合の安全策
        raise EmbeddingError("embedding provider call failed")

    latency_ms = int((time.monotonic() - start_ts) * 1000)
    logger.info(
        "埋め込みAPIの呼び出しが完了",
        extra={
            "event": "embedding.llm_usage",
            "count": len(texts),
            "latency_ms": latency_ms,
            "prompt_tokens": usage_info["prompt_tokens"] if usage_info else None,
            "completion_tokens": usage_info["completion_tokens"] if usage_info else None,
            "total_tokens": usage_info["total_tokens"] if usage_info else None,
        },
    )

    # レスポンス件数の検証
    if len(vectors) != len(texts):
        logger.error(
            "埋め込みレスポンス件数が期待値と一致しません",
            extra={"expected": len(texts), "actual": len(vectors)},
        )
        raise EmbeddingError("embedding response size mismatch")

    # 各ベクトルの次元数を検証し、PgVector に正規化
    normalized: list[PgVector] = []
    for text, vector in zip(texts, vectors):

        # ログにテキスト全文を出さないため、SHA256 の短縮ダイジェストを付与して識別する
        digest = hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()[:12]
        vector_list = list(vector)

        # ベクトルの長さが設定値と異なる場合は DB との互換性が失われるため即エラー
        if len(vector_list) != EMBEDDING_DIM:
            logger.error(
                "埋め込みベクトルの次元が設定値と一致しません",
                extra={"expected": EMBEDDING_DIM, "actual": len(vector_list), "text_digest": digest},
            )
            raise EmbeddingError("unexpected embedding dimension")
        normalized.append(PgVector(vector_list))

    return normalized


async def _azure_embeddings_with_usage(
    targets: Sequence[str],
) -> tuple[list[list[float]], dict[str, int | None] | None]:
    """Azure OpenAI Embedding を呼び出し、公式の使用トークン情報を取得する。"""

    if AsyncAzureOpenAI is None:
        raise LLMError("openai パッケージがインストールされていません。")

    cfg = settings.llm
    if not cfg.azure_api_key or not cfg.azure_endpoint or not cfg.azure_embedding_deployment:
        raise LLMError("Azure OpenAI Embedding の接続情報が不足しています。")

    client = AsyncAzureOpenAI(
        api_key=cfg.azure_api_key,
        api_version=cfg.azure_api_version,
        azure_endpoint=cfg.azure_endpoint,
        timeout=cfg.request_timeout or None,
    )
    try:
        response = await client.embeddings.create(
            input=list(targets),
            model=cfg.azure_embedding_deployment,
        )
    except Exception as exc:  # pragma: no cover - ネットワークエラーなど
        raise LLMError("Azure OpenAI Embedding 呼び出しに失敗しました。") from exc
    finally:  # pragma: no cover - クライアント終了処理
        try:
            await client.close()
        except Exception:
            pass

    usage_info = _normalize_embedding_usage(getattr(response, "usage", None))
    vectors = [list(item.embedding) for item in getattr(response, "data", [])]
    return vectors, usage_info


def _normalize_embedding_usage(raw: Any) -> dict[str, int | None] | None:
    """OpenAI API が返す usage オブジェクトをログ用 dict へ正規化する。"""

    if raw is None:
        return None

    def _read(obj: Any, *keys: str) -> Any:
        for key in keys:
            if isinstance(obj, Mapping) and key in obj:
                return obj[key]
            if hasattr(obj, key):
                return getattr(obj, key)
        return None

    prompt = _read(raw, "prompt_tokens", "input_tokens")
    completion = _read(raw, "completion_tokens", "output_tokens")
    total = _read(raw, "total_tokens")
    try:
        prompt = int(prompt) if prompt is not None else None
    except (TypeError, ValueError):
        prompt = None
    try:
        completion = int(completion) if completion is not None else None
    except (TypeError, ValueError):
        completion = None
    try:
        total = int(total) if total is not None else None
    except (TypeError, ValueError):
        total = None
    if total is None and prompt is not None and completion is not None:
        total = prompt + completion
    return {
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": total if total is not None else prompt,
    }

__all__ = ["EmbeddingError", "EMBEDDING_DIM", "compute_embeddings"]
