"""ドキュメント管理に関わるユースケースを集約したモジュール。

上から順番に読み進めることで「アップロード → 解析 → ベクトル化 → 登録」「更新」「削除」「検索」
といった一連の流れが理解できるように丁寧なコメントを付与している。初学者が業務ロジックを
学ぶ教材としても利用できることを目指し、可能な限り日本語で意図を説明した。
"""

from __future__ import annotations

import json
import time
from collections import OrderedDict  # 検索結果を順序付きで保持するための辞書型
from typing import Any, Optional, Sequence  # 型ヒントを読みやすくするための定義群
from uuid import UUID  # ドキュメントを一意に識別するための ID 型

from fastapi import UploadFile  # FastAPI でアップロードされたファイルを扱うラッパークラス
from psycopg2.extensions import connection as PGConnection  # PostgreSQL の低レベル接続オブジェクト

# ------------------------------------------------------------
# スキーマと外部依存の読み込み
# ------------------------------------------------------------
from backend.api.documents.schema import DocumentListQuery, DocumentMetadata, DocumentUpdateRequest  # ドキュメント API のリクエスト定義
from backend.api.search.schema import DocumentSearchFilters, DocumentSearchRequest  # 検索 API のフィルタ・リクエスト定義
from backend.foundation.audit_log import AuditLogger  # 監査ログに操作履歴を残すためのユーティリティ
from backend.foundation.authentication import UserContext  # 認証済みユーザーのメタ情報を格納する辞書ライクなオブジェクト
from backend.foundation.database import DatabaseConnectionPool  # 非同期トランザクションをまとめて扱うコネクションプール
from backend.foundation.logging import configure_logging  # 構造化ログの初期化ヘルパー
from backend.infrastructure.embedding_client import EmbeddingError, compute_embeddings  # ベクトル化処理と関連例外
from backend.rag.ingestion import ChunkPayload, build_hybrid_chunks_from_upload
from backend.rag.text import build_search_terms, estimate_token_count
from backend.service import search_service  # 同一サービス層の検索ユースケース

# ------------------------------------------------------------
# 定数・ロガー設定
# ------------------------------------------------------------
# モジュールパス (backend.service.documents_service) をそのままログに出すため __name__ を渡す。
logger = configure_logging(__name__)

# 以下の定数はドキュメント管理機能全体で利用するチューニング値。
MAX_INSERT_RETRIES = 3
"""並列環境で INSERT が衝突した際に再試行する最大回数。例外発生時のリトライ戦略を理解しやすくするため。"""

MAX_CHARS_DEFAULT = 2000
MIN_CHARS_DEFAULT = 1200

# ============================================================
# 1. ドキュメント登録（新規アップロード時）
# ============================================================
async def create_document(
    upload: UploadFile,
    metadata: DocumentMetadata,
    *,
    user: UserContext,
) -> dict[str, Any]:
    """アップロードファイルを解析し、文書本体とチャンク情報をまとめて登録する処理。

    処理の流れ
    ---------
    1. ファイルからテキストを抽出し、段落単位にチャンク分割する。
    2. 各チャンクをベクトル化し、要約やトークン数などのメタ情報を付与する。
    3. documents/document_chunks テーブルに対して一括 INSERT を行い、一貫性を保つ。
    4. 誰が登録したかを監査ログへ記録し、監査証跡を残す。

    パラメータ
    ----------
    upload:
        エンドユーザーから渡された UploadFile。中身のテキストを解析対象とする。
    metadata:
        ドキュメントタイトルや部門コードなど、登録時に付随するメタ情報。
    user:
        操作中のユーザー情報。監査ログや権限制御で利用する。

    戻り値
    ------
    documents テーブルに登録されたレコードの ID とステータスをまとめた辞書を返却する。
    """

    start_ts = time.monotonic()
    # --- ログ開始 ---
    logger.info(
        "ドキュメント登録を開始",
        extra={
            "user_id": user.id,
            "file_name": upload.filename,
            "department_code": metadata.department_code,
        },
    )

    # --- ファイル解析とチャンク生成 ---
    chunk_payloads = await build_hybrid_chunks_from_upload(
        upload,
        max_chars=MAX_CHARS_DEFAULT,
        min_chars=MIN_CHARS_DEFAULT,
    )
    logger.info(
        "ドキュメントのチャンク生成が完了",
        extra={
            "user_id": user.id,
            "file_name": upload.filename,
            "chunk_count": len(chunk_payloads),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )

    # --- 各チャンクをAIモデルでベクトル化（埋め込み生成） ---
    chunk_texts = [chunk.content for chunk in chunk_payloads]
    embeddings = await _compute_document_embeddings(
        chunk_texts,
        user=user,
        title=metadata.title,
    )

    logger.debug(
        "チャンク生成の概要",
        extra={
            "chunk_count": len(chunk_payloads),
            "has_raw_text": bool(chunk_payloads),
        },
    )

    # --- 各チャンクの要約・トークン数推定・埋め込み整形 ---
    serialized_chunks = _build_serialized_chunks(chunk_payloads, embeddings)  # DB へ渡すための整形済みチャンク群

    # --- DB登録ロジック ---
    # DB への書き込みは 1 トランザクションでまとめる。
    document_row = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _create_document_transaction(
            conn,
            metadata=metadata,
            serialized_chunks=serialized_chunks,
            user=user,
        )
    )
    document_id = document_row["id"]  # INSERT 後に採番された UUID を控える

    logger.info(
        "ドキュメント登録が完了",
        extra={
            "user_id": user.id,
            "document_id": str(document_id),
            "chunk_count": len(serialized_chunks),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )

    # FastAPIルーター層に返す
    return {"document_id": document_id, "status": document_row["status"]}


# ============================================================
# 2. ドキュメント更新（メタ情報の変更）
# ============================================================
async def update_document(
    document_id: UUID,
    metadata: DocumentUpdateRequest,
    *,
    user: UserContext,
) -> Optional[dict[str, Any]]:
    """既存ドキュメントのメタ情報を更新する。

    処理の流れ
    ---------
    1. 更新対象のフィールドだけを抽出し、SQL の `SET` 句を動的に組み立てる。
    2. 引数に部門コードが含まれていれば、事前に部門 ID を解決してから更新対象に加える。
    3. 単一トランザクション内で `UPDATE` を実行し、変更内容を監査ログへ記録する。

    パラメータ
    ----------
    document_id:
        更新対象となるドキュメントの UUID。
    metadata:
        更新したいフィールドが格納されたリクエストオブジェクト。`None` の項目は据え置きとする。
    user:
        操作ユーザー情報。監査ログやアクセス制御で利用する。

    戻り値
    ------
    更新後の行を辞書で返す。該当レコードが存在しない場合は `None` を返却する。
    """

    start_ts = time.monotonic()
    logger.info(
        "ドキュメント更新を開始",
        extra={"document_id": str(document_id), "user_id": user.id},
    )

    # --- SQLのSET句を組み立てる ---
    assignments: list[str] = []  # SET 句として利用する「カラム = %s」形式の文字列を格納
    params: list[Any] = []  # 上記の %s にバインドする値を順番通りに保持

    # 更新候補となるカラムと値を順番に確認する。
    for column, value in (
        ("title", metadata.title),
        ("type", metadata.document_type),
        ("registration_type", metadata.registration_type),
        ("is_auto_import_target", metadata.is_auto_import_target),
        ("source_uri", metadata.source_uri),
        ("public_scope", metadata.public_scope),
        ("status", metadata.status),
    ):
        if value is not None:
            assignments.append(f"{column} = %s")
            params.append(value)

    # トランザクション内で UPDATE と監査記録をまとめて実行する。
    updated_row = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _update_document_transaction(
            conn,
            document_id=document_id,
            metadata=metadata,
            assignments=assignments,
            params=params,
            user=user,
        )
    )

    if not updated_row:
        logger.warning(
            "更新対象のドキュメントが見つからない",
            extra={"document_id": str(document_id), "user_id": user.id},
        )
        return None

    logger.info(
        "ドキュメント更新が完了",
        extra={
            "user_id": user.id,
            "document_id": str(document_id),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return updated_row


# ============================================================
# 3. ドキュメント削除
# ============================================================
async def delete_document(
    document_id: UUID,
    *,
    user: UserContext,
) -> None:
    """ドキュメントおよび関連チャンクを削除する。

    処理の流れ
    ---------
    1. 参照整合性を保つため、先に `document_chunks` 行を削除する。
    2. 親テーブル `documents` の該当行を削除し、削除件数が 0 なら未存在と判断する。
    3. 削除が成功した場合は監査ログに DELETE 操作を記録して証跡を残す。

    パラメータ
    ----------
    document_id:
        削除対象のドキュメント UUID。
    user:
        操作したユーザーのコンテキスト。監査ログに記録する。
    """
    start_ts = time.monotonic()
    logger.info(
        "ドキュメント削除を開始",
        extra={"document_id": str(document_id), "user_id": user.id},
    )
    # チャンクと本体をまとめて削除するためトランザクション処理に包む。
    deleted = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _delete_document_transaction(
            conn,
            document_id=document_id,
            user=user,
        )
    )

    if not deleted:
        logger.warning("削除対象のドキュメントが見つからない", extra={"document_id": str(document_id)})
        return

    logger.info(
        "ドキュメント削除が完了",
        extra={
            "document_id": str(document_id),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )


# ============================================================
# 4. 検索・取得系
# ============================================================
async def fetch_document(document_id: UUID) -> Optional[dict[str, Any]]:
    """ドキュメント1件を取得（部門コードも結合）。

    パラメータ
    ----------
    document_id:
        取得したいドキュメントの UUID。

    戻り値
    ------
    取得できた場合は辞書形式のレコード、見つからない場合は `None` を返す。
    """

    start_ts = time.monotonic()
    # 指定 ID の行を 1 件だけ取得する SQL を実行。
    row = await DatabaseConnectionPool.fetch_one_async(
        """
            SELECT *
              FROM documents d
             WHERE d.id = %s
        """,
        (document_id,),
    )
    logger.info(
        "ドキュメント取得が完了",
        extra={
            "document_id": str(document_id),
            "found": bool(row),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return row


async def fetch_document_chunks(document_id: UUID) -> list[dict[str, Any]]:
    """指定ドキュメント配下のチャンク一覧を取得。

    パラメータ
    ----------
    document_id:
        チャンクを列挙したい親ドキュメントの UUID。

    戻り値
    ------
    チャンク行を辞書で表現したリスト。該当が無くても空リストを返す。
    """

    start_ts = time.monotonic()
    # 子チャンクを順序付きで全件取得する。
    rows = await DatabaseConnectionPool.fetch_all_async(
        """
            SELECT *
              FROM document_chunks
             WHERE document_id = %s
             ORDER BY chunk_order ASC
        """,
        (document_id,),
    )
    logger.info(
        "ドキュメントチャンク取得が完了",
        extra={
            "document_id": str(document_id),
            "row_count": len(rows),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return rows


async def list_documents(query: DocumentListQuery) -> dict[str, Any]:
    """スタッフ画面向けにドキュメント一覧を返す。"""

    start_ts = time.monotonic()
    base_result = await _fetch_documents_base(query)
    semantic_hits = await _semantic_search_documents(query)
    if semantic_hits:
        merged = await _merge_semantic_hits(base_result, semantic_hits, query)
        logger.info(
            "ドキュメント一覧取得が完了（意味検索あり）",
            extra={
                "count": len(merged.get("items", [])),
                "latency_ms": int((time.monotonic() - start_ts) * 1000),
            },
        )
        return merged
    logger.info(
        "ドキュメント一覧取得が完了",
        extra={
            "count": len(base_result.get("items", [])),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return base_result


async def _fetch_documents_base(query: DocumentListQuery) -> dict[str, Any]:
    """通常の SQL 条件に基づいてページング済み一覧を取得する。"""

    where_clause, params = _build_where_clause(query)
    count_sql = f"SELECT COUNT(*) AS total FROM documents doc {where_clause}"
    total_row = await DatabaseConnectionPool.fetch_one_async(count_sql, tuple(params))
    sql = f"""
        SELECT doc.*
          FROM documents doc
          {where_clause}
      ORDER BY doc.updated_at DESC
         LIMIT %s OFFSET %s
    """
    rows = await DatabaseConnectionPool.fetch_all_async(
        sql,
        (*params, query.limit, query.offset),
    )
    return {"total": int(total_row["total"]) if total_row else 0, "items": [dict(row) for row in rows]}

# ============================================================
# 6. 意味検索（Semantic Search）
# ============================================================
async def _semantic_search_documents(query: DocumentListQuery) -> "OrderedDict[UUID, dict[str, Any]]":
    """ベクトル検索（自然文による意味検索）を実行し、類似ドキュメント候補を取得する。

    処理の流れ
    ---------
    1. クライアントから渡されたフィルタ条件を検索マイクロサービス向けの形式へ再構築する。
    2. 意味検索 API を呼び出し、チャンク単位の検索結果を取得する。
    3. チャンクの結果をドキュメント単位へ集約し、もっともスコアが高いチャンクの情報を保持する。

    パラメータ
    ----------
    query:
        一覧 API のクエリ条件。キーワード検索やセマンティック検索の文字列、各種フィルタを含む。

    戻り値
    ------
    ドキュメント UUID をキーとした `OrderedDict`。値にはスコアとスニペットを格納する。
    検索文字列が空の場合は空の `OrderedDict` を返す。
    """
    if not query.semantic_query:
        return OrderedDict()

    # --- 絞り込み条件の作成（部門・種別など） ---
    filters = DocumentSearchFilters(
        departments=query.department_codes or None,
        document_types=query.document_types or None,
        public_scopes=query.public_scopes or None,
        statuses=(query.statuses or ([query.status] if query.status else None)),
    )  # 指定がある場合だけ絞り込みを有効にする
    active_filters = (
        filters
        if any([filters.departments, filters.document_types, filters.public_scopes, filters.statuses])
        else None
    )  # 全て空ならフィルタなしとみなして None を渡す

    # 検索 API に渡すリクエストオブジェクトを生成。
    search_request = DocumentSearchRequest(
        text_query=None,
        semantic_query=query.semantic_query,
        limit=max(query.limit + query.offset, 50),
        filters=active_filters,
    )

    # セマンティック検索を実際に実行。
    search_results = await search_service.search_documents(search_request)

    # --- ドキュメントID単位に集約 ---
    hits: "OrderedDict[UUID, dict[str, Any]]" = OrderedDict()  # 集約済みのドキュメント候補を保持
    # チャンク単位の検索結果を走査し、ドキュメント単位へ寄せ集める。
    for item in search_results:
        # document_id が欠落している場合があるため、防御的に UUID 化を試みる。
        try:
            doc_uuid = UUID(str(item.get("document_id")))
        except (ValueError, TypeError):
            continue
        score = item.get("score")  # ベクトル検索の類似度スコア
        snippet = item.get("snippet")  # 検索結果の抜粋テキスト
        current = hits.get(doc_uuid)  # すでに登録済みかどうかを確認

        # 同一document_idが複数チャンクに存在する場合 → 最もスコア高いものを採用
        if current is None or (score is not None and score > current.get("score", 0.0)):
            hits[doc_uuid] = {"score": score, "snippet": snippet}

    return hits


# ============================================================
# 7. SQL結果と意味検索結果の統合
# ============================================================
async def _merge_semantic_hits(
    base_result: dict[str, Any],
    semantic_hits: "OrderedDict[UUID, dict[str, Any]]",
    query: DocumentListQuery,
) -> dict[str, Any]:
    """SQL 検索結果に意味検索のヒットを統合し、再度ページングを適用する。

    処理の流れ
    ---------
    1. まず通常の SQL 検索結果を順序付き辞書へ写し替える。
    2. 意味検索でヒットしたドキュメントのメタ情報をまとめて取得する。
    3. SQL 側のフィルタ条件を改めて適用し、条件に一致したものだけを統合する。
    4. 最後にオフセット・リミットを適用し、元の API と同じ形式で返却する。

    パラメータ
    ----------
    base_result:
        通常検索（SQL）で得た結果。`items` と `total` を含む辞書を想定。
    semantic_hits:
        セマンティック検索でヒットしたドキュメントの補足情報。スコアやスニペットを保持する。
    query:
        一覧検索の条件。ページングやステータス、部門などのフィルタを含む。

    戻り値
    ------
    `total` と `items` を持つ辞書。`items` はページング後のドキュメント辞書リストとなる。
    """

    allowed_statuses = query.statuses or ([query.status] if query.status else None)
    ordered: "OrderedDict[UUID, dict[str, Any]]" = OrderedDict()  # ここに統合結果を順番通り詰める
    # まずは SQL の結果をそのまま順序付き辞書へ移し替える。
    for row in base_result["items"]:
        ordered[row["id"]] = dict(row)  # SQL 結果を最終候補に初期投入

    # --- 意味検索でヒットしたdocument_idのメタ情報を一括取得 ---
    metadata_map = await _fetch_documents_by_ids(list(semantic_hits.keys()))  # まとめて DB から詳細を取得

    # 続いて意味検索のヒットをマージし、条件を再評価する。
    for doc_id, extras in semantic_hits.items():
        base_row = metadata_map.get(doc_id)  # DB から取得できなかった場合はスキップ
        if not base_row:
            continue

        # フィルタ条件を再度適用（セマンティック検索は条件が緩いことがある）
        if allowed_statuses and base_row.get("status") not in allowed_statuses:
            continue
        doc_department = (base_row.get("department_code") or "").strip()
        if query.department_codes and doc_department and doc_department not in query.department_codes:
            continue
        if query.document_types and base_row.get("type") not in query.document_types:
            continue
        if query.public_scopes and base_row.get("public_scope") not in query.public_scopes:
            continue

        enriched = dict(base_row)  # 新しい辞書を作って副作用を避ける
        enriched["score"] = extras.get("score")  # セマンティックスコアを付加
        enriched["snippet"] = extras.get("snippet")  # 抜粋テキストを付加
        ordered[doc_id] = enriched  # 最終集合へ追加または上書き

    combined = list(ordered.values())  # OrderedDict からリストへ戻す
    total = base_result.get("total", len(combined))  # total が既に計算済みなら尊重

    # ページネーション制御
    start = max(query.offset, 0)  # オフセットは負数になる可能性があるため防御的に補正
    end = start + query.limit  # 取り出す上限位置を計算
    paged = combined[start:end] if start < len(combined) else []  # 範囲外なら空リストを返す

    logger.info(
        "ドキュメント一覧取得が完了",
        extra={"count": len(paged), "semantic": True},
    )
    return {"total": total, "items": paged}


# ============================================================
# 8. SQL WHERE句構築（通常検索）
# ============================================================
def _build_where_clause(query: DocumentListQuery) -> tuple[str, list[Any]]:
    """一覧検索で利用する WHERE 句とバインドパラメータを構築する。"""

    conditions: list[str] = []
    params: list[Any] = []

    if query.department_codes:
        conditions.append(
            "(doc.department_code = ANY(%s) OR doc.department_code IS NULL OR doc.department_code = '')"
        )
        params.append(query.department_codes)

    if query.document_types:
        conditions.append("doc.type = ANY(%s)")
        params.append(query.document_types)

    if query.public_scopes:
        conditions.append("doc.public_scope = ANY(%s)")
        params.append(query.public_scopes)

    statuses = query.statuses or ([query.status] if query.status else None)
    if statuses:
        conditions.append("doc.status = ANY(%s)")
        params.append(statuses)

    if query.q:
        conditions.append("(doc.title ILIKE %s OR doc.source_uri ILIKE %s)")
        like = f"%{query.q}%"
        params.extend([like, like])

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    return where_clause, params


async def _compute_document_embeddings(
    chunk_texts: Sequence[str],
    *,
    user: UserContext,
    title: str | None,
) -> list[list[float]]:
    """チャンク配列を埋め込みベクトルへ変換し、失敗時には詳細ログを残す。

    パラメータ
    ----------
    chunk_texts:
        埋め込み対象の本文リスト。
    user:
        現在の操作ユーザー。障害時のログに利用する。
    title:
        登録対象ドキュメントのタイトル。エラーログの文脈情報として使用。

    戻り値
    ------
    各チャンクに対応したベクトルを `list[list[float]]` 形式で返す。
    埋め込み生成で失敗した場合は `EmbeddingError` をそのまま投げ直す。
    """

    if not chunk_texts:
        return []
    start_ts = time.monotonic()
    try:
        vectors = await compute_embeddings(chunk_texts)  # ベクトル化 API を実行
        latency_ms = int((time.monotonic() - start_ts) * 1000)
        logger.info(
            "ドキュメント埋め込み生成が完了",
            extra={
                "user_id": user.id,
                "chunk_count": len(chunk_texts),
                "latency_ms": latency_ms,
            },
        )
        return vectors
    except EmbeddingError as exc:
        logger.error(
            "ドキュメントの埋め込み生成に失敗",
            extra={
                "user_id": user.id,
                "document_title": title,
                "chunk_count": len(chunk_texts),
            },
        )
        raise EmbeddingError("document embedding failed") from exc


def _build_serialized_chunks(
    chunk_payloads: Sequence[ChunkPayload],
    embeddings: Sequence[Sequence[float]],
) -> list[dict[str, Any]]:
    """チャンクとベクトルを DB 挿入用の辞書配列に変換する。

    パラメータ
    ----------
    chunk_payloads:
        ハイブリッドチャンクの配列。呼び出し順序が `chunk_order` となる。
    embeddings:
        各チャンクに対応するベクトル列。チャンク順とベクトル順が一致している前提。

    戻り値
    ------
    `document_chunks` テーブルへ挿入可能な辞書リストを返す。要約やトークン数などもここで付与する。
    """

    if chunk_payloads and len(chunk_payloads) != len(embeddings):
        raise ValueError("chunk payload と埋め込み数が一致しません")

    serialized: list[dict[str, Any]] = []
    for order, (chunk, embedding) in enumerate(zip(chunk_payloads, embeddings), start=1):
        content = chunk.content
        serialized.append(
            {
                "order": order,
                "label": chunk.chunk_label,
                "page_start": chunk.page_start or 1,
                "page_end": chunk.page_end or chunk.page_start or 1,
                "content": content,
                "summary": "",
                "tokens": estimate_token_count(content),
                "embedding": embedding,
                "terms": build_search_terms(content),
                "metadata": chunk.metadata or {},
            }
        )
    return serialized


# ============================================================
# 9. 補助関数群（DB操作）
# ============================================================
def _insert_document_row(conn: PGConnection, metadata: DocumentMetadata) -> dict[str, Any]:
    """`documents` テーブルに新規レコードを挿入し、挿入した行を辞書で返す。

    パラメータ
    ----------
    conn:
        実行中トランザクションに紐づく PostgreSQL 接続。
    metadata:
        登録対象ドキュメントのメタ情報。タイトルや種別などを利用する。
    戻り値
    ------
    `documents` テーブルに新規挿入した行を辞書化したもの。
    挿入に失敗した場合は例外を送出する。
    """

    sql = """
        INSERT INTO documents (
            department_code,
            title,
            type,
            registration_type,
            is_auto_import_target,
            source_uri,
            public_scope,
            status
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING *
    """
    with conn.cursor() as cur:
        cur.execute(
            sql,
            (
                metadata.department_code,
                metadata.title,
                metadata.document_type,
                metadata.registration_type,
                metadata.is_auto_import_target,
                metadata.source_uri,
                metadata.public_scope,
                "ready",
            ),
        )
        row = cur.fetchone()
        if row is None:
            raise RuntimeError("document_insert_failed")
        return dict(row)


def _insert_document_chunks(conn: PGConnection, document_id: UUID, chunk_rows: Sequence[dict[str, Any]]) -> None:
    """`document_chunks` テーブルに複数チャンクを一括挿入する。

    パラメータ
    ----------
    conn:
        挿入を実行するデータベース接続。
    document_id:
        親となるドキュメント UUID。外部キーとして保存される。
    chunk_rows:
        事前に整形されたチャンク辞書リスト。空なら何もしない。
    """

    if not chunk_rows:
        return
    sql = """
        INSERT INTO document_chunks (
            document_id,
            chunk_order,
            chunk_label,
            page_start,
            page_end,
            content,
            summary,
            tokens_count,
            embedding,
            content_tsv,
            metadata
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s::vector, to_tsvector(%s, %s), %s::jsonb)
    """
    # list comprehension でバルク INSERT 用のタプルを生成する。
    parameters = [
        (
            document_id,
            row["order"],
            row["label"],
            row.get("page_start", 1),
            row.get("page_end", row.get("page_start", 1)),
            row["content"],
            row.get("summary"),
            row.get("tokens", 0),
            row["embedding"],
            "pg_catalog.simple",
            row["terms"],
            json.dumps(row.get("metadata") or {}),
        )
        for row in chunk_rows
    ]
    with conn.cursor() as cur:
        cur.executemany(sql, parameters)  # executemany でまとめて挿入し、往復回数を削減


def _create_document_transaction(
    conn: PGConnection,
    *,
    metadata: DocumentMetadata,
    serialized_chunks: list[dict[str, Any]],
    user: UserContext,
) -> dict[str, Any]:
    """ドキュメントの INSERT 処理と監査ログ記録を 1 トランザクションで実行する。

    パラメータ
    ----------
    conn:
        トランザクションを実行する接続。
    metadata:
        ドキュメントのメタ情報。タイトルや部門コードが含まれる。
    serialized_chunks:
        DB へそのまま書き込めるチャンクの辞書リスト。
    user:
        操作ユーザー。監査ログに必要。
    戻り値
    ------
    挿入後のドキュメント行を辞書で返す。
    """

    document_row = _insert_document_row(conn, metadata)  # documents へ本体を挿入
    document_id = document_row["id"]  # 生成されたドキュメント UUID を控える

    if serialized_chunks:
        _insert_document_chunks(conn, document_id, serialized_chunks)  # チャンクをまとめて書き込む

    AuditLogger.record(
        user_id=user.id,
        user_email=user.get("email"),
        user_department=user.get("department"),
        action="CREATE",
        target_type="DOCUMENT",
        target_id=str(document_id),
        payload={
            "title": metadata.title,
            "department_code": metadata.department_code,
            "chunk_count": len(serialized_chunks),
        },
    )  # 監査要件を満たすために操作履歴を残す
    return document_row


def _update_document_transaction(
    conn: PGConnection,
    *,
    document_id: UUID,
    metadata: DocumentUpdateRequest,
    assignments: list[str],
    params: list[Any],
    user: UserContext,
) -> Optional[dict[str, Any]]:
    """ドキュメント更新処理と監査ログ記録を同一トランザクションで実施する。

    パラメータ
    ----------
    conn:
        実行対象のデータベース接続。
    document_id:
        更新対象のドキュメント UUID。
    metadata:
        更新リクエスト。部門コードなど追加情報が入っている。
    assignments:
        事前に構築された SET 句のリスト。
    params:
        プレースホルダへバインドする値のリスト。
    user:
        操作ユーザー。監査ログで利用。

    戻り値
    ------
    更新後の辞書行。該当レコードが存在しなければ `None`。
    """

    local_assignments = list(assignments)  # 元のリストを書き換えないようコピー
    local_params = list(params)  # 同上。追加入力を受け付けるため

    if metadata.department_code is not None:
        local_assignments.append("department_code = %s")  # None/空文字もそのまま保存し、フロントから指定された通り反映
        local_params.append(metadata.department_code)

    if not local_assignments:
        return _fetch_document_with_connection(conn, document_id)  # 変更点が無ければ現在値を返す

    local_assignments.append("updated_at = NOW()")  # タイムスタンプを必ず更新する
    updated_row = _update_document_row(conn, document_id, local_assignments, local_params)
    if updated_row is None:
        return None

    AuditLogger.record(
        user_id=user.id,
        user_email=user.get("email"),
        user_department=user.get("department"),
        action="UPDATE",
        target_type="DOCUMENT",
        target_id=str(document_id),
        payload={"updated_fields": local_assignments},
    )  # どのフィールドを変更したかを明示的に記録する
    return updated_row


def _delete_document_transaction(
    conn: PGConnection,
    *,
    document_id: UUID,
    user: UserContext,
) -> bool:
    """ドキュメント本体とチャンクを削除し、監査ログへ記録する。

    戻り値
    ------
    削除された場合は `True`、対象が存在しなかった場合は `False`。
    """

    with conn.cursor() as cur:
        cur.execute("DELETE FROM document_chunks WHERE document_id = %s", (document_id,))  # 子テーブルから先に削除
        cur.execute("DELETE FROM documents WHERE id = %s RETURNING id", (document_id,))  # 親テーブルを削除し存在を確認
        row = cur.fetchone()
        if not row:
            return False
    AuditLogger.record(
        user_id=user.id,
        user_email=user.get("email"),
        user_department=user.get("department"),
        action="DELETE",
        target_type="DOCUMENT",
        target_id=str(document_id),
        payload=None,
    )  # 削除操作も必ず監査ログに残す
    return True


def _update_document_row(conn: PGConnection, document_id: UUID, assignments: Sequence[str], params: Sequence[Any]) -> Optional[dict[str, Any]]:
    """`documents` テーブルの特定行を更新し、更新後の行を辞書で返す。

    パラメータ
    ----------
    conn:
        トランザクション中の接続。
    document_id:
        主キー UUID。
    assignments:
        `column = %s` 形式の文字列を並べたシーケンス。
    params:
        上記 assignments に対応する値。
    """

    sql = f"""
        UPDATE documents
           SET {', '.join(assignments)}
         WHERE id = %s
     RETURNING *
    """
    with conn.cursor() as cur:
        cur.execute(sql, [*params, document_id])  # document_id を末尾に付けてバインド
        row = cur.fetchone()
        return dict(row) if row else None


def _fetch_document_with_connection(conn: PGConnection, document_id: UUID) -> Optional[dict[str, Any]]:
    """トランザクション中の接続を利用してドキュメント1件を取得する。

    パラメータ
    ----------
    conn:
        呼び出し元トランザクションの接続。
    document_id:
        取得対象のドキュメント UUID。

    戻り値
    ------
    取得できた場合は辞書。存在しない場合は `None`。
    """

    with conn.cursor() as cur:
        cur.execute(
            """
                SELECT *
                  FROM documents d
                 WHERE d.id = %s
            """,
            (document_id,),
        )
        row = cur.fetchone()
        return dict(row) if row else None

async def _fetch_documents_by_ids(doc_ids: Sequence[UUID]) -> dict[UUID, dict[str, Any]]:
    """ドキュメントIDリストに基づいて、複数件を一括取得する。

    パラメータ
    ----------
    doc_ids:
        取得したいドキュメントの UUID シーケンス。

    戻り値
    ------
    UUID をキー、ドキュメント行の辞書を値とするマッピング。順序は元の行取得順を保持する。
    """
    if not doc_ids:
        return {}

    def _run(conn: PGConnection) -> dict[UUID, dict[str, Any]]:
        """指定 ID 群に対応するドキュメントを辞書化して返す。"""
        sql = """
            SELECT *
              FROM documents d
             WHERE d.id = ANY(%s)
        """
        with conn.cursor() as cur:
            cur.execute(sql, (list(doc_ids),))
            rows = cur.fetchall() or []  # 該当が無い場合は空配列を扱う
        mapping: dict[UUID, dict[str, Any]] = OrderedDict()  # 取得順を保持したまま辞書化
        # 取得した各行を UUID をキーにした辞書へ詰め直す。
        for row in rows:
            data = dict(row)  # psycopg2 の Row オブジェクトを通常の dict へ変換
            mapping[data["id"]] = data
        return mapping

    return await DatabaseConnectionPool.run_in_transaction_async(_run)  # 単発でもトランザクション Context を活用
