"""FAQ 管理に関するユースケースロジック。

上から順に読むだけで「登録 → 更新 → 削除 → 取得 → 検索」の全体像が分かるよう、
教科書的な日本語コメントで処理の意図と背景を解説する。スタッフ UI から届くリクエストを
受け取り、データベースとベクトル検索の橋渡しをするサービス層として実装されている。
"""

from __future__ import annotations

import time
from collections import OrderedDict  # 検索結果を順序付きで保持する辞書型
from typing import Any, Optional, Sequence  # 型ヒントを読みやすくするための補助型
from uuid import UUID  # FAQ を一意に識別するための ID 型

from psycopg2.extensions import connection as PGConnection  # PostgreSQL 接続オブジェクト型

from backend.api.faqs.schema import FAQListQuery, FAQPayload  # FAQ API の入力スキーマ
from backend.api.search.schema import FAQSearchFilters, FAQSearchRequest  # FAQ 検索フィルタとリクエスト定義
from backend.foundation.audit_log import AuditLogger  # 操作履歴を監査ログに記録するユーティリティ
from backend.foundation.authentication import UserContext  # 認証済みユーザー情報を保持する辞書ライッパー
from backend.foundation.database import DatabaseConnectionPool  # 非同期トランザクションを提供するコネクションプール
from backend.foundation.logging import configure_logging  # 構造化ログの初期化ヘルパー
from backend.infrastructure.embedding_client import EmbeddingError, compute_embeddings  # 埋め込み生成 API と例外
from backend.service import search_service  # FAQ 検索ユースケースとの連携
from backend.rag.text import build_search_terms, estimate_token_count  # 検索語生成とトークン推定

# FAQ 処理のモジュール名をそのままログに残す。
logger = configure_logging(__name__)

TSVECTOR_CONFIG = "pg_catalog.simple"
"""PostgreSQL の全文検索に利用するテキスト解析設定。シンプルな辞書を採用する。"""

async def create_faq(
    payload: FAQPayload,
    *,
    user: UserContext,
) -> dict[str, Any]:
    """FAQ を新規登録するユースケース。

    処理の流れ
    ---------
    1. 質問と回答を結合し、埋め込み生成に渡すテキストを用意する。
    2. 埋め込みベクトル生成・トークン数推定・全文検索用語抽出を行う。
    3. トランザクション内で `faqs` テーブルへ INSERT し、監査ログを記録する。

    パラメータ
    ----------
    payload:
        フロントエンドから受け取った FAQ の内容。
    user:
        操作ユーザー。監査ログの記録に利用する。

    戻り値
    ------
    作成された FAQ の ID とステータスを含む辞書。
    """

    start_ts = time.monotonic()
    # 質問と回答を 1 つのテキストにまとめる。改行を挟むことでベクトル化時の文脈を保つ。
    combined_text = f"{payload.question}\n{payload.answer}".strip()  # 質問と回答を 1 本の文字列に整形
    embedding = await _compute_faq_embedding(
        combined_text,
        user=user,
        faq_id=None,
        context_event="FAQ作成時の埋め込み生成に失敗",
        extra_payload={"category": payload.category},
    )  # ベクトル生成に失敗した場合は例外を投げて呼び出し元で対処する
    tokens = estimate_token_count(combined_text)  # OpenAI モデルでのコスト目安としても活用
    question_terms = build_search_terms(payload.question)  # 質問文に出現する主要語を抽出
    answer_terms = build_search_terms(payload.answer)  # 回答文の主要語も同様に抽出
    content_terms = " ".join(part for part in [question_terms, answer_terms] if part)  # 質問/回答両方の語を統合
    if not content_terms:
        content_terms = build_search_terms(combined_text)  # どちらも空の場合は結合テキストから生成

    logger.info(
        "FAQ登録を開始",
        extra={
            "user_id": user.id,
            "category": payload.category,
            "status": payload.status,
        },
    )

    # DB 書き込みと監査ログを丸ごとトランザクションに閉じ込める。
    row = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _create_faq_transaction(
            conn,
            payload=payload,
            tokens=tokens,
            embedding=embedding,
            question_terms=question_terms,
            answer_terms=answer_terms,
            content_terms=content_terms,
            user=user,
        )
    )

    logger.info(
        "FAQ登録が完了",
        extra={
            "user_id": user.id,
            "faq_id": str(row["id"]),
            "token_count": tokens,
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return {"faq_id": row["id"], "status": row["status"]}


async def update_faq(
    faq_id: UUID,
    payload: FAQPayload,
    *,
    user: UserContext,
) -> Optional[dict[str, Any]]:
    """既存 FAQ の内容を更新する。

    処理の流れ
    ---------
    1. 新しい質問・回答を結合し、埋め込み生成と全文検索用語の抽出を行う。
    2. トランザクション内で `UPDATE` を発行し、変更行を監査ログへ記録する。

    パラメータ
    ----------
    faq_id:
        更新対象となる FAQ の UUID。
    payload:
        更新後の質問・回答・カテゴリなどを含むオブジェクト。
    user:
        操作ユーザー。監査ログで使用する。

    戻り値
    ------
    更新後のレコードを辞書で返す。対象が存在しない場合は `None`。
    """

    start_ts = time.monotonic()
    logger.info(
        "FAQ更新を開始",
        extra={"faq_id": str(faq_id), "user_id": user.id},
    )
    combined_text = f"{payload.question}\n{payload.answer}".strip()  # 質問と回答を 1 本の文字列に整形
    embedding = await _compute_faq_embedding(
        combined_text,
        user=user,
        faq_id=str(faq_id),
        context_event="FAQ更新時の埋め込み生成に失敗",
        extra_payload=None,
    )  # 既存 FAQ が対象なので ID をログに紐づける
    tokens = estimate_token_count(combined_text)  # 更新後の内容に合わせてトークン数を再計算
    question_terms = build_search_terms(payload.question)  # 質問文から検索語を抽出
    answer_terms = build_search_terms(payload.answer)  # 回答文でも同様に抽出
    content_terms = " ".join(part for part in [question_terms, answer_terms] if part)  # 両方の語を統合
    if not content_terms:
        content_terms = build_search_terms(combined_text)  # どちらも空になった場合のフォールバック

    # DB 更新と監査ログ記録を同一トランザクションで実施する。
    row = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _update_faq_transaction(
            conn,
            faq_id=faq_id,
            payload=payload,
            tokens=tokens,
            embedding=embedding,
            question_terms=question_terms,
            answer_terms=answer_terms,
            content_terms=content_terms,
            user=user,
        )
    )

    # 更新対象が存在しなかった場合は監査ログを残さずに呼び出し元へ通知する。
    if not row:
        logger.warning(
            "更新対象の FAQ が見つからない",
            extra={"faq_id": str(faq_id), "user_id": user.id},
        )
        return None

    logger.info(
        "FAQ更新が完了",
        extra={
            "faq_id": str(faq_id),
            "user_id": user.id,
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return row


async def delete_faq(
    faq_id: UUID,
    *,
    user: UserContext,
) -> None:
    """FAQ を物理削除するユースケース。

    処理の流れ
    ---------
    1. トランザクション内で対象行を削除し、削除件数をチェックする。
    2. 削除できた場合は監査ログに DELETE 操作を記録する。

    パラメータ
    ----------
    faq_id:
        削除対象の FAQ UUID。
    user:
        操作ユーザー。監査ログへ記録するために必要。
    """

    start_ts = time.monotonic()
    logger.info(
        "FAQ削除を開始",
        extra={"faq_id": str(faq_id), "user_id": user.id},
    )
    # FAQ レコード削除と監査ログ記録を 1 つのトランザクションで実行する。
    deleted = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _delete_faq_transaction(
            conn,
            faq_id=faq_id,
            user=user,
        )
    )
    # 削除対象が存在しないケースでは警告ログのみを出力する。
    if not deleted:
        logger.warning(
            "削除対象の FAQ が見つからない",
            extra={"faq_id": str(faq_id), "user_id": user.id},
        )
        return

    logger.info(
        "FAQ削除が完了",
        extra={
            "faq_id": str(faq_id),
            "user_id": user.id,
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )


async def fetch_faq(faq_id: UUID) -> Optional[dict[str, Any]]:
    """FAQ を 1 件取得する。

    パラメータ
    ----------
    faq_id:
        取得対象の FAQ UUID。

    戻り値
    ------
    該当レコードが存在すれば辞書、存在しなければ `None`。
    """

    start_ts = time.monotonic()
    row = await DatabaseConnectionPool.fetch_one_async(
        """
            SELECT *
              FROM faqs f
             WHERE f.id = %s
        """,
        (faq_id,),
    )
    logger.info(
        "FAQ取得が完了",
        extra={
            "faq_id": str(faq_id),
            "found": bool(row),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return row


async def list_faqs(query: FAQListQuery) -> dict[str, Any]:
    """スタッフ画面向けに FAQ の一覧を返す。"""

    start_ts = time.monotonic()
    base_result = await _fetch_faqs_base(query)
    semantic_hits = await _semantic_search_faqs(query)
    if semantic_hits:
        merged = await _merge_semantic_hits(base_result, semantic_hits, query)
        logger.info(
            "FAQ一覧取得が完了（意味検索あり）",
            extra={
                "count": len(merged.get("items", [])),
                "latency_ms": int((time.monotonic() - start_ts) * 1000),
            },
        )
        return merged
    logger.info(
        "FAQ一覧取得が完了",
        extra={
            "count": len(base_result.get("items", [])),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return base_result


async def _fetch_faqs_base(query: FAQListQuery) -> dict[str, Any]:
    """FAQ の SQL 一覧を取得する。"""

    where_clause, params = _build_where_clause(query)
    count_sql = f"SELECT COUNT(*) AS total FROM faqs f {where_clause}"
    total_row = await DatabaseConnectionPool.fetch_one_async(count_sql, tuple(params))
    sql = f"""
        SELECT f.*
          FROM faqs f
          {where_clause}
      ORDER BY f.updated_at DESC
         LIMIT %s OFFSET %s
    """
    rows = await DatabaseConnectionPool.fetch_all_async(
        sql,
        (*params, query.limit, query.offset),
    )
    return {"total": int(total_row["total"]) if total_row else 0, "items": [dict(row) for row in rows]}

async def _semantic_search_faqs(query: FAQListQuery) -> "OrderedDict[UUID, dict[str, Any]]":
    """FAQ の意味検索を実行し、スコア付き結果を返す。

    処理の流れ
    ---------
    1. クエリ条件から検索フィルタを組み立て、検索マイクロサービスへ渡すリクエストを作成する。
    2. セマンティック検索結果（FAQ 単位）を受け取り、UUID をキーにした `OrderedDict` に整形する。

    検索文字列が空の場合は空の `OrderedDict` を返し、呼び出し元で通常検索のみを継続する。
    """
    if not query.semantic_query:
        return OrderedDict()

    filters = FAQSearchFilters(
        departments=query.department_codes or None,
        categories=query.categories or None,
        faq_types=query.faq_types or None,
        public_scopes=query.public_scopes or None,
        statuses=(query.statuses or ([query.status] if query.status else None)),
    )  # フィルタ条件が未指定なら None を渡して検索範囲を広げる
    active_filters = (
        filters
        if any(
            [
                filters.departments,
                filters.categories,
                filters.faq_types,
                filters.public_scopes,
                filters.statuses,
            ]
        )
        else None
    )  # 全て空であればフィルタなしと判断する

    search_request = FAQSearchRequest(
        text_query=None,
        semantic_query=query.semantic_query,
        limit=max(query.limit + query.offset, 50),
        filters=active_filters,
    )  # セマンティック検索は自然文のみを対象にする
    search_results = await search_service.search_faqs(search_request)

    hits: "OrderedDict[UUID, dict[str, Any]]" = OrderedDict()  # FAQ ID をキーにしてスコアを保持
    # 検索サービスから返る各行を走査し、UUID 化に失敗したものはスキップする。
    for item in search_results:
        try:
            faq_uuid = UUID(str(item.get("faq_id")))
        except (ValueError, TypeError):
            continue
        score = item.get("score")  # ベクトル類似度スコア
        snippet = item.get("snippet")  # 抜粋テキスト（LLM への根拠提示にも利用）
        hits[faq_uuid] = {"score": score, "snippet": snippet}
    return hits


async def _merge_semantic_hits(
    base_result: dict[str, Any],
    semantic_hits: "OrderedDict[UUID, dict[str, Any]]",
    query: FAQListQuery,
) -> dict[str, Any]:
    """通常検索結果にセマンティック検索結果を統合し、ページングを再適用する。

    処理の流れ
    ---------
    1. 通常検索結果 (`base_result`) を順序付き辞書に移し替え、FAQ ID をキーとする。
    2. セマンティック検索でヒットした FAQ の詳細情報をまとめて取得する。
    3. 再度フィルタ条件を適用し、条件一致したものだけを統合する。
    4. 最後にページングをかけ、呼び出し元と同じレスポンス形式に整形する。
    """

    ordered: "OrderedDict[UUID, dict[str, Any]]" = OrderedDict()  # 最終的な集合を保持
    for row in base_result["items"]:
        ordered[row["id"]] = dict(row)  # SQL 結果を初期値として投入

    metadata_map = await _fetch_faqs_by_ids(list(semantic_hits.keys()))  # ヒットした ID の詳細をまとめて取得
    # セマンティック検索の結果を走査し、条件に合致したものだけを上書きする。
    allowed_statuses = query.statuses or ([query.status] if query.status else None)
    for faq_id, extras in semantic_hits.items():
        base_row = metadata_map.get(faq_id)
        if not base_row:
            continue
        if allowed_statuses and base_row.get("status") not in allowed_statuses:
            continue
        faq_department = (base_row.get("department_code") or "").strip()
        if query.department_codes and faq_department and faq_department not in query.department_codes:
            continue
        if query.categories and base_row.get("category") not in query.categories:
            continue
        if query.faq_types and base_row.get("type") not in query.faq_types:
            continue
        if query.public_scopes and base_row.get("public_scope") not in query.public_scopes:
            continue
        enriched = dict(base_row)  # 新しい辞書を作り、副作用を避ける
        enriched["score"] = extras.get("score")
        enriched["snippet"] = extras.get("snippet")
        ordered[faq_id] = enriched

    combined = list(ordered.values())  # 順序付き辞書からリストへ戻す
    total = base_result.get("total", len(combined))  # 既存 total があれば優先する
    start = max(query.offset, 0)  # オフセットが負数になるのを防ぐ
    end = start + query.limit
    paged = combined[start:end] if start < len(combined) else []  # 範囲外アクセスは空リストで対応
    return {"total": total, "items": paged}


def _build_where_clause(query: FAQListQuery) -> tuple[str, list[Any]]:
    """FAQ 検索用の WHERE 句とバインドパラメータを生成する。

    パラメータ
    ----------
    query:
        API から渡された検索条件。部門・カテゴリ・種別・キーワードなどを含む。

    戻り値
    ------
    `(where_clause, params)` のタプルを返す。`where_clause` は `WHERE` 句文字列、`params` はバインド値のリスト。
    """
    conditions: list[str] = []
    params: list[Any] = []

    if query.department_codes:
        conditions.append(
            "(f.department_code = ANY(%s) OR f.department_code IS NULL OR f.department_code = '')"
        )
        params.append(query.department_codes)
    if query.categories:
        conditions.append("f.category = ANY(%s)")
        params.append(query.categories)
    if query.faq_types:
        conditions.append("f.type = ANY(%s)")
        params.append(query.faq_types)
    if query.public_scopes:
        conditions.append("f.public_scope = ANY(%s)")
        params.append(query.public_scopes)

    statuses = query.statuses or ([query.status] if query.status else None)
    if statuses:
        conditions.append("f.status = ANY(%s)")
        params.append(statuses)

    if query.q:
        conditions.append("(f.question ILIKE %s OR f.answer ILIKE %s)")
        like = f"%{query.q}%"
        params.extend([like, like])

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    return where_clause, params


# ---------------------------------------------------------------------------
# DB操作用のヘルパー
# ---------------------------------------------------------------------------
def _insert_faq_row(
    conn: PGConnection,
    *,
    department_code: Optional[str],
    category: Optional[str],
    faq_type: Optional[str],
    question: str,
    answer: str,
    summary: str,
    tokens: int,
    embedding: Sequence[float],
    question_terms: str,
    answer_terms: str,
    content_terms: str,
    public_scope: str,
    status: str,
    user_id: UUID,
) -> dict[str, Any]:
    """`faqs` テーブルへ 1 レコード挿入し、その行を辞書で返す。

    パラメータ
    ----------
    conn:
        現在のトランザクションに紐づく PostgreSQL 接続。
    department_code:
        フロントエンドから渡された部門コード。NULL/空文字なら「全部門」扱いとして保存する。
    category / faq_type / question / answer / summary:
        FAQ の基本情報。summary が空の場合はここで生成した文字列を使用する。
    tokens:
        質問＋回答のトークン数。検索の重み付けや分析に利用する。
    embedding:
        ベクトルをそのまま保持した配列。DB 層で pgvector 文字列へ変換する。
    question_terms / answer_terms / content_terms:
        PostgreSQL の全文検索 (`tsvector`) 用に事前生成した語群。
    public_scope / status:
        FAQ の公開範囲とステータス。
    user_id:
        作成者の UUID。`created_by` と `updated_by` に設定する。

    戻り値
    ------
        挿入された行を辞書形式で返す。挿入に失敗した場合は例外を送出する。
    """
    sql = """
        INSERT INTO faqs (
            department_code,
            category,
            type,
            question,
            answer,
            summary,
            tokens_count,
            embedding,
            question_tsv,
            answer_tsv,
            content_tsv,
            public_scope,
            status,
            created_by,
            updated_by
        )
        VALUES (
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s::vector,
            to_tsvector(%s, %s),
            to_tsvector(%s, %s),
            to_tsvector(%s, %s),
            %s,
            %s,
            %s,
            %s
        )
        RETURNING *
    """
    with conn.cursor() as cur:
        cur.execute(
            sql,
            (
                department_code,
                category,
                faq_type,
                question,
                answer,
                summary,
                tokens,
                embedding,
                TSVECTOR_CONFIG,
                question_terms,
                TSVECTOR_CONFIG,
                answer_terms,
                TSVECTOR_CONFIG,
                content_terms,
                public_scope,
                status,
                user_id,
                user_id,
            ),
        )
        row = cur.fetchone()
        if row is None:
            raise RuntimeError("faq_insert_failed")
        return dict(row)


def _update_faq_row(
    conn: PGConnection,
    faq_id: UUID,
    assignments: Sequence[str],
    params: Sequence[Any],
) -> Optional[dict[str, Any]]:
    """FAQ テーブルの指定行を更新し、更新後の行を辞書で返す。

    パラメータ
    ----------
    conn:
        トランザクション中の接続。
    faq_id:
        更新対象の主キー。
    assignments:
        `column = %s` 形式の文字列を並べたシーケンス。
    params:
        assignments に対応する値のシーケンス。

    戻り値
    ------
    更新後の行を辞書にして返す。対象が存在しなければ `None`。
    """
    sql = f"""
        UPDATE faqs
           SET {', '.join(assignments)}
         WHERE id = %s
     RETURNING *
    """
    with conn.cursor() as cur:
        cur.execute(sql, [*params, faq_id])  # params の末尾に faq_id を追加してバインド
        row = cur.fetchone()
        return dict(row) if row else None


def _create_faq_transaction(
    conn: PGConnection,
    *,
    payload: FAQPayload,
    tokens: int,
    embedding: Sequence[float],
    question_terms: str,
    answer_terms: str,
    content_terms: str,
    user: UserContext,
) -> dict[str, Any]:
    """FAQ を登録し、監査ログを記録するトランザクション処理。

    パラメータ
    ----------
    conn:
        実行中のトランザクション接続。
    payload / tokens / embedding / question_terms ...:
        登録に必要な情報一式。上位レイヤーで事前計算した値をそのまま受け取る。
    user:
        操作ユーザー。監査ログに利用する。

    戻り値
    ------
    挿入された FAQ 行を辞書として返す。
    """
    row = _insert_faq_row(
        conn,
        department_code=payload.department_code,
        category=payload.category,
        faq_type=payload.faq_type,
        question=payload.question,
        answer=payload.answer,
        summary=payload.summary or payload.answer[:200],  # 要約未指定なら回答冒頭を仮要約として保存
        tokens=tokens,
        embedding=embedding,
        question_terms=question_terms,
        answer_terms=answer_terms,
        content_terms=content_terms,
        public_scope=payload.public_scope,
        status=payload.status,
        user_id=user.id,
    )

    AuditLogger.record(
        user_id=user.id,
        user_email=user.get("email"),
        user_department=user.get("department"),
        action="CREATE",
        target_type="FAQ",
        target_id=str(row["id"]),
        payload={"question": payload.question, "status": row["status"]},
    )  # 誰がどの FAQ を登録したかを後から追跡できるようにする
    return row


def _update_faq_transaction(
    conn: PGConnection,
    *,
    faq_id: UUID,
    payload: FAQPayload,
    tokens: int,
    embedding: Sequence[float],
    question_terms: str,
    answer_terms: str,
    content_terms: str,
    user: UserContext,
) -> Optional[dict[str, Any]]:
    """FAQ 更新処理と監査ログ記録をひとまとめに行う。

    パラメータ
    ----------
    conn:
        実行中のトランザクション接続。
    faq_id / payload / tokens ...:
        更新対象の主キーと、事前計算済みの更新内容。
    user:
        操作ユーザー。

    戻り値
    ------
    更新後の行を辞書で返す。対象が存在しない場合は `None`。
    """
    assignments = [
        "question = %s",
        "answer = %s",
        "summary = %s",
        "tokens_count = %s",
        "embedding = %s::vector",
        "question_tsv = to_tsvector(%s, %s)",
        "answer_tsv = to_tsvector(%s, %s)",
        "content_tsv = to_tsvector(%s, %s)",
        "public_scope = %s",
        "status = %s",
        "updated_by = %s",
        "updated_at = NOW()",
    ]  # 更新対象カラムを順番に列挙
    params: list[Any] = [
        payload.question,
        payload.answer,
        payload.summary or payload.answer[:200],  # 表示用サマリーが空なら回答冒頭を利用
        tokens,
        embedding,
        TSVECTOR_CONFIG,
        question_terms,
        TSVECTOR_CONFIG,
        answer_terms,
        TSVECTOR_CONFIG,
        content_terms,
        payload.public_scope,
        payload.status,
        user.id,
    ]  # assignments の順番に対応するバインド値

    if payload.department_code is not None:
        assignments.append("department_code = %s")
        params.append(payload.department_code)
    if payload.category is not None:
        assignments.append("category = %s")  # カテゴリが指定された場合のみ更新
        params.append(payload.category)
    if payload.faq_type is not None:
        assignments.append("type = %s")  # FAQ 種別も同様に条件付きで更新
        params.append(payload.faq_type)

    row = _update_faq_row(conn, faq_id, assignments, params)  # 実際の UPDATE 実行
    if not row:
        return None

    AuditLogger.record(
        user_id=user.id,
        user_email=user.get("email"),
        user_department=user.get("department"),
        action="UPDATE",
        target_type="FAQ",
        target_id=str(faq_id),
        payload={"updated_fields": assignments},
    )  # 変更したカラム情報をそのまま監査ログへ残す
    return row


def _delete_faq_transaction(
    conn: PGConnection,
    *,
    faq_id: UUID,
    user: UserContext,
) -> bool:
    """FAQ を削除し、監査ログに記録する。

    パラメータ
    ----------
    conn:
        実行中のトランザクション接続。
    faq_id:
        削除対象の UUID。
    user:
        操作ユーザー。監査ログに使用。

    戻り値
    ------
    削除できた場合は `True`、対象が存在しなかった場合は `False`。
    """

    with conn.cursor() as cur:
        cur.execute("DELETE FROM faqs WHERE id = %s RETURNING id", (faq_id,))  # 指定 ID の行を削除
        row = cur.fetchone()
        if not row:
            return False
    AuditLogger.record(
        user_id=user.id,
        user_email=user.get("email"),
        user_department=user.get("department"),
        action="DELETE",
        target_type="FAQ",
        target_id=str(faq_id),
        payload=None,
    )  # 物理削除でも操作履歴を確実に残す
    return True

async def _fetch_faqs_by_ids(faq_ids: Sequence[UUID]) -> dict[UUID, dict[str, Any]]:
    """指定された FAQ ID 群をまとめて取得し、辞書形式で返す。

    検索結果と通常検索結果をマージする際に、必要なメタ情報をまとめて取得するための
    ヘルパー。順序を維持するため `OrderedDict` を利用する。
    """
    if not faq_ids:
        return {}

    def _run(conn: PGConnection) -> dict[UUID, dict[str, Any]]:
        """複数 FAQ をまとめて取得し、ID をキーとした辞書に詰め直す。"""
        sql = """
            SELECT *
              FROM faqs f
             WHERE f.id = ANY(%s)
        """
        with conn.cursor() as cur:
            cur.execute(sql, (list(faq_ids),))
            rows = cur.fetchall() or []  # 見つからなければ空リストを返す
        mapping: dict[UUID, dict[str, Any]] = OrderedDict()  # 取得順を保ちながら辞書化
        for row in rows:
            data = dict(row)  # psycopg2 の Row オブジェクトを通常の辞書へ変換
            mapping[data["id"]] = data
        return mapping

    return await DatabaseConnectionPool.run_in_transaction_async(_run)  # 非同期コンテキストから安全に実行


async def _compute_faq_embedding(
    text: str,
    *,
    user: UserContext,
    faq_id: Optional[str],
    context_event: str,
    extra_payload: Optional[dict[str, Any]],
) -> list[float]:
    """FAQ 向け埋め込み生成を共通化したヘルパー。

    パラメータ
    ----------
    text:
        埋め込み生成の対象テキスト（質問＋回答など）。
    user:
        操作ユーザー。ログ出力時のトレースに利用する。
    faq_id:
        更新時などに紐づく FAQ ID。新規作成時は `None`。
    context_event:
        ログ出力時に利用するイベントキー。呼び出し元によって変わる。
    extra_payload:
        追加でログへ含めたいメタ情報（カテゴリなど）。

    戻り値
    ------
    埋め込みベクトル（浮動小数のリスト）。
    生成に失敗した場合は `EmbeddingError` を投げ、呼び出し元で補足する。
    """

    try:
        start_ts = time.monotonic()
        vectors = (await compute_embeddings([text]))[0]
        logger.info(
            "FAQ埋め込み生成が完了",
            extra={
                "user_id": user.id,
                "faq_id": faq_id,
                "latency_ms": int((time.monotonic() - start_ts) * 1000),
            },
        )
        return vectors
    except EmbeddingError as exc:
        log_payload = {"user_id": user.id}
        if faq_id is not None:
            log_payload["faq_id"] = faq_id
        if extra_payload:
            log_payload.update(extra_payload)
        logger.error(context_event, extra=log_payload)
        raise EmbeddingError("faq embedding failed") from exc
