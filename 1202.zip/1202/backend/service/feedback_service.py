"""フィードバック保存ユースケースを集約したモジュール。

上から順に読み進めるだけで「パラメータの整形 → DB 登録 → 結果返却」という流れが理解できるよう、
コメントを教科書的に整備している。API ルーター層から呼び出され、ビジネスロジック層として
フィードバックの保存処理を担当する。

アーキテクチャの考え方
------------------------
- API 層は「リクエストをどのように受け取るか」を知っている。
- Service 層（このファイル）は「受け取ったデータをどのように扱うか」を知っている。
- Repository 層（ここでは `DatabaseConnectionPool` が提供するトランザクション関数）が「どのように保存するか」を知っている。

この責務分離によって、ユニットテストや機能拡張（たとえば保存先の変更や通知処理の追加）が容易になる。
"""

from __future__ import annotations
import json
from typing import Any, Optional
from uuid import UUID

from backend.api.feedback.schema import (
    FeedbackCreateRequest,
    FeedbackLatestRecord,
    FeedbackStoredRecord,
)
from backend.foundation.authentication import UserContext
from backend.foundation.database import DatabaseConnectionPool
from backend.foundation.logging import configure_logging
from psycopg2.extensions import connection as PGConnection  # PostgreSQL の接続オブジェクト型

# ロガー設定（"feedback_service" という名前で出力される）
# 完全修飾モジュール名をログに流すため __name__ をそのまま渡す。
logger = configure_logging(__name__)


async def create_feedback(
    payload: FeedbackCreateRequest,
    *,
    user: UserContext,
) -> FeedbackStoredRecord:
    """フィードバックをデータベースに保存するメインユースケース。

    処理の流れ
    ---------
    1. 過去の会話履歴 (`context_messages`) を JSON 文字列へ整形する。
    2. 送信者やスレッド情報をログに記録し、トレースしやすくする。
    3. トランザクション内で `feedback` テーブルへ INSERT を実行し、結果を監査用に取得する。
    4. 挿入されたレコードの ID と作成日時を `FeedbackStoredRecord` として呼び出し元へ返す。

    パラメータ
    ----------
    payload:
        フロントエンドから受け取ったフィードバック内容。評価値・コメント・会話履歴を含む。
    user:
        フィードバックを送信した認証済みユーザー情報。

    戻り値
    ------
    データベースへ保存されたレコードの ID と作成日時を格納した `FeedbackStoredRecord`。
    """

    start_ts = time.monotonic()
    # ------------------------------------------------------------
    # (1) 会話履歴を JSON に変換（空であれば None）
    # ------------------------------------------------------------
    context_json = None  # 会話履歴が無い場合は NULL を保存して容量を節約
    if payload.context_messages:
        # Pydantic モデルを素直な dict に変換し、可読性を保つために ensure_ascii=False を指定
        context_json = json.dumps([message.dict() for message in payload.context_messages], ensure_ascii=False)

    # ------------------------------------------------------------
    # (2) ログ出力：処理開始
    # ------------------------------------------------------------
    logger.info(
        "フィードバック保存を開始",
        extra={
            "user_id": user.id,
            "thread_id": str(payload.thread_id),
            "assistant_message_id": str(payload.assistant_message_id),
            "rating": payload.rating,
        },
    )

    if payload.context_messages:
        logger.debug(
            "フィードバックの履歴メッセージ件数",
            extra={"count": len(payload.context_messages)},
        )

    # ------------------------------------------------------------
    # (3) 実際のDB登録処理（1件INSERT）
    # ------------------------------------------------------------
    row = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _create_feedback_transaction(
            conn,
            payload=payload,
            user=user,
            context_json=context_json,
        )
    )

    # ------------------------------------------------------------
    # (5) ログ出力：完了
    # ------------------------------------------------------------
    logger.info(
        "フィードバック保存が完了",
        extra={
            "user_id": user.id,
            "feedback_id": str(row["id"]),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )

    # ------------------------------------------------------------
    # (6) 呼び出し元（API層）へ結果を返す
    # ------------------------------------------------------------
    return FeedbackStoredRecord(id=row["id"], created_at=row["created_at"])


def _create_feedback_transaction(
    conn: PGConnection,
    *,
    payload: FeedbackCreateRequest,
    user: UserContext,
    context_json: Optional[str],
) -> dict[str, Any]:
    """フィードバックを 1 件挿入し、挿入結果を辞書で返すトランザクション処理。

    パラメータ
    ----------
    conn:
        `DatabaseConnectionPool` から貸し出された PostgreSQL 接続。
    payload:
        保存対象のフィードバック内容。
    user:
        フィードバックを投稿したユーザー。`user_id` として保存する。
    context_json:
        会話履歴を JSON 文字列にしたもの。履歴が無い場合は `None`。

    戻り値
    ------
    `INSERT ... RETURNING` で得た `id` と `created_at` を辞書化して返す。
    """
    sql = """
        INSERT INTO feedback (
            user_id,
            thread_id,
            assistant_message_id,
            user_message,
            assistant_message,
            rating,
            messages
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        RETURNING id, created_at
    """
    with conn.cursor() as cur:
        cur.execute(
            sql,
            (
                user.id,
                payload.thread_id,
                payload.assistant_message_id,
                payload.user_message,
                payload.assistant_message,
                payload.rating,
                context_json,
            ),
        )
        row = cur.fetchone()
        if row is None:
            raise RuntimeError("feedback_insert_failed")
        return dict(row)  # psycopg2 の Row オブジェクトを通常の辞書に変換


async def list_latest_feedback(
    thread_id: UUID,
    *,
    user: UserContext,
) -> list[FeedbackLatestRecord]:
    """指定スレッド内でユーザーが最後に押した評価だけを取り出す補助関数。"""

    start_ts = time.monotonic()
    sql = """
        SELECT DISTINCT ON (assistant_message_id)
            assistant_message_id,
            rating
        FROM feedback
        WHERE user_id = %s
          AND thread_id = %s
          AND assistant_message_id IS NOT NULL
        ORDER BY assistant_message_id, created_at DESC
    """
    rows = await DatabaseConnectionPool.fetch_all_async(sql, (user.id, thread_id))
    logger.info(
        "最新フィードバック取得が完了",
        extra={
            "thread_id": str(thread_id),
            "row_count": len(rows),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return [
        FeedbackLatestRecord(
            assistant_message_id=row["assistant_message_id"],
            rating=row["rating"],
        )
        for row in rows
    ]
