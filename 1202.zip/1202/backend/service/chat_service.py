"""チャット API から RAG 検索・回答生成までを束ねるサービス層。

LangChain を用いた Retriever／Generator の連携、履歴保存 API、例外ハンドリングを
一箇所に集約し、FastAPI などのプレゼンテーション層からは単純な関数呼び出しで
利用できるようにしている。
"""
from __future__ import annotations

import json
import time
from typing import Any, Optional, Sequence, Union
from uuid import UUID, uuid4

from psycopg2.extras import Json

from backend.api.chat.schema import (
    ChatAnswer,
    ChatHistoryTurn,
    ChatQueryFilters,
    ChatQueryRequest,
    ChatSaveMessage,
    ChatSaveRequest,
    ChatSaveResponse,
)
from backend.api.search.schema import DocumentSearchFilters, FAQSearchFilters
from backend.foundation.authentication import UserContext
from backend.foundation.database import DatabaseConnectionPool
from backend.foundation.logging import configure_logging
from backend.foundation.llm_client import LLMError
from backend.infrastructure.embedding_client import EmbeddingError
from backend.rag.config import rag_tuning
from backend.rag.orchestrator import OrchestratorConfig, run_rag_pipeline

# エラーメッセージはユーザーに再試行を促す定型文を使用する。
ERROR_MESSAGE = (
    "申し訳ありません。回答生成中に問題が発生しました。時間をおいて再度お試しください。"
)
logger = configure_logging(__name__)


# REST API からの質問を受け RAG パイプラインを駆動する公開関数。
async def ask_question(
    payload: ChatQueryRequest,
    *,
    user: UserContext,
) -> ChatAnswer:
    """チャット検索要求を受け取り、最終回答とメタ情報を返す。

    Retriever からの空応答・Embedding/LLM エラーなどはここで握りつぶし、呼び出し
    元へはユーザー向けエラーメッセージとメトリクスのみ返す。

    Args:
        payload: 質問文、履歴、フィルター条件を含むリクエストボディ。
        user: 呼び出しユーザーの認証情報。

    Returns:
        ChatAnswer: 回答本文と引用情報、遅延計測を含むレスポンス。
    """
    logger.info(
        "チャット質問を受信",
        extra={
            "user_id": user.id,
            "thread_id": str(payload.thread_id) if payload.thread_id else None,
        },
    )
    logger.debug(
        "入力内容の詳細",
        extra={
            "query": payload.query,
            "history_count": len(payload.history),
            "filters": payload.filters.model_dump(exclude_none=True) if payload.filters else None,
        },
    )

    doc_filters, faq_filters = _convert_filters(payload.filters)
    history_text = _format_history_text(payload.history)
    logger.debug(
        "LLMへ渡す履歴テキスト",
        extra={"history_preview": history_text or "(履歴なし)"},
    )
    start_ts = time.monotonic()

    try:
        (
            answer_text,
            citations,
            prompt_key,
            config,
        ) = await run_rag_pipeline(
            query=payload.query,
            history_text=history_text,
            answer_mode=payload.filters.answer_mode if payload.filters else None,
            doc_filters=doc_filters,
            faq_filters=faq_filters,
        )

        latency_ms = int((time.monotonic() - start_ts) * 1000)
        answer = ChatAnswer(
            query_id=uuid4(),
            thread_id=payload.thread_id,
            sources_used=config.sources,
            weights=config.weight_map,
            answer=answer_text,
            citations=citations,
            prompt_type=prompt_key,
            latency_ms=latency_ms,
        )
        logger.info(
            "回答生成完了",
            extra={"latency_ms": latency_ms, "citation_count": len(citations)},
        )
        logger.debug(
            "回答本文プレビュー",
            extra={
                "answer_preview": answer_text[:300] + ("..." if len(answer_text) > 300 else ""),
                "latency_ms": latency_ms,
            },
        )
        logger.info(
            "チャット質問パイプラインが完了",
            extra={
                "event": "chat.ask.pipeline.complete",
                "latency_ms": latency_ms,
                "citation_count": len(citations),
                "sources": config.sources,
                "weights": config.weight_map,
                "answer_mode": payload.filters.answer_mode if payload.filters else None,
            },
        )
        return answer
    except EmbeddingError as exc:
        latency_ms = int((time.monotonic() - start_ts) * 1000)
        logger.error("チャット質問で Embedding が失敗", extra={"error": str(exc)})
        return _build_error_answer(payload, latency_ms=latency_ms, reason="embedding_failed")
    except LLMError as exc:
        latency_ms = int((time.monotonic() - start_ts) * 1000)
        logger.error("チャット質問で LLM 呼び出しが失敗", extra={"error": str(exc)})
        return _build_error_answer(payload, latency_ms=latency_ms, reason="llm_failed")


def _format_history_text(history: Sequence[ChatHistoryTurn]) -> str:
    """LLM へ渡せるように履歴配列を整形する。

    Args:
        history: ユーザーとアシスタントの過去ターン。

    Returns:
        str: `role: content` 形式で連結した文字列。古い履歴はトリムされる。
    """

    turns = list(history)[-rag_tuning.prompt_history_turns :]
    return "\n".join(f"{turn.role}: {turn.content}" for turn in turns)




def _convert_filters(filters: Optional[ChatQueryFilters]) -> tuple[Optional[DocumentSearchFilters], Optional[FAQSearchFilters]]:
    """チャット API のフィルター構造体を検索用フィルターへ分解する。

    Args:
        filters: 部署やカテゴリなどをまとめたチャットリクエストの条件。

    Returns:
        tuple[DocumentSearchFilters | None, FAQSearchFilters | None]:
            Document/FAQ 向けのフィルターをそれぞれ返す。条件が空なら None。
    """

    if not filters:
        return None, None

    def _normalize(value: Optional[Union[str, list[str]]]) -> Optional[list[str]]:
        """文字列または文字列配列をクエリフィルター用の配列に揃える。

        Args:
            value: 単一／複数指定かもしれないフィルター値。

        Returns:
            list[str] | None: 空文字を除いた正規化済み配列。空になれば None。
        """

        if value is None:
            return None
        if isinstance(value, list):
            cleaned = [str(v).strip() for v in value if str(v).strip()]
            return cleaned or None
        cleaned = str(value).strip()
        return [cleaned] if cleaned else None

    doc_filters = DocumentSearchFilters(
        departments=_normalize(filters.department),
        document_types=_normalize(filters.document_category),
        public_scopes=None,
        statuses=None,
    )
    faq_filters = FAQSearchFilters(
        departments=_normalize(filters.department),
        categories=_normalize(filters.faq_category),
        faq_types=None,
        public_scopes=None,
        statuses=None,
    )

    return doc_filters, faq_filters

# === 会話履歴の永続化・取得（既存アプリ互換） ===

async def save_messages(
    payload: ChatSaveRequest,
    *,
    user: UserContext,
) -> ChatSaveResponse:
    """クライアントから送られた複数メッセージを DB に upsert する。

    Args:
        payload: スレッド ID とメッセージ配列を保持するリクエスト。
        user: 呼び出しユーザー情報（現状は監査用途）。

    Returns:
        ChatSaveResponse: 保存件数や実行結果を表すレスポンス。
    """

    start_ts = time.monotonic()
    logger.info(
        "チャットメッセージ保存を開始",
        extra={
            "thread_id": str(payload.thread_id),
            "message_count": len(payload.messages),
        },
    )

    def _handler(conn):
        """トランザクション内でメッセージ保存とスレッド更新をまとめて行う。

        Args:
            conn: DatabaseConnectionPool から払い出された生接続。

        Returns:
            int: 新規保存できたメッセージ数。
        """

        saved = _insert_messages(conn, thread_id=payload.thread_id, messages=payload.messages)
        if payload.messages:
            latest_ts = payload.messages[-1].created_at
            title = payload.messages[0].content[:50]
            _update_thread_metadata(conn, thread_id=payload.thread_id, latest_timestamp=latest_ts, title_candidate=title)
        return saved

    count = await DatabaseConnectionPool.run_in_transaction_async(_handler)
    logger.info(
        "チャットメッセージ保存が完了",
        extra={
            "thread_id": str(payload.thread_id),
            "saved_count": count,
            "requested_count": len(payload.messages),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return ChatSaveResponse(status="ok", saved_count=count)


async def fetch_history(
    thread_id: UUID,
    *,
    user: UserContext,
    limit: int,
) -> list[dict[str, Any]]:
    """指定スレッドのメッセージ履歴を昇順で取得する。

    Args:
        thread_id: 対象スレッド ID。
        user: 呼び出しユーザー。所有権確認に利用する。
        limit: 取得最大件数。

    Returns:
        list[dict[str, Any]]: DB から取得したメッセージ行。
    """

    start_ts = time.monotonic()
    rows = await _fetch_history_rows(thread_id, user_id=user.id, limit=limit)
    latency_ms = int((time.monotonic() - start_ts) * 1000)
    logger.info(
        "チャット履歴取得が完了",
        extra={
            "thread_id": str(thread_id),
            "row_count": len(rows),
            "latency_ms": latency_ms,
            "limit": limit,
        },
    )
    return rows


def _insert_messages(conn, *, thread_id: UUID, messages: Sequence[ChatSaveMessage]) -> int:
    """messages テーブルへ複数行を挿入し、重複 ID は無視する。

    Args:
        conn: psycopg 接続オブジェクト。
        thread_id: 紐づけ対象のスレッド ID。
        messages: 保存したいメッセージ配列。

    Returns:
        int: 実際に新規挿入できた件数。
    """

    sql = """
        INSERT INTO messages (id, thread_id, role, content, created_at, citations)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (id) DO NOTHING
    """
    saved = 0
    with conn.cursor() as cur:
        for message in messages:
            citations_payload = [
                json.loads(citation.model_dump_json(exclude_none=True))
                for citation in message.citations
            ] if message.citations else []
            cur.execute(
                sql,
                (
                    message.id,
                    thread_id,
                    message.role,
                    message.content,
                    message.created_at,
                    Json(citations_payload),
                ),
            )
            if cur.rowcount:
                saved += 1
    logger.debug(
        "メッセージ挿入処理の結果",
        extra={
            "thread_id": str(thread_id),
            "requested_count": len(messages),
            "inserted_count": saved,
        },
    )
    return saved


def _update_thread_metadata(conn, *, thread_id: UUID, latest_timestamp, title_candidate: str) -> None:
    """最新メッセージ時刻とタイトル候補で threads テーブルを更新する。

    Args:
        conn: psycopg 接続。
        thread_id: 更新対象のスレッド ID。
        latest_timestamp: 履歴で最も新しいメッセージのタイムスタンプ。
        title_candidate: 初回タイトル未設定時に保存するプレフィックス。
    """

    sql = """
        UPDATE threads
           SET updated_at = GREATEST(updated_at, %s),
               title = CASE WHEN title IS NULL OR title = '' THEN %s ELSE title END
         WHERE id = %s
    """
    with conn.cursor() as cur:
        cur.execute(sql, (latest_timestamp, title_candidate, thread_id))


async def _fetch_history_rows(thread_id: UUID, *, user_id: str, limit: int) -> list[dict[str, Any]]:
    """threads/messages テーブルを結合し、ユーザー所有分の履歴を取得する。

    Args:
        thread_id: 取得対象のスレッド。
        user_id: 所有者確認に用いるユーザー ID。
        limit: 取得上限件数。

    Returns:
        list[dict[str, Any]]: DB から生で取得したメッセージ行。
    """

    sql = """
        SELECT m.*
          FROM messages m
          JOIN threads t ON t.id = m.thread_id
         WHERE m.thread_id = %s
           AND t.user_id = %s
           AND t.is_deleted = FALSE
         ORDER BY m.created_at ASC
         LIMIT %s
    """
    return await DatabaseConnectionPool.fetch_all_async(sql, (thread_id, user_id, limit))


def _build_error_answer(
    payload: ChatQueryRequest,
    *,
    latency_ms: int,
    reason: str,
) -> ChatAnswer:
    """ユーザー向けの汎用エラーレスポンスを構築する。

    Args:
        payload: 元の質問（thread_id を保持する）。
        latency_ms: エラー応答までに要した時間。
        reason: ログ用のエラー識別子。

    Returns:
        ChatAnswer: UI 向けの定型文エラーメッセージ。
    """

    logger.error("チャット質問でエラーレスポンスを返却", extra={"reason": reason})
    return ChatAnswer(
        query_id=uuid4(),
        thread_id=payload.thread_id,
        sources_used=[],
        weights={},
        answer=ERROR_MESSAGE,
        citations=[],
        prompt_type="error",
        latency_ms=latency_ms,
    )


__all__ = [
    "ask_question",
    "save_messages",
    "fetch_history",
    "OrchestratorConfig",
]
