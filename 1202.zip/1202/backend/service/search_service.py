"""検索API向けユースケース。"""
from __future__ import annotations

import time

from backend.api.search.schema import DocumentSearchRequest, FAQSearchRequest
from backend.foundation.authentication import UserContext
from backend.foundation.logging import configure_logging
from backend.rag.rag_search import HybridWeights, search_documents_hybrid, search_faqs_hybrid
from backend.rag.config import rag_tuning

logger = configure_logging(__name__)


async def search_documents(
    payload: DocumentSearchRequest,
    *,
    user: UserContext | None = None,
) -> list[dict[str, object]]:
    start_ts = time.monotonic()
    logger.info(
        "ドキュメント検索を開始",
        extra={
            "text_query": (payload.text_query or "")[:120],
            "semantic_query": (payload.semantic_query or "")[:120],
            "limit": payload.limit,
        },
    )
    text_query = payload.text_query or payload.semantic_query or ""
    semantic_queries = []
    if payload.semantic_query:
        semantic_queries.append(payload.semantic_query)
    elif text_query:
        semantic_queries.append(text_query)

    weights = HybridWeights(
        keyword=rag_tuning.hybrid_keyword_weight,
        vector=rag_tuning.hybrid_vector_weight,
    )

    rows = await search_documents_hybrid(
        text_query=text_query,
        semantic_queries=semantic_queries,
        filters=payload.filters,
        limit=payload.limit,
        weights=weights,
        file_name_hints=None,
    )

    results: list[dict[str, object]] = []
    for row in rows[: payload.limit]:
        entry = row.copy()
        entry.setdefault("source", "hybrid")
        results.append(entry)
    logger.info(
        "ドキュメント検索が完了",
        extra={
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
            "result_count": len(results),
            "limit": payload.limit,
        },
    )
    return results


async def search_faqs(
    payload: FAQSearchRequest,
    *,
    user: UserContext | None = None,
) -> list[dict[str, object]]:
    start_ts = time.monotonic()
    logger.info(
        "FAQ検索を開始",
        extra={
            "text_query": (payload.text_query or "")[:120],
            "semantic_query": (payload.semantic_query or "")[:120],
            "limit": payload.limit,
        },
    )
    text_query = payload.text_query or payload.semantic_query or ""
    semantic_queries = []
    if payload.semantic_query:
        semantic_queries.append(payload.semantic_query)
    elif text_query:
        semantic_queries.append(text_query)

    weights = HybridWeights(
        keyword=rag_tuning.hybrid_keyword_weight,
        vector=rag_tuning.hybrid_vector_weight,
    )

    rows = await search_faqs_hybrid(
        text_query=text_query,
        semantic_queries=semantic_queries,
        filters=payload.filters,
        limit=payload.limit,
        weights=weights,
    )

    results: list[dict[str, object]] = []
    for row in rows[: payload.limit]:
        entry = row.copy()
        entry.setdefault("source", "hybrid")
        results.append(entry)
    logger.info(
        "FAQ検索が完了",
        extra={
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
            "result_count": len(results),
            "limit": payload.limit,
        },
    )
    return results


__all__ = ["search_documents", "search_faqs"]
