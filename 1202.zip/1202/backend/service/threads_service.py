"""スレッド（会話単位）に関するユースケースをまとめたモジュール。

チャット画面のサイドバーに表示される「会話の一覧」を扱うため、
作成・論理削除・一覧取得という基本的な処理を提供する。Service 層として、
API ルーターから受け取ったリクエストをデータベース操作へ橋渡しする役割を担う。
"""

from __future__ import annotations

import time
from typing import Any
from uuid import UUID

from backend.foundation.authentication import UserContext
from backend.foundation.database import DatabaseConnectionPool
from backend.foundation.logging import configure_logging
from psycopg2.extensions import connection as PGConnection  # PostgreSQL の接続型（補助関数で利用）

# ログ上の `module` が backend.service.threads_service と読めるようにする。
logger = configure_logging(__name__)


async def create_thread(title: str | None, *, user: UserContext) -> dict[str, Any]:
    """新しいスレッドを作成し、`threads` テーブルへ保存する。

    処理の流れ
    ---------
    1. クライアントから送られてきたタイトルを受け取り、監査用にログへ記録する。
    2. トランザクション内で `_create_thread_transaction` を呼び出し、レコードを挿入する。
    3. 生成された UUID を含むレコードをそのまま呼び出し元へ返却する。

    パラメータ
    ----------
    title:
        スレッドの見出し。未設定の場合は `None` を許容し、DB 側の既定値に任せる。
    user:
        スレッドを作成したユーザー。`user.id` を `threads.user_id` に保存する。

    戻り値
    ------
    `threads` テーブルへ挿入した行を辞書で返す。
    """

    start_ts = time.monotonic()
    logger.info("スレッド作成を開始", extra={"user_id": user.id, "title": title})

    row = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _create_thread_transaction(conn, user_id=user.id, title=title)
    )

    logger.info(
        "スレッド作成が完了",
        extra={
            "user_id": user.id,
            "thread_id": str(row.get("id")),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return row


async def delete_thread(thread_id: UUID, *, user: UserContext) -> dict[str, Any] | None:
    """指定スレッドを論理削除する（`is_deleted` フラグを立てる）。

    パラメータ
    ----------
    thread_id:
        削除対象のスレッド UUID。
    user:
        操作ユーザー。自分のスレッドのみ削除できるよう、SQL の `user_id` 条件に利用する。

    戻り値
    ------
    更新後のスレッド行を辞書で返す。対象が見つからなければ `None`。
    """

    start_ts = time.monotonic()
    logger.info("スレッド削除を開始", extra={"user_id": user.id, "thread_id": str(thread_id)})

    row = await DatabaseConnectionPool.run_in_transaction_async(
        lambda conn: _delete_thread_transaction(conn, thread_id=thread_id, user_id=user.id)
    )

    if not row:
        logger.warning("指定スレッドが見つからず削除不可", extra={"user_id": user.id, "thread_id": str(thread_id)})
        return None

    logger.info(
        "スレッド削除が完了",
        extra={
            "user_id": user.id,
            "thread_id": str(thread_id),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return row


async def list_threads(*, user: UserContext) -> list[dict[str, Any]]:
    """ユーザーが所有するスレッド一覧を更新日時降順で取得する。

    パラメータ
    ----------
    user:
        認証済みユーザー。`threads.user_id` との照合に利用する。

    戻り値
    ------
    スレッド行を辞書化したリスト。論理削除済み (`is_deleted = TRUE`) のものは含まない。
    """

    start_ts = time.monotonic()
    sql = """
        SELECT *
          FROM threads
         WHERE user_id = %s AND is_deleted = FALSE
         ORDER BY updated_at DESC
    """

    threads = await DatabaseConnectionPool.fetch_all_async(sql, (user.id,))

    logger.info(
        "スレッド一覧取得が完了",
        extra={
            "user_id": user.id,
            "count": len(threads),
            "latency_ms": int((time.monotonic() - start_ts) * 1000),
        },
    )
    return threads


def _create_thread_transaction(conn: PGConnection, *, user_id: str, title: str | None) -> dict[str, Any]:
    """`threads` テーブルに 1 件挿入し、挿入した行を辞書で返す。"""
    sql = """
        INSERT INTO threads (user_id, title)
        VALUES (%s, %s)
        RETURNING *
    """
    with conn.cursor() as cur:
        cur.execute(sql, (user_id, title))
        row = cur.fetchone()
        if row is None:
            raise RuntimeError("thread_insert_failed")
        return dict(row)


def _delete_thread_transaction(conn: PGConnection, *, thread_id: UUID, user_id: str) -> dict[str, Any] | None:
    """`threads` の論理削除フラグを更新し、更新後の行を辞書で返す。"""
    sql = """
        UPDATE threads
           SET is_deleted = TRUE,
               deleted_at = NOW(),
               updated_at = NOW()
         WHERE id = %s AND user_id = %s
     RETURNING *
    """
    with conn.cursor() as cur:
        cur.execute(sql, (thread_id, user_id))
        row = cur.fetchone()
        return dict(row) if row else None
