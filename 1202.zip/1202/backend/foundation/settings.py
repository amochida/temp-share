"""環境変数ベースの設定値を一元管理するモジュール。

LangChain ベース設計では LLM / RAG に関するチューニング値が増えるため、
Pydantic の ``BaseSettings`` を活用して `.env` から読み取った値を
構造化オブジェクトとして表現する。
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from pydantic import AliasChoices, Field, validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class LLMSettings(BaseSettings):
    """LLM 切り替えやモデル指定を制御する設定クラス。"""

    env: str = Field(default="development", alias="APP_ENV")
    provider: Optional[str] = Field(default=None, alias="LLM_PROVIDER")

    # Azure OpenAI
    azure_api_key: Optional[str] = Field(default=None, alias="AZURE_OPENAI_API_KEY")
    azure_endpoint: Optional[str] = Field(default=None, alias="AZURE_OPENAI_ENDPOINT")
    azure_api_version: str = Field(default="2024-02-01", alias="AZURE_OPENAI_API_VERSION")
    azure_chat_deployment: Optional[str] = Field(default=None, alias="AZURE_OPENAI_CHAT_DEPLOYMENT")
    azure_chat_deployment_rag_chain: Optional[str] = Field(
        default=None,
        alias="AZURE_OPENAI_CHAT_DEPLOYMENT_RAG_CHAIN",
    )
    azure_chat_deployment_query_rewriter: Optional[str] = Field(
        default=None,
        alias="AZURE_OPENAI_CHAT_DEPLOYMENT_QUERY_REWRITER",
    )
    azure_embedding_deployment: Optional[str] = Field(default=None, alias="AZURE_OPENAI_EMBED_DEPLOYMENT")

    # Ollama
    ollama_base_url: str = Field(default="http://ollama:11434", alias="OLLAMA_BASE_URL")
    ollama_chat_model: str = Field(
        default="qwen2.5:3b",
        alias="OLLAMA_CHAT_MODEL",
        validation_alias=AliasChoices("OLLAMA_CHAT_MODEL", "OLLAMA_DEFAULT_MODEL"),
    )
    ollama_chat_model_rag_chain: Optional[str] = Field(
        default=None,
        alias="OLLAMA_CHAT_MODEL_RAG_CHAIN",
    )
    ollama_chat_model_query_rewriter: Optional[str] = Field(
        default=None,
        alias="OLLAMA_CHAT_MODEL_QUERY_REWRITER",
    )
    ollama_embed_model: str = Field(
        default="mxbai-embed-large",
        alias="OLLAMA_EMBEDDING_MODEL",
        validation_alias=AliasChoices("OLLAMA_EMBEDDING_MODEL", "OLLAMA_EMBED_MODEL"),
    )

    request_timeout: int = Field(default=300, alias="LLM_TIMEOUT_SECONDS")
    embedding_dimension: int = Field(default=1024, alias="EMBEDDING_DIMENSION")

    model_config = SettingsConfigDict(populate_by_name=True, case_sensitive=False)

    @validator("env", pre=True, always=True)
    def _normalize_env(cls, value: str | None) -> str:
        return (value or "development").strip().lower()

    @validator("provider", pre=True, always=True)
    def _resolve_provider(cls, value: str | None, values: dict[str, object]) -> str:
        if value:
            return value.strip().lower()
        app_env = str(values.get("env", "development")).lower()
        if app_env == "development":
            return "ollama"
        return "azure"

    @validator(
        "ollama_base_url",
        "ollama_chat_model",
        "ollama_chat_model_rag_chain",
        "ollama_chat_model_query_rewriter",
        "ollama_embed_model",
        pre=True,
        always=True,
    )
    def _strip_ollama_values(cls, value: str | None) -> str:
        return (value or "").strip()


class RAGSettings(BaseSettings):
    """RAG の機能フラグのみを保持する設定クラス。"""

    use_query_rewriter: bool = Field(default=True, alias="RAG_USE_QUERY_REWRITER")
    use_reranker: bool = Field(default=True, alias="RAG_USE_RERANKER")

    model_config = SettingsConfigDict(populate_by_name=True, case_sensitive=False)


class DevUserSettings(BaseSettings):
    """ローカル開発時に使用する疑似ユーザー設定。"""

    user_id: str = Field(default="dev-user", alias="DEV_USER_ID")
    email: str = Field(default="dev@example.com", alias="DEV_USER_EMAIL")
    department: str = Field(default="Development", alias="DEV_USER_DEPARTMENT")

    model_config = SettingsConfigDict(populate_by_name=True, case_sensitive=False)


@dataclass(frozen=True)
class SearchSettings:
    """全文検索関連の設定。"""

    text_search_config: str = "simple"


class RerankerSettings(BaseSettings):
    """既存リランカー設定との互換用クラス。"""

    provider: str = Field(default="builtin", alias="RERANKER_PROVIDER")
    model_name: str | None = Field(default="lightblue/-reranker-v2-small", alias="RERANKER_MODEL_NAME")
    huggingface_token: str | None = Field(default=None, alias="HUGGINGFACE_API_TOKEN")
    batch_size: int = Field(default=16, alias="RERANKER_BATCH_SIZE")
    timeout: int = Field(default=60, alias="RERANKER_TIMEOUT_SECONDS")

    model_config = SettingsConfigDict(populate_by_name=True, case_sensitive=False)


class AppSettings:
    """アプリケーション全体設定をまとめたラッパークラス。"""

    def __init__(self) -> None:
        self.enable_docs: bool = os.getenv("ENABLE_DOCS", "1") == "1"
        app_env = os.getenv("APP_ENV") or os.getenv("ENVIRONMENT")

        # LLMSettings を先に構築し、その env を全体設定として流用する。
        self.llm = LLMSettings(env=app_env)
        self.environment = self.llm.env

        self.rag = RAGSettings()
        self.dev_user = DevUserSettings()
        self.search = SearchSettings()
        self.reranker = RerankerSettings()


settings = AppSettings()
"""モジュール読み込み時に構築されるグローバル設定インスタンス。"""
