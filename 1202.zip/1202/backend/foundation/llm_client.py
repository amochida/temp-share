"""LLM / Embeddings 利用を LangChain ベースで共通化するユーティリティ。

アプリケーション全体で使用する

    * Chat LLM（会話モデル）
    * Embeddings（テキスト → ベクトル）

の生成とキャッシュを一元管理するモジュール。

役割の概要:
    * settings.llm.provider に応じて Azure OpenAI / Ollama を選択
    * LangChain の Chat LLM / Embeddings インスタンスを構築
    * 生成したインスタンスをグローバルにキャッシュし、再利用

これにより、呼び出し側はベンダー差分や接続情報を意識せず、
「LangChain LLM と Embeddings を取得する」だけで済む設計になっている。
"""

from __future__ import annotations

import asyncio
from collections.abc import Mapping
import time
from typing import Any, Sequence

from langchain_community.chat_models import ChatOllama
from langchain_community.embeddings import OllamaEmbeddings
from langchain_core.embeddings import Embeddings
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings

from backend.foundation.logging import configure_logging
from backend.foundation.settings import LLMSettings, settings

# 共通の構造化ロガーを取得し、本モジュール内の LLM 呼び出し状況を記録できるようにする。
logger = configure_logging(__name__)


class LLMError(RuntimeError):
    """LLM 関連のエラーを表すアプリケーション専用例外。

    LLM 呼び出し（チャット / 埋め込み）で内部エラーや設定不足が発生した場合に送出される。
    標準の例外クラスでは粒度が粗いため、「LLM まわりの問題である」と明確に区別する目的で
    専用の例外クラスを定義している。

    これにより、呼び出し側では:

    * ネットワーク障害や設定ミスなど LLM 由来のエラーと、
    * それ以外のロジックエラー

    を分けてハンドリングしやすくなる。
    """


def _coerce_int(value: Any) -> int | None:
    """任意の値を安全に int 型へ変換するユーティリティ。

    変換できない値（None や "abc" など）が渡された場合は例外を投げず、
    代わりに None を返す。

    初心者向けの背景説明:
        外部サービスから返ってくる値は、常に期待した型であるとは限らない。
        ここでは「トークン数として扱いたいが、本当に数字かどうか分からない」
        という値を安全に int へ変換し、問題があれば None で表現する。

    Args:
        value (Any):
            整数に変換したい任意の値。

    Returns:
        int | None:
            変換に成功した場合は int、失敗した場合は None。
    """
    try:
        # 組み込みの int() を使って数値へ変換を試みる。
        return int(value)
    except (TypeError, ValueError):
        # 型エラーや値エラーが起きた場合は None を返し、呼び出し側での判定に委ねる。
        return None


def extract_token_usage(message: Any) -> dict[str, int | None]:
    """LangChain レスポンスからトークン使用量を抽出し、共通フォーマットに整形する。

    LangChain の AIMessage や ChatResult などには、provider ごとに微妙に異なる形で
    usage_metadata / response_metadata が格納されている。この関数ではそれらの差分を吸収し、
    以下の共通キーを持つ辞書として返す。

    * ``prompt_tokens``: プロンプト側（入力）で消費したトークン数
    * ``completion_tokens``: 応答側（出力）で消費したトークン数
    * ``total_tokens``: 合計トークン数

    初心者向けの背景説明:
        LLM を運用する上で「どれだけトークンを使ったか」を記録しておくことは、
        コスト管理や性能チューニングの観点で非常に重要である。
        しかし、ライブラリやベンダーによって記録しているフィールド名が異なるため、
        ログに出す前にここで統一フォーマットへ変換している。

    Args:
        message (Any):
            LangChain の AIMessage / ChatResult など、トークン情報を含みうるオブジェクト。

    Returns:
        dict[str, int | None]:
            トークン使用量を表す辞書。
            一部の値が取得できない場合は None になることがある。
    """
    # 初期値として None を設定しておき、見つかったものから上書きしていく。
    prompt = completion = total = None

    # usage_metadata を優先的に参照する（provider によって有無やキー名が異なる）
    usage = getattr(message, "usage_metadata", None)
    if isinstance(usage, Mapping):
        # 各種フィールド候補を順番に試しつつ、_coerce_int で安全に整数化する。
        prompt = _coerce_int(
            usage.get("prompt_tokens")
            or usage.get("input_tokens")
            or usage.get("total_prompt_tokens")
        )
        completion = _coerce_int(
            usage.get("completion_tokens")
            or usage.get("output_tokens")
            or usage.get("generated_tokens")
        )
        total = _coerce_int(usage.get("total_tokens"))

    # response_metadata 側にも token_usage / usage フィールドがある場合があるため、追って参照する。
    metadata = getattr(message, "response_metadata", None)
    if isinstance(metadata, Mapping):
        token_usage = metadata.get("token_usage") or metadata.get("usage")
        if isinstance(token_usage, Mapping):
            # 既に値が入っている場合はそちらを優先し、None の場合のみ補完する。
            prompt = prompt or _coerce_int(
                token_usage.get("prompt_tokens") or token_usage.get("input_tokens")
            )
            completion = completion or _coerce_int(
                token_usage.get("completion_tokens")
                or token_usage.get("output_tokens")
            )
            total = total or _coerce_int(token_usage.get("total_tokens"))

    # total が取れなかったが prompt / completion が両方得られている場合は、
    # 足し算して合計トークン数を算出する。
    if total is None and prompt is not None and completion is not None:
        total = prompt + completion

    return {
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": total,
    }


# ---------------------------------------------------------------------------
# Chat LLM / Embeddings のインスタンスをプロセス内でキャッシュするための変数
# ---------------------------------------------------------------------------

# purpose（用途）ごとに Chat LLM インスタンスを保持するキャッシュ。
_chat_llm_cache: dict[str, BaseChatModel] = {}

# Embeddings モデルはアプリケーション全体で 1 つを共有する前提。
_embedding_model: Embeddings | None = None

# purpose が指定されなかったときに使用するデフォルト用途名
_DEFAULT_PURPOSE = "default"


# def reset_llm_cache() -> None:
#     """LLM / Embeddings インスタンスのキャッシュをリセットする。

#     設定変更時やテストコードなどで、「すでに生成済みの LLM / Embeddings を破棄し、
#     次回から新しい設定で作り直したい」というケースで利用する。

#     初心者向けの背景説明:
#         LLM や Embeddings は一度作ると、その後何度も再利用されるようキャッシュされている。
#         しかし、環境変数や設定ファイルを変更した後は、古いインスタンスを使い続けると
#         意図しない動作になる可能性がある。そのため、明示的にキャッシュをクリアする
#         関数を用意している。

#     Args:
#         なし

#     Returns:
#         None:
#             副作用として内部キャッシュがリセットされるだけで、戻り値はない。
#     """
#     global _chat_llm_cache, _embedding_model

#     # Chat LLM キャッシュを空の辞書で上書き
#     _chat_llm_cache = {}

#     # Embeddings インスタンスを破棄（次回呼び出し時に再生成される）
#     _embedding_model = None


def get_langchain_chat_llm(
    *,
    temperature: float | None = None,
    purpose: str | None = None,
) -> BaseChatModel:
    """現在の設定に基づいて LangChain Chat LLM インスタンスを返す。

    settings.llm.provider に応じて Azure OpenAI / Ollama のいずれかを選択し、
    LangChain の Chat LLM インスタンスを構築して返す。

    temperature を明示指定した場合はキャッシュを使わず、その温度で毎回新規インスタンスを生成する。
    これは「retrieval 判定時だけ温度を低めにする」など、用途ごとに温度を変えたいケースに対応するため。

    Args:
        temperature (float | None, optional):
            生成温度。None の場合は内部でデフォルト値 0.2 が使用される。
            値を指定した場合、その値で新しいインスタンスを都度生成する。
        purpose (str | None, optional):
            モデルの用途（例: "default", "rag_chain", "query_rewriter" など）。
            用途によって Azure のデプロイ名や Ollama のモデル名を切り替えたい場合に使用する。

    Returns:
        BaseChatModel:
            LangChain 互換の Chat LLM インスタンス。

    Raises:
        LLMError:
            サポート外の provider が指定されている場合や、
            Azure の接続情報が不足している場合。
    """
    global _chat_llm_cache

    # purpose を正規化して、キャッシュキーとして使用できる形に揃える。
    normalized_purpose = _normalize_purpose(purpose)

    # 明示的な temperature が指定されている場合は、キャッシュを使わず新しいインスタンスを作成する。
    if temperature is not None:
        # 内部ヘルパー _build_chat_llm を呼び出して、指定温度・用途で LLM インスタンスを構築する。
        return _build_chat_llm(temperature=temperature, purpose=normalized_purpose)

    # temperature が None の場合は、用途ごとのキャッシュを参照する。
    model = _chat_llm_cache.get(normalized_purpose)
    if model is None:
        # キャッシュに存在しない場合は _build_chat_llm を呼び出して新規作成する。
        model = _build_chat_llm(purpose=normalized_purpose)
        # 作成したインスタンスをキャッシュに保存して、次回以降の再利用を可能にする。
        _chat_llm_cache[normalized_purpose] = model
    return model


def get_langchain_embeddings() -> Embeddings:
    """現在の設定に基づいて LangChain Embeddings インスタンスを返す。

    settings.llm.provider に応じて Azure OpenAI / Ollama の Embeddings を構築し、
    LangChain の Embeddings 抽象（embed_documents など）として返す。

    Embeddings モデルはアプリケーション全体で 1 インスタンスを共有する前提のため、
    本関数内でキャッシュされ、2 回目以降の呼び出しでは同じインスタンスを返す。

    Args:
        なし

    Returns:
        Embeddings:
            LangChain 互換の Embeddings インスタンス。

    Raises:
        LLMError:
            サポート外の provider が指定されている場合や、
            Azure Embedding の接続情報が不足している場合。
    """
    global _embedding_model

    # まだ Embeddings インスタンスが生成されていない場合は、新しく作成する。
    if _embedding_model is None:
        # 内部ヘルパー _build_embeddings を呼び出して、新しい Embeddings インスタンスを構築する。
        _embedding_model = _build_embeddings()

    # 生成済みのインスタンスを返す。
    return _embedding_model


def _build_chat_llm(
    *,
    temperature: float | None = None,
    purpose: str = _DEFAULT_PURPOSE,
) -> BaseChatModel:
    """設定に基づいて新しい LangChain Chat LLM インスタンスを構築する内部ヘルパー。

    この関数はキャッシュ制御を行わず、毎回新しいインスタンスを返す。
    実際のモデル選択（Azure / Ollama）は settings.llm.provider に基づいて行う。

    Args:
        temperature (float | None):
            生成温度。None の場合は 0.2 をデフォルトとする。
        purpose (str):
            用途を表す文字列。"default" / "rag_chain" / "query_rewriter" など。
            用途に応じて Azure のデプロイ名や Ollama モデル名を切り替える。

    Returns:
        BaseChatModel:
            新しく構築された Chat LLM インスタンス。

    Raises:
        LLMError:
            Azure の接続情報が不足している場合や、サポート外の provider が指定された場合。
    """
    # アプリケーション全体の LLM 設定を取得する。
    cfg = settings.llm
    provider = cfg.provider
    # temperature が None の場合はデフォルト値 0.2 を採用する。
    temp = temperature if temperature is not None else 0.2

    if provider == "azure":
        # Azure 用のチャットデプロイ名を、用途に応じて選択するヘルパーを呼び出す。
        deployment = _select_azure_chat_deployment(cfg, purpose)
        if not cfg.azure_api_key or not cfg.azure_endpoint or not deployment:
            # 接続に必要な情報が一つでも欠けている場合は LLMError を投げる。
            raise LLMError(
                "Azure OpenAI の接続情報が不足しています (APIキー/エンドポイント/デプロイ名)。"
            )
        # AzureChatOpenAI クラスを用いて LangChain 互換の Chat LLM インスタンスを構築する。
        return AzureChatOpenAI(
            azure_deployment=deployment,
            api_version=cfg.azure_api_version,
            api_key=cfg.azure_api_key,
            azure_endpoint=cfg.azure_endpoint,
            temperature=temp,
        )

    if provider == "ollama":
        # Ollama 用のチャットモデル名を、用途に応じて選択するヘルパーを呼び出す。
        model_name = _select_ollama_chat_model(cfg, purpose)
        if not model_name:
            raise LLMError("Ollama のチャットモデル名が設定されていません。")
        # ChatOllama クラスを用いて LangChain 互換の Chat LLM インスタンスを構築する。
        return ChatOllama(
            model=model_name,
            base_url=cfg.ollama_base_url,
            temperature=temp,
        )

    # ここまで到達した場合は provider が未対応の値であるため、エラーとする。
    raise LLMError(f"Unsupported LLM provider: {provider}")


def _build_embeddings() -> Embeddings:
    """設定に基づいて新しい LangChain Embeddings インスタンスを構築する内部ヘルパー。

    provider に応じて AzureOpenAIEmbeddings / OllamaEmbeddings を構築し、
    キャッシュ制御は呼び出し元（get_langchain_embeddings）側に委ねる。

    Args:
        なし

    Returns:
        Embeddings:
            新しく構築された Embeddings インスタンス。

    Raises:
        LLMError:
            Azure Embedding の接続情報が不足している場合や、サポート外の provider が指定された場合。
    """
    # LLM 設定を取得
    cfg = settings.llm
    provider = cfg.provider

    if provider == "azure":
        # Azure Embedding の接続に必要な情報が揃っているか確認
        if not cfg.azure_api_key or not cfg.azure_endpoint or not cfg.azure_embedding_deployment:
            raise LLMError("Azure OpenAI Embedding の接続情報が不足しています。")
        # AzureOpenAIEmbeddings クラスを用いて Embeddings インスタンスを構築する。
        return AzureOpenAIEmbeddings(
            azure_deployment=cfg.azure_embedding_deployment,
            api_key=cfg.azure_api_key,
            azure_endpoint=cfg.azure_endpoint,
            api_version=cfg.azure_api_version,
            dimensions=cfg.embedding_dimension,
        )

    if provider == "ollama":
        # OllamaEmbeddings クラスを用いて Embeddings インスタンスを構築する。
        return OllamaEmbeddings(
            model=cfg.ollama_embed_model,
            base_url=cfg.ollama_base_url,
        )

    # 未対応の provider が指定されていた場合
    raise LLMError(f"Unsupported LLM provider: {provider}")


def _normalize_purpose(purpose: str | None) -> str:
    """用途名（purpose）をキャッシュキーとして扱いやすい形に正規化する。

    ここでは、None や空文字列に対してデフォルト値 `"default"` を適用し、
    前後の空白削除と小文字化を行う。

    Args:
        purpose (str | None):
            正規化対象の用途名。None や空文字列が渡される場合もある。

    Returns:
        str:
            正規化後の用途名。必ず空でない文字列が返る。
    """
    # None を許容しつつ、strip/lower を呼び出せるようにする。
    value = (purpose or _DEFAULT_PURPOSE).strip().lower()
    # strip の結果が空文字列になった場合は、デフォルトに戻す。
    return value or _DEFAULT_PURPOSE


def _select_azure_chat_deployment(cfg: LLMSettings, purpose: str) -> str | None:
    """用途に応じて Azure Chat LLM のデプロイ名を選択する。

    LLMSettings には

    * 共通デプロイ名（azure_chat_deployment）
    * RAG 用デプロイ名（azure_chat_deployment_rag_chain）
    * クエリリライタ用デプロイ名（azure_chat_deployment_query_rewriter）

    のような形で用途ごとの設定を持たせることができる。
    本関数では、用途に応じて適切なデプロイ名を選択し、文字列として返す。

    Args:
        cfg (LLMSettings):
            LLM に関する設定値をまとめたオブジェクト。
        purpose (str):
            用途名。"rag_chain" / "query_rewriter" / "default" など。

    Returns:
        str | None:
            選択されたデプロイ名。設定がない場合は None。
    """
    if purpose == "rag_chain":
        value = cfg.azure_chat_deployment_rag_chain or cfg.azure_chat_deployment
        return value.strip() if isinstance(value, str) else value
    if purpose == "query_rewriter":
        value = cfg.azure_chat_deployment_query_rewriter or cfg.azure_chat_deployment
        return value.strip() if isinstance(value, str) else value
    value = cfg.azure_chat_deployment
    return value.strip() if isinstance(value, str) else value


def _select_ollama_chat_model(cfg: LLMSettings, purpose: str) -> str | None:
    """用途に応じて Ollama のチャットモデル名を選択する。

    Azure と同様に、設定オブジェクト上に

    * 共通モデル名（ollama_chat_model）
    * RAG 用モデル名（ollama_chat_model_rag_chain）
    * クエリリライタ用モデル名（ollama_chat_model_query_rewriter）

    などを定義しておくことを想定している。

    Args:
        cfg (LLMSettings):
            LLM に関する設定値をまとめたオブジェクト。
        purpose (str):
            用途名。"rag_chain" / "query_rewriter" / "default" など。

    Returns:
        str | None:
            選択されたモデル名。設定がない場合は None。
    """
    if purpose == "rag_chain":
        value = cfg.ollama_chat_model_rag_chain or cfg.ollama_chat_model
        return value.strip() if isinstance(value, str) else value
    if purpose == "query_rewriter":
        value = cfg.ollama_chat_model_query_rewriter or cfg.ollama_chat_model
        return value.strip() if isinstance(value, str) else value
    value = cfg.ollama_chat_model
    return value.strip() if isinstance(value, str) else value


# async def chat_completion(
#     messages: Sequence[dict[str, str]],
#     *,
#     temperature: float = 0.2,
#     max_tokens: int = 256,  # noqa: ARG001 - 将来の拡張用プレースホルダ
# ) -> str:
#     """dict 形式のメッセージ配列を受け取り、1 回分のチャット応答テキストを返す互換 API。

#     旧来の dict ベース API 形式:

#         [
#             {"role": "system", "content": "..."},
#             {"role": "user", "content": "..."},
#             ...
#         ]

#     を受け取り、内部では LangChain の Chat LLM を利用して 1 回分の応答テキストを生成する。

#     新しいコードでは `ChatPromptTemplate` や `Runnable` を使うことが推奨されるが、
#     既存コードとの互換性を保つためにこの関数を提供している。

#     初心者向けの背景説明:
#         LangChain を利用した新しい設計では、プロンプトやチェーンをオブジェクトで管理する。
#         しかし既存のコードでは「messages の配列を渡して文字列を受け取る」という
#         シンプルなインターフェースになっていることが多い。
#         この関数は、その古いインターフェースと新しい LangChain ベース実装の間をつなぐ
#         「アダプター」の役割を果たしている。

#     Args:
#         messages (Sequence[dict[str, str]]):
#             role / content キーを持つメッセージ辞書の配列。
#             role は "system" / "user" / "assistant" を想定する。
#         temperature (float, optional):
#             生成温度。値が高いほど出力がランダムになり、低いほど決まった内容になりやすい。
#             デフォルトは 0.2。
#         max_tokens (int, optional):
#             将来の拡張用パラメータ（現時点では未使用）。

#     Returns:
#         str:
#             LLM の応答テキスト。状況によっては空文字列が返ることもある。

#     Raises:
#         LLMError:
#             LangChain または LLM provider 側で例外が発生した場合。
#     """
#     # get_langchain_chat_llm を呼び出して、指定温度の Chat LLM インスタンスを取得する。
#     llm = get_langchain_chat_llm(temperature=temperature)

#     # dict 形式の messages を、LangChain のメッセージオブジェクトへ変換する。
#     # _coerce_to_langchain_message を呼び出して、role に応じた BaseMessage を生成している。
#     lc_messages = [_coerce_to_langchain_message(message) for message in messages]

#     # 呼び出し開始時刻を記録し、後でレイテンシ計測に使用する。
#     start_ts = time.monotonic()
#     try:
#         # LangChain Chat LLM の非同期呼び出し (ainvoke) を行い、応答を取得する。
#         response = await llm.ainvoke(lc_messages)
#     except Exception as exc:  # pragma: no cover - LangChain内部エラー
#         # 例外発生時にはログへ詳細を出力し、LLMError にラップして上位へ伝える。
#         logger.exception("チャット補完処理で例外が発生", extra={"error": str(exc)})
#         raise LLMError("chat completion failed") from exc

#     # レスポンスの形式に応じてテキスト内容を取り出す。
#     if isinstance(response, str):
#         # 文字列そのものが返ってきた場合は strip して利用する。
#         answer_text = response.strip()
#     elif isinstance(response, BaseMessage):
#         # LangChain のメッセージオブジェクトの場合は content フィールドを参照する。
#         content = response.content
#         answer_text = content.strip() if isinstance(content, str) else str(content)
#     else:
#         # 予期しない形式の場合は空文字列を返しておく。
#         answer_text = ""

#     # レイテンシ（処理時間）をミリ秒単位で計測
#     latency_ms = int((time.monotonic() - start_ts) * 1000)

#     # extract_token_usage を呼び出して、レスポンスからトークン使用量を抽出する。
#     usage = extract_token_usage(response)

#     # チャット補完 API の呼び出し結果を情報レベルのログとして記録する。
#     logger.info(
#         "LLMチャット補完の呼び出しが完了",
#         extra={
#             "event": "llm.chat_completion",
#             "latency_ms": latency_ms,
#             "prompt_tokens": usage["prompt_tokens"],
#             "completion_tokens": usage["completion_tokens"],
#             "total_tokens": usage["total_tokens"],
#             "message_count": len(messages),
#         },
#     )

#     # 応答テキストの先頭 200 文字だけをデバッグログとして出力し、内容確認をしやすくする。
#     logger.debug(
#         "チャット補完応答プレビュー",
#         extra={
#             "answer_preview": answer_text[:200],
#             "latency_ms": latency_ms,
#         },
#     )
#     return answer_text


# async def embedding(texts: Sequence[str]) -> list[list[float]]:
#     """テキスト配列に対して埋め込みベクトルを計算する互換 API。

#     LangChain Embeddings の同期メソッド `embed_documents` を内部で呼び出し、
#     非同期コンテキストから利用できるように `run_in_executor` でラップしている。

#     新しいコードでは :func:`backend.infrastructure.embedding_client.compute_embeddings`
#     を利用することが推奨されるが、既存の互換用エンドポイントとして本関数を残している。

#     初心者向けの背景説明:
#         Embeddings とは、テキストを数値ベクトルに変換したもの（ベクトル表現）で、
#         類似検索やクラスタリングなどで利用される。
#         ここでは「既存のシンプルな API インターフェース（文字列の配列 → ベクトルの配列）」
#         を維持しつつ、内部実装だけ LangChain ベースに差し替えている。

#     Args:
#         texts (Sequence[str]):
#             ベクトル化したい文字列の配列。

#     Returns:
#         list[list[float]]:
#             各テキストに対応するベクトル（list[float]）のリスト。

#     Raises:
#         LLMError:
#             Embeddings provider の呼び出しで例外が発生した場合。
#     """
#     # get_langchain_embeddings を呼び出して、共有の Embeddings モデルを取得する。
#     model = get_langchain_embeddings()

#     # 同期メソッド embed_documents を別スレッドで実行するためのラッパー関数を定義する。
#     def _run() -> list[list[float]]:
#         # Embeddings の embed_documents を呼び出し、結果を list に変換して返す。
#         return list(model.embed_documents(list(texts)))

#     # 空配列が渡された場合は、すぐに空のリストを返して無駄な呼び出しを避ける。
#     if not texts:
#         return []

#     # 呼び出し開始時刻を記録する。
#     start_ts = time.monotonic()

#     # 現在のイベントループを取得する。
#     loop = asyncio.get_running_loop()
#     try:
#         # run_in_executor を呼び出して、CPU バウンド/ブロッキングな処理をスレッドプール上で実行する。
#         # これにより、async 関数から同期 API を安全に呼び出せる。
#         vectors = await loop.run_in_executor(None, _run)
#     except Exception as exc:  # pragma: no cover - LangChain内部エラー
#         # 例外発生時にはログに詳細を出力し、LLMError にラップして上位へ伝える。
#         logger.exception("埋め込み生成処理で例外が発生", extra={"error": str(exc)})
#         raise LLMError("embedding provider call failed") from exc

#     # レイテンシをミリ秒単位で計算する。
#     latency_ms = int((time.monotonic() - start_ts) * 1000)

#     # 埋め込み互換 API の呼び出しが完了したことを情報ログとして記録する。
#     logger.info(
#         "LLM埋め込み互換APIの呼び出しが完了",
#         extra={
#             "event": "llm.embedding.compat",
#             "latency_ms": latency_ms,
#             "count": len(texts),
#         },
#     )
#     return vectors


# def _coerce_to_langchain_message(entry: dict[str, str]) -> BaseMessage:
#     """dict 形式のメッセージを LangChain の BaseMessage へ変換する内部ヘルパー。

#     互換 API :func:`chat_completion` で使用されるユーティリティであり、
#     {"role": ..., "content": ...} 形式の辞書を LangChain 標準の

#     * SystemMessage
#     * HumanMessage
#     * AIMessage

#     のいずれかに変換する。

#     Args:
#         entry (dict[str, str]):
#             {"role": ..., "content": ...} 形式のメッセージ辞書。
#             role は "system" / "user" / "assistant" のいずれかを想定し、
#             未指定の場合は "user" とみなす。

#     Returns:
#         BaseMessage:
#             LangChain の SystemMessage / HumanMessage / AIMessage のいずれか。
#     """
#     # role が指定されていない場合は "user" とみなし、小文字化して比較しやすくする。
#     role = entry.get("role", "user").lower()
#     # content が未指定の場合は空文字列として扱う。
#     content = entry.get("content", "")

#     # role の値に応じて、適切なメッセージクラスのインスタンスを返す。
#     if role == "system":
#         return SystemMessage(content=content)
#     if role == "assistant":
#         return AIMessage(content=content)
#     # 上記以外（主に "user"）は HumanMessage として扱う。
#     return HumanMessage(content=content)


__all__ = [
    "LLMError",
    "extract_token_usage",
    # "chat_completion",
    # "embedding",
    "get_langchain_chat_llm",
    "get_langchain_embeddings",
    # "reset_llm_cache",
]
