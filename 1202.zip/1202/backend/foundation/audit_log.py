"""監査ログを専用ファイルへ統一フォーマットで書き込む補助モジュール。

RAG システムでは「誰が・いつ・どのリソースを操作したか」を継続的に追跡する必要がある。
本モジュールは、そのための共通 API を 1 箇所に集約し、アプリケーションのどの層からでも
同じ形式で監査ログを書き込めるようにする。

主な役割:
    - 監査目的のログを JSON 形式で専用ファイルへ出力する
    - 操作者の ID / メールアドレス / 部署など、ユーザー関連情報をまとめて受け取る
    - 任意の辞書オブジェクト payload を一緒に保存し、変更差分や詳細情報を残せる
    - ログファイルは日付ごと (audit_YYYY-MM-DD.log) に分割される

このモジュールを使うことで、「どこで」「どのように」監査ログを書き出すかを意識せず、
サービス層などから単一のインターフェースで一貫した監査ログ記録が行えるようになる。

利用例:
    AuditLogger.record(
        user_id="u12345",
        user_email="user@example.com",
        user_department="生産部",
        action="UPDATE",
        target_type="DOCUMENT",
        target_id="XXXXXXXXXXXXX",
        payload={"title": "就業規則", "status": "published"},
    )
"""

from __future__ import annotations

from typing import Any, Optional

from backend.foundation.logging import configure_logging
from backend.foundation.request_context import current_request_id

# ---------------------------------------------------------------------------
# AuditLogger クラス定義: 操作ログ（監査ログ）を記録するためのヘルパー
# ---------------------------------------------------------------------------


class AuditLogger:
    """監査ログ記録処理を集約したユーティリティクラス

    このクラスは、アプリケーション中で発生した「誰が・何をしたか」を
    一貫した形式でログとして残すための窓口となる。

    監査ログは、セキュリティインシデントや不正操作の調査、運用保守での
    問い合わせ対応などにおいて重要な手がかりとなるため、アプリケーション
    ログとは別に、専用のファイルへ記録する方針とする。

    本クラスでは、スタティックメソッド record() を通じて監査ログを
    1 件分記録できる。呼び出し側はインスタンスを作成する必要はなく、
    どこからでも AuditLogger.record(...) を呼び出すだけで利用できる。

    特徴:
        - JSON 形式で構造化された監査ログを出力する
        - 操作者情報と対象リソース情報を 1 つのレコードにまとめて保存する
        - 任意の追加情報を payload として柔軟に付与できる
        - request_id との紐づけにより、同一リクエスト内の処理をトレースしやすくする
    """

    # クラスレベルロガー
    # 監査ログ専用のロガーを作成する
    # ここでは共通ロギング設定関数 configure_logging() を呼び出して、
    # 「audit_YYYY-MM-DD.log」という日付付きファイルに出力されるロガーを生成している
    _logger = configure_logging(__name__, static_log_stem="audit")

    @staticmethod
    def record(
        *,
        user_id: str,
        user_email: Optional[str] = None,
        user_department: Optional[str] = None,
        action: str,
        target_type: str,
        target_id: Optional[str] = None,
        payload: Optional[dict[str, Any]] = None,
    ) -> None:
        """監査ログを 1 件分記録する。

        このメソッドは、サービス層やユースケース層など「ビジネスロジックを実装する層」から
        呼び出されることを想定している。ユーザーが何らかの操作を行ったタイミングで、
        その操作内容を監査ログとして残したい場合に利用する。

        Args:
            user_id (str):
                操作を行ったユーザーの一意な ID。
            user_email (Optional[str], optional):
                ユーザーのメールアドレス。
            user_department (Optional[str], optional):
                ユーザーが所属している部署名や組織名。
            action (str):
                ユーザーが行った操作の種類を表す文字列。
            target_type (str):
                操作対象の種類を表す文字列。
            target_id (Optional[str], optional):
                操作対象の一意な ID。ドキュメントID、FAQIDなど。
            payload (Optional[dict[str, Any]], optional):
                操作に関する追加情報を格納する辞書。

        Returns:
            None:
                戻り値なし、監査ログファイルへ 1 行分の JSON ログを出力する。

        Raises:
            ValueError:
                必須項目である user_id, action, target_type のいずれかが
                空文字列または未指定だった場合に送出される。

        Examples:
            ユーザーが文書を更新した際に監査ログを記録する例:

            >>> AuditLogger.record(
            ...     user_id="u12345",
            ...     user_email="user@example.com",
            ...     user_department="HR",
            ...     action="UPDATE",
            ...     target_type="DOCUMENT",
            ...     target_id="doc-001",
            ...     payload={"title_before": "旧タイトル", "title_after": "新タイトル"},
            ... )

        """

        # 監査ログとして最低限必要な項目が指定されているか確認する
        if not user_id or not action or not target_type:
            raise ValueError("user_id, action, and target_type are required for audit logging")

        # 現在の処理に紐づけられたリクエスト ID を取得する
        # current_request_id() は、リクエストごとに割り当てられた ID を返し、
        # アプリケーションログと監査ログを紐づけて追跡するのに役立つ
        normalized_request_id = current_request_id()

        # 監査ログとして出力する情報を 1 つの辞書にまとめる
        # この辞書は logging モジュールの extra 引数として渡され、
        # JSON 形式の構造化ログとして記録される
        log_payload = {
            "user_id": user_id,
            "user_email": user_email,
            "user_department": user_department,
            "action": action,
            "target_type": target_type,
            "target_id": target_id,
            "payload": payload,
            "request_id": normalized_request_id,
        }

        # ロガーの info メソッドを呼び出して監査ログを 1 件分出力する
        # メッセージ文字列には簡潔な説明を入れ、詳細な情報は extra で渡した辞書に持たせている
        AuditLogger._logger.info("監査レコードを記録しました", extra=log_payload)
