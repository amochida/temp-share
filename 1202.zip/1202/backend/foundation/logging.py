"""全サービスで共通利用する構造化ロギングユーティリティ。


本モジュールは Python 標準の logging モジュールを薄くラップし、
以下の要件を満たすロガーを簡単に生成できるようにする。

主な特徴:
    - すべてのログを JSON 形式に統一する
    - 標準出力と /var/log/rag 配下のファイルへの二重出力に対応
    - 日付＋容量（10MB）で自動ローテーションし、1 日あたり最大 30 個までファイルを保持
    - ログディレクトリへの書き込み権限が不足している場合は、自動的に標準出力のみへフォールバック


利用例:
    >>> logger = configure_logging(__name__)
    >>> logger.info(
    ...     "ドキュメント作成開始",
    ...     extra={"event": "documents.create.start", "user_id": "u123"},
    ... )

"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from threading import RLock
from typing import Optional
from zoneinfo import ZoneInfo

from backend.foundation.request_context import current_api_name, current_request_id, current_user_id


# ---------------------------------------------------------------------------
# ログディレクトリ設定
# ---------------------------------------------------------------------------

# ログファイルの出力先ディレクトリ
_DEFAULT_LOG_DIR = os.getenv("LOG_DIR", "/var/log/rag")

# 実際に使用するログディレクトリの Path オブジェクト
_LOG_DIR: Optional[Path] = Path(_DEFAULT_LOG_DIR)

# API ごとに 1 つだけ共有されるファイルハンドラ（動的な API 名でファイルを分ける場合に使用）
_API_FILE_HANDLER: Optional["TimedSizeRotatingFileHandler"] = None

# 固定ファイル名（static_log_stem）でログを出し分けたいときのハンドラキャッシュ
# 例えば "audit" ログ用のファイルハンドラなどをここに保持する
_STATIC_FILE_HANDLERS: dict[str, "TimedSizeRotatingFileHandler"] = {}

# API 名が取得できなかった場合に使用するフォールバック名
_DEFAULT_API_FALLBACK = "unknown"

# ログのタイムスタンプとして使用するタイムゾーン
_LOG_TZ = ZoneInfo(os.getenv("LOG_TZ", "Asia/Tokyo"))

# ログディレクトリを生成する
try:
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
except PermissionError:
    _LOG_DIR = None


# ---------------------------------------------------------------------------
# カスタムハンドラ: 日付＋サイズローテーション対応
# ---------------------------------------------------------------------------

class _DailySizedFileHandler(RotatingFileHandler):
    """日付付きの個別ログファイルに書き込むためのハンドラ。

    日単位でファイル名を変えつつ、一定サイズ（バイト数）を超えたら
    RotatingFileHandler の機能でローテーションさせる役割を担う。

    """

    def __init__(
        self,
        file_stem: str,
        *,
        max_bytes: int,
        backup_count: int,
        encoding: str,
    ) -> None:
        """日付付きログファイルハンドラを初期化する。

        Args:
            file_stem (str):
                ログファイル名の接頭辞。実際のファイル名は
                {file_stem}_YYYY-MM-DD.log の形式となる。
            max_bytes (int):
                1 ファイルあたりの最大サイズ（バイト数）。
                このサイズを超えるとローテーションが行われる。
            backup_count (int):
                ローテーション時に保持するファイル数。
                これを超えた古いファイルは削除される。
            encoding (str):
                ログファイルの文字エンコーディング。
        """
        # ログディレクトリが利用可能であることを前提とする
        assert _LOG_DIR is not None

        # ログファイル名の接頭辞を保持
        self.file_stem = file_stem
        # 現在のログファイルに紐づく日付文字列を保持（例: "2025-12-02"）
        self.current_date = datetime.now().strftime("%Y-%m-%d")

        # 実際のログファイルパスを組み立てる
        log_file = _LOG_DIR / f"{self.file_stem}_{self.current_date}.log"

        # 親クラス RotatingFileHandler のコンストラクタを呼び出し、
        # ローテーションの条件（サイズ・バックアップ数・エンコーディング）を設定する
        super().__init__(
            filename=str(log_file),
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding=encoding,
        )

    def shouldRollover(self, record: logging.LogRecord) -> bool:
        """ローテーションが必要かどうかを判定する。

        日付の変化とファイルサイズの両方をチェックし、どちらかの条件を満たした場合に
        ローテーションフラグを立てる。

        Args:
            record (logging.LogRecord):
                これから書き込もうとしているログレコード。

        Returns:
            bool:
                ローテーションが必要な場合は True、不要な場合は False。
        """
        # 現在のシステム日付（文字列）を取得
        new_date = datetime.now().strftime("%Y-%m-%d")

        # ---- 日付ローテーションの判定 ----
        # 日付が変わっていたら、ログファイルを新しい日付のファイルへ切り替える
        if new_date != self.current_date:
            self.current_date = new_date
            # 日付変更に伴い、書き込み先ファイルを切り替えるメソッドを呼び出す
            self._switch_to_current_date()
            return False

        # ---- サイズローテーションの判定 ----
        if self.maxBytes > 0:
            # ファイルの末尾へ移動して現在のファイルサイズを取得
            self.stream.seek(0, 2)
            if self.stream.tell() >= self.maxBytes:
                # 最大サイズを超えていた場合はローテーション対象
                return True

        # どちらの条件も満たさなければローテーション不要
        return False

    def _switch_to_current_date(self) -> None:
        """日付変更時に新しい日付のログファイルへ書き込み先を切り替える。"""

        assert _LOG_DIR is not None

        # baseFilename を新しい日付のファイル名に更新する
        self.baseFilename = str(_LOG_DIR / f"{self.file_stem}_{self.current_date}.log")

        # 既存のストリームがあればクローズし、再度ファイルを開き直す
        if self.stream:
            self.stream.close()
        # 親クラスの _open メソッドを呼び出して新しいファイルストリームを取得
        self.stream = self._open()


class TimedSizeRotatingFileHandler(logging.Handler):
    """API 名やサービス名ごとにログファイルを振り分けるためのラッパーハンドラ。

    内部的には _DailySizedFileHandler を複数個（API 名ごとなど）保持し、
    ログレコードの内容に応じて適切なハンドラを選択して書き込む。

    """

    def __init__(
        self,
        service_name: str,
        *,
        dynamic_naming: bool = True,
        fallback_api_name: str = _DEFAULT_API_FALLBACK,
        max_bytes: int = 10 * 1024 * 1024,
        backup_count: int = 30,
        encoding: str = "utf-8",
    ) -> None:
        """ラッパーハンドラを初期化する。

        Args:
            service_name (str):
                サービスやアプリケーションを識別する名前。
                dynamic_naming が False の場合は、この名前をそのまま
                ログファイル名の接頭辞として利用する。
            dynamic_naming (bool, optional):
                True の場合は、API 名（api_name）ごとにファイルを分ける。
                False の場合は、service_name 固定のファイルに書き込む。
            fallback_api_name (str, optional):
                API 名が取得できなかった場合に使用するフォールバック名。
            max_bytes (int, optional):
                1 ファイルあたりの最大サイズ（バイト数）。
            backup_count (int, optional):
                ローテーション時に保持するバックアップファイル数。
            encoding (str, optional):
                ログファイルの文字エンコーディング。
        """
        # 親クラス logging.Handler の初期化を呼び出す
        super().__init__()

        # ログディレクトリが None（利用不可）でないことを前提とする
        # もし None であれば、上位のロジックでファイルハンドラ自体が使われないようにしている
        assert _LOG_DIR is not None

        # インスタンス変数へ設定値を保持
        self.service_name = service_name
        self.dynamic_naming = dynamic_naming
        self.fallback_api_name = fallback_api_name
        self.max_bytes = max_bytes
        self.backup_count = backup_count
        self.encoding = encoding

        # 複数スレッドから同時にハンドラ辞書を触っても安全なようにロックを用意
        self._lock = RLock()

        # API 名（または service_name）ごとに _DailySizedFileHandler を保持する辞書
        self._handlers: dict[str, _DailySizedFileHandler] = {}

        # まずは "unknown" などのフォールバックキーで 1 つハンドラを作成し、
        # ファイルへの書き込み権限があるかどうか事前に検証しておく。
        seed_key = self.service_name if not self.dynamic_naming else self.fallback_api_name

        # _DailySizedFileHandler を生成して、初期ハンドラとして登録する。
        self._handlers[seed_key] = _DailySizedFileHandler(
            seed_key,
            max_bytes=self.max_bytes,
            backup_count=self.backup_count,
            encoding=self.encoding,
        )

    def emit(self, record: logging.LogRecord) -> None:
        """実際にログレコードを書き込む処理。

        ログレコードごとに適切な _DailySizedFileHandler を選択し、その emit を呼び出す。

        Args:
            record (logging.LogRecord):
                書き込み対象のログレコード。
        """
        try:
            # ログレコードの内容から、どのファイルに書き込むべきかを判定し、
            # 対応する _DailySizedFileHandler を取得する。
            handler = self._get_handler(record)
            # 選択された下位ハンドラに処理を委譲して、実際のファイル書き込みを行う。
            handler.emit(record)
        except Exception:  # noqa: BLE001 - logging の設計上必要
            # 例外発生時には handleError を呼び出し、ログフレームワークの標準的な
            # エラー処理（標準エラー出力への出力など）に任せる。
            self.handleError(record)

    def flush(self) -> None:
        """保持しているすべてのハンドラに対して flush を実行する。"""

        # 登録されている各 _DailySizedFileHandler に対して flush を順番に呼び出す。
        for handler in self._handlers.values():
            handler.flush()

    def close(self) -> None:
        """保持しているすべてのハンドラをクローズし、リソースを解放する。"""

        try:
            # すべての下位ハンドラをクローズする
            for handler in self._handlers.values():
                handler.close()
        finally:
            # ハンドラ辞書をクリアしてから、親クラスの close を呼び出す
            self._handlers.clear()
            super().close()

    def setFormatter(self, fmt: logging.Formatter) -> None:
        """自分自身と保持している全ての下位ハンドラにフォーマッタを設定する。"""

        # まずは自分自身のフォーマッタを設定
        super().setFormatter(fmt)

        # すでに作成されているすべての _DailySizedFileHandler に対しても
        # 同じフォーマッタを適用しておく。
        for handler in self._handlers.values():
            handler.setFormatter(fmt)

    def _get_handler(self, record: logging.LogRecord) -> _DailySizedFileHandler:
        """レコードの内容に応じて使用する下位ハンドラを返す。

        Args:
            record (logging.LogRecord):
                振り分けに使用するログレコード。

        Returns:
            _DailySizedFileHandler:
                書き込みに使用すべきハンドラ。
        """
        # ログレコードに応じて、ファイル名の接頭辞（file_stem）を決定する。
        key = self._determine_file_stem(record)

        # 複数スレッドからのアクセスを考慮してロックを取得
        with self._lock:
            # まだそのキーのハンドラが存在しなければ、新たに作成する。
            if key not in self._handlers:
                # _DailySizedFileHandler を生成してハンドラ辞書に登録
                handler = _DailySizedFileHandler(
                    key,
                    max_bytes=self.max_bytes,
                    backup_count=self.backup_count,
                    encoding=self.encoding,
                )
                # 既に自分自身にフォーマッタが設定されていれば、それを下位ハンドラにも適用
                if self.formatter:
                    handler.setFormatter(self.formatter)
                self._handlers[key] = handler

            # 最終的に利用するハンドラを返す
            return self._handlers[key]

    def _determine_file_stem(self, record: logging.LogRecord) -> str:
        """API 名やサービス名から、ログファイル名の接頭辞を決定する。

        Args:
            record (logging.LogRecord):
                判定に使用するログレコード。

        Returns:
            str:
                ログファイルの接頭辞として利用する文字列。
        """
        # dynamic_naming が False の場合は、常に service_name 固定のファイルに書き込む。
        if not self.dynamic_naming:
            return self.service_name

        # ログレコードに api_name 属性があればそれを優先し、
        # 無ければ request_context から API 名を取得する。
        api_name = getattr(record, "api_name", None) or current_api_name()

        # いずれも取得できなかった場合はフォールバック名を利用する。
        return api_name or self.fallback_api_name


class RequestIdLoggingFilter(logging.Filter):
    """ログレコードに request_id フィールドを補完するフィルター。

    """

    def filter(self, record: logging.LogRecord) -> bool:
        """ログレコードへ request_id を設定する。

        Args:
            record (logging.LogRecord):
                フィルタリング対象のログレコード。

        Returns:
            bool:
                常に True を返し、レコードをログ出力処理に通す。
        """
        # すでに request_id が設定されていなければ、現在のリクエスト ID を補完する。
        if not hasattr(record, "request_id") or record.request_id is None:
            # 現在のリクエストコンテキストから request_id を取得して設定
            record.request_id = current_request_id()
        return True


class ApiNameLoggingFilter(logging.Filter):
    """API 名 (api_name) をログへ常に含めるためのフィルター。

    api_name は「どの API エンドポイントから出たログか」を表し、
    後からログを絞り込む際に非常に有用である。
    """

    def filter(self, record: logging.LogRecord) -> bool:
        """ログレコードへ api_name を設定する。

        Args:
            record (logging.LogRecord):
                フィルタリング対象のログレコード。

        Returns:
            bool:
                常に True を返し、レコードをログ出力処理に通す。
        """
        # すでに api_name が設定されていなければ、現在の API 名を補完する。
        if not hasattr(record, "api_name") or record.api_name is None:
            # リクエストコンテキストから API 名を取得し、
            # 無ければフォールバック文字列（unknown）を利用する。
            record.api_name = current_api_name() or _DEFAULT_API_FALLBACK
        return True


class UserIdLoggingFilter(logging.Filter):
    """ログレコードに user_id を安定して付与するためのフィルター。

    ユーザー ID が未指定の場合でも null としてフィールドを補完し、
    JSON のスキーマがレコードごとに変わらないようにする。
    """

    def filter(self, record: logging.LogRecord) -> bool:
        """ログレコードへ user_id を設定する。

        Args:
            record (logging.LogRecord):
                フィルタリング対象のログレコード。

        Returns:
            bool:
                常に True を返し、レコードをログ出力処理に通す。
        """
        # すでに user_id が設定されていなければ、現在のユーザー ID を補完する。
        if not hasattr(record, "user_id") or record.user_id is None:
            # current_user_id() は認証情報などからユーザー ID を取得し、
            # 未ログインなどの場合は None を返すことを想定している。
            record.user_id = current_user_id()
        return True


# ---------------------------------------------------------------------------
# ロガー設定関数
# ---------------------------------------------------------------------------


def _create_json_formatter(jsonlogger_module) -> logging.Formatter:
    """構造化ログ用の JSON フォーマッタを生成するヘルパー関数。

    Args:
        jsonlogger_module:
            pythonjsonlogger モジュールを受け取る。

    Returns:
        logging.Formatter:
            JSON 形式の構造化ログを出力するためのフォーマッタインスタンス。
    """

    def _json_dumps(obj: dict[str, object], **kwargs: object) -> str:
        """JSON シリアライザラッパー。

        日本語などの非 ASCII 文字をそのまま出力するために
        ensure_ascii=False を固定で付与する。
        """
        kwargs["ensure_ascii"] = False
        return json.dumps(obj, **kwargs)

    class _ISO8601Formatter(jsonlogger_module.JsonFormatter):
        """ISO 8601 形式のタイムスタンプを出力するためのカスタムフォーマッタ。"""

        def formatTime(self, record: logging.LogRecord, datefmt: Optional[str] = None) -> str:
            """ログレコードの時刻情報を ISO 8601 形式の文字列に変換する。"""

            # ログレコードの作成時刻（エポック秒）を、指定のタイムゾーンに変換
            timestamp = datetime.fromtimestamp(record.created, tz=_LOG_TZ)
            # ミリ秒単位まで含めた ISO 8601 文字列に変換して返す
            return timestamp.isoformat(timespec="milliseconds")

    # _ISO8601Formatter を用いて JSON フォーマッタインスタンスを生成する。
    # fmt にはログレコードからどのフィールドを取り出すかを指定する。
    return _ISO8601Formatter(
        fmt="%(asctime)s %(levelname)s %(request_id)s %(api_name)s %(name)s %(message)s %(user_id)s",
        rename_fields={
            "asctime": "timestamp",
            "levelname": "level",
            "name": "module",
        },
        json_serializer=_json_dumps,
    )


def configure_logging(logger_name: str, *, static_log_stem: Optional[str] = None) -> logging.Logger:
    """サービス／モジュールごとの JSON 構造化ロガーを構成する。

    Args:
        logger_name (str):
            logging.getLogger に渡すロガー名。
            通常は __name__ を指定し、モジュールパスを module フィールドに出力させる。
        static_log_stem (Optional[str], optional):
            "audit" のように API 名ごとではなく固定ファイル名でログを出力したい場合に指定する。
            指定しない場合は、API 名（api_name）ごとにファイルを振り分ける。

    Returns:
        logging.Logger:
            構成済みのロガーインスタンス。以降はこのロガーに対して
            info, warning, error などのメソッドを呼び出せばよい。

    Raises:
        例外はハンドラ生成時のファイル I/O などから発生しうるが、
        多くの場合は内部でキャッチされ、標準出力のみへのフォールバックに切り替わる。
    """
    import sys
    from pythonjsonlogger import jsonlogger

    # ---- 環境変数からログレベルを読み込み ----
    # LOG_LEVEL が指定されていなければ INFO をデフォルトとする。
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()

    # ---- JSON 形式のフォーマッタ設定 ----
    # _create_json_formatter を呼び出して、python-json-logger ベースの
    # JSON フォーマッタを生成する。
    json_formatter = _create_json_formatter(jsonlogger)

    # ---- サービス専用ロガーを構築 ----
    # logging.getLogger を呼び出して、指定された名前のロガーを取得する。
    logger = logging.getLogger(logger_name)
    logger.setLevel(log_level)
    # 上位ロガー（root ロガーなど）への伝播を無効化し、重複出力を防ぐ。
    logger.propagate = False

    # 各ログレコードに request_id / api_name / user_id を自動補完するフィルターを追加する。
    logger.addFilter(RequestIdLoggingFilter())
    logger.addFilter(ApiNameLoggingFilter())
    logger.addFilter(UserIdLoggingFilter())

    # 既にハンドラが設定されている場合は、一度クリアして再構成する。
    if logger.handlers:
        logger.handlers.clear()

    # ---- コンソール（標準出力）ハンドラ設定 ----
    # logging.StreamHandler を生成し、標準出力に JSON ログを出すよう設定する。
    console_handler = logging.StreamHandler(sys.stdout)
    # JSON フォーマッタをコンソールハンドラに設定
    console_handler.setFormatter(json_formatter)
    # ロガーにコンソールハンドラを追加
    logger.addHandler(console_handler)

    # ---- ファイルハンドラ（日付＋サイズローテーション対応）----
    # ログディレクトリが利用可能かどうかに応じて、ファイルハンドラを設定する。
    file_warning_emitted = False
    try:
        # _resolve_file_handler を呼び出して、API 単位／固定ファイルいずれかに
        # 適したファイルハンドラを取得する。
        file_handler = _resolve_file_handler(static_log_stem)
    except OSError as exc:
        # ここで例外が起きた場合はファイル出力をあきらめ、標準出力のみとする。
        file_handler = None
        file_warning_emitted = True
        logger.warning(
            "ログファイルハンドラの有効化に失敗したため標準出力のみを使用",
            extra={
                "service": logger_name,
                "log_dir": str(_DEFAULT_LOG_DIR),
                "reason": str(exc),
            },
        )

    if file_handler is not None:
        # ファイルハンドラにも JSON フォーマッタを適用
        file_handler.setFormatter(json_formatter)
        # ロガーにファイルハンドラを追加
        logger.addHandler(file_handler)
    elif not file_warning_emitted:
        # ディレクトリ自体が利用できない場合など、ファイルハンドラが生成できなかった場合には
        # 警告ログを 1 度だけ出力し、標準出力のみでの運用に切り替える。
        logger.warning(
            "ログディレクトリを利用できないため標準出力のみで継続",
            extra={
                "service": logger_name,
                "log_dir": str(_DEFAULT_LOG_DIR),
                "message": "falling back to stdout only",
            },
        )

    # ---- 初期化ログを出力（ロガー設定確認用）----
    # 構造化ロガーがどのように設定されたかを確認できるよう、情報ログを 1 件出す。
    logger.info(
        "構造化ロガーの初期化が完了",
        extra={
            "service": logger_name,
            "log_level": log_level,
            "rotation": "daily+10MB" if file_handler else "stdout-only",
            "pattern": f"{(static_log_stem or 'api_name')}_YYYY-MM-DD.log",
            "log_dir": str(_DEFAULT_LOG_DIR),
            "encoding": "utf-8",
            "ensure_ascii": False,
            "log_scope": "dedicated" if static_log_stem else "per_api",
        },
    )

    # デバッグレベルでは、実際にロガーにぶら下がっているハンドラ一覧も出力しておく。
    logger.debug(
        "ロガーに設定されたハンドラ一覧",
        extra={
            "service": logger_name,
            "handlers": [type(handler).__name__ for handler in logger.handlers],
        },
    )

    # 設定済みのロガーを呼び出し元へ返す
    return logger


def _resolve_file_handler(static_log_stem: Optional[str]) -> Optional[TimedSizeRotatingFileHandler]:
    """API 単位／固定ファイルいずれの場合でも適切なファイルハンドラを返す。

    この関数は、以下の 2 パターンを切り替えるためのヘルパーである。

    - static_log_stem が指定されている場合:
        例えば "audit" のような固定プレフィックスのファイルに対してログを書き込む。
        同じ static_log_stem を複数回指定しても、同一のハンドラインスタンスを再利用する。
    - static_log_stem が None の場合:
        API 名ごと（api_name）にファイルを分けるための共有ハンドラを返す。

    Args:
        static_log_stem (Optional[str]):
            固定ファイル名の接頭辞。None の場合は API 名ごとのファイル出力を行う。

    Returns:
        Optional[TimedSizeRotatingFileHandler]:
            利用可能な場合は適切なファイルハンドラ、それ以外の場合は None。
    """
    global _API_FILE_HANDLER

    # ログディレクトリが None の場合はファイル出力ができないため、None を返す。
    if _LOG_DIR is None:
        return None

    # ---- 固定ファイル名用のハンドラ生成 ----
    if static_log_stem:
        # まだ指定された static_log_stem のハンドラが存在しなければ作成してキャッシュ
        if static_log_stem not in _STATIC_FILE_HANDLERS:
            # TimedSizeRotatingFileHandler を生成し、dynamic_naming=False にすることで
            # API 名ではなく static_log_stem 固定のファイルに書き込む。
            _STATIC_FILE_HANDLERS[static_log_stem] = TimedSizeRotatingFileHandler(
                static_log_stem,
                dynamic_naming=False,
            )
        # キャッシュ済みのハンドラを返す
        return _STATIC_FILE_HANDLERS[static_log_stem]

    # ---- API 単位のファイル出力用ハンドラ生成 ----
    if _API_FILE_HANDLER is None:
        # 「api」というサービス名で共有ハンドラを 1 つだけ生成する。
        _API_FILE_HANDLER = TimedSizeRotatingFileHandler("api")

    # 共有ハンドラを返す
    return _API_FILE_HANDLER
