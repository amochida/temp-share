"""リクエスト単位の情報（特に request_id）を扱う補助モジュール。

FastAPI のミドルウェアから ``bind_request_id`` を呼び出すことで、処理中の
タスクから常に同じ request_id を取得できる。ContextVar を利用しているため、
asyncio のタスク切り替えが発生しても値が混ざらない。
"""

from __future__ import annotations

from contextvars import ContextVar, Token
from typing import Optional

# ContextVar は非同期タスクごとに固有の値を保持できる。
_request_id_var: ContextVar[Optional[str]] = ContextVar("request_id", default=None)
_api_name_var: ContextVar[Optional[str]] = ContextVar("api_name", default=None)
_user_id_var: ContextVar[Optional[str]] = ContextVar("user_id", default=None)


def bind_request_id(request_id: str) -> Token:
    """現在のコンテキストに request_id を紐付ける。"""

    return _request_id_var.set(request_id)


def reset_request_id(token: Token) -> None:
    """ContextVar の値を登録前の状態へ戻す。"""

    _request_id_var.reset(token)


def current_request_id() -> Optional[str]:
    """現在のコンテキストに紐付いた request_id を返す。"""

    return _request_id_var.get()


def bind_api_name(api_name: str) -> Token:
    """処理対象の API 名を ContextVar に紐付ける。"""

    return _api_name_var.set(api_name)


def reset_api_name(token: Token) -> None:
    """API 名の ContextVar を登録前の状態へ戻す。"""

    _api_name_var.reset(token)


def current_api_name() -> Optional[str]:
    """現在のコンテキストに紐付いた API 名を取得する。"""

    return _api_name_var.get()


def bind_user_id(user_id: str) -> Token:
    """現在のコンテキストに user_id を紐付ける。"""

    return _user_id_var.set(user_id)


def reset_user_id(token: Token) -> None:
    """user_id の ContextVar を登録前の状態へ戻す。"""

    _user_id_var.reset(token)


def current_user_id() -> Optional[str]:
    """現在のリクエストに紐付いた user_id を返す。"""

    return _user_id_var.get()
