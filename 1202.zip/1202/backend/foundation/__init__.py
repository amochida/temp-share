"""基盤層モジュールの公開エントリーポイント。

共通依存（認証・DB・ロギング・設定など）を一括で import できるようにする。
"""

from .audit_log import AuditLogger
from .authentication import UserContext, UserContextDependency, get_user_context
from .database import DatabaseConnectionPool
from .logging import configure_logging
from .llm_client import (
    LLMError,
    # chat_completion,
    # embedding,
    get_langchain_chat_llm,
    get_langchain_embeddings,
)
from .settings import settings

__all__ = [
    "AuditLogger",
    "UserContext",
    "UserContextDependency",
    "get_user_context",
    "DatabaseConnectionPool",
    "configure_logging",
    "LLMError",
    # "chat_completion",
    # "embedding",
    "get_langchain_chat_llm",
    "get_langchain_embeddings",
    "settings",
]
