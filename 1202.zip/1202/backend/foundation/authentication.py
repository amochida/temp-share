"""FastAPI へ認証済みユーザー情報を安全に供給するための補助モジュール。

Apache（社内SSOゲートウェイ）から挿入されるリクエストヘッダーを解析し、
FastAPI の各エンドポイントで利用しやすい辞書形式（:class:`UserContext`）へ整形して返す。
本モジュールを介すことで、「ヘッダー読み取り」「欠損時のフォールバック」といった
周辺処理を一箇所に閉じ込め、業務ロジック側は `user.id` など直感的なアクセスのみで
ユーザー情報を扱えるようになる。

想定している主な責務は以下のとおり。

* `X-User-Id` / `X-User-Email` / `X-User-Department` ヘッダーの取り出しと整形
* FastAPI の依存解決（:func:`fastapi.Depends`）を通じた自動注入
* 開発環境でヘッダーが付与されない場合の疑似ユーザー値フォールバック

利用例::

    @router.post("/documents")
    async def create_document(user: UserContextDependency):
        # user は UserContext 型。辞書アクセスとプロパティアクセスの双方に対応。
        print(user.id, user.email)
"""

from __future__ import annotations  # 型ヒントで後方参照を許可（Python 3.7+）

from typing import Annotated, AsyncIterator
from fastapi import Depends, Header, HTTPException, status

from backend.foundation.settings import settings
from backend.foundation.request_context import bind_user_id, reset_user_id


# ---------------------------------------------------------------------------
# UserContext クラス定義: ユーザー情報を保持する軽量オブジェクト
# ---------------------------------------------------------------------------

class UserContext(dict):
    """社内認証基盤から受け取ったユーザー情報を保持する軽量オブジェクト。

    ``dict`` を継承しているため ``user["user_id"]`` のような辞書参照が可能であり、
    あわせて ``user.id`` や ``user.email`` といったプロパティ経由のアクセスも
    提供する。SSO 側で真正性の検証が完結している想定のため、ここでは追加検証を行わない。
    """

    @property
    def id(self) -> str:
        """ユーザーIDを返す。"""
        return self.get("user_id", "")

    @property
    def email(self) -> str:
        """ユーザーのメールアドレスを返す。"""
        return self.get("email", "")

    @property
    def department(self) -> str:
        """所属部門名を返す。"""
        return self.get("department", "")


# ---------------------------------------------------------------------------
# 依存関数: ヘッダーから UserContext を生成
# ---------------------------------------------------------------------------

async def get_user_context(
    user_id: Annotated[str | None, Header(alias="X-User-Id")] = None,
    email: Annotated[str | None, Header(alias="X-User-Email")] = None,
    department: Annotated[str | None, Header(alias="X-User-Department")] = None,
) -> AsyncIterator[UserContext]:
    """非同期ジェネレータとして実装した UserContext 依存関数。

    FastAPI 0.111 以降で同期ジェネレータ依存が threadpool に移される問題を避けるため、
    async def + AsyncIterator に変更し、ContextVar の bind/reset が
    同一イベントループ内で実行されるようにする。
    """

    # Header が無い場合（dev 環境の fallback）
    if user_id is None:
        if settings.environment != "production":
            dev = settings.dev_user
            context = UserContext(
                user_id=dev.user_id,
                email=email or dev.email,
                department=department or dev.department,
            )
            token = bind_user_id(context.id)
            try:
                yield context
            finally:
                reset_user_id(token)
            return

        # 本番で user_id が無い場合 → 401
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing required header: X-User-Id (expected from SSO gateway)",
        )

    # 正常経路（header に user_id あり）
    context = UserContext(
        user_id=user_id,
        email=email or "",
        department=department or "",
    )
    token = bind_user_id(context.id)
    try:
        yield context
    finally:
        reset_user_id(token)


# ---------------------------------------------------------------------------
# FastAPI Depends 用エイリアス: 簡潔に利用できる形式で公開
# ---------------------------------------------------------------------------

UserContextDependency = Annotated[UserContext, Depends(get_user_context)]
