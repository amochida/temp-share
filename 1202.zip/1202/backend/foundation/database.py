"""PostgreSQL 接続ユーティリティ（psycopg2 ベース）。

Python 初心者でも迷わないように、以下の方針で実装している。

* 接続情報はすべて環境変数から読み取る（Docker Compose と .env に揃える）
* psycopg2 のコネクションプールを使い、サービス全体で安全に再利用する
* SQL の実行は `RealDictCursor` で辞書形式に統一し、上位層（service 層）が扱いやすくする
* `with` 構文でトランザクション管理を隠蔽し、commit / rollback の書き忘れを防ぐ
* 非同期コード（FastAPI の async 関数）からも扱えるよう、`asyncio.to_thread` を用いた薄いラッパを用意

本モジュール以外では psycopg2 を直接 import せず、ここで定義した関数・クラスのみを利用する。
これにより「DB まわりは foundation.database を読むだけ」で全体像を把握できる構造になる。

初心者向けの背景説明:
    データベース接続周りのコードは、プロジェクト全体のあちこちに分散させると、
    以下のような問題が起きやすくなる。

    * 接続文字列やプール設定が場所ごとにバラバラになる
    * commit / rollback の書き忘れによるバグが混入しやすい
    * 非同期コードからのアクセス方法が統一されない

    そこで、本モジュールに「接続の作り方・使い方」をすべて集約し、
    上位層からはシンプルなメソッド（fetch_one / fetch_all / execute など）を
    呼び出すだけで適切なトランザクション管理とロギングが行われるようにしている。
"""

from __future__ import annotations

import asyncio
import os
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Optional, Sequence, TypeVar

import psycopg2
from psycopg2 import OperationalError
from psycopg2 import extensions
from psycopg2.extensions import QuotedString, connection as PGConnection, register_adapter
from psycopg2.extras import RealDictCursor, register_uuid
from psycopg2.pool import SimpleConnectionPool

from backend.foundation.logging import configure_logging

# psycopg2 はデフォルトでは uuid.UUID 型を正しく扱えないことがあるため、
# register_uuid() を呼び出して、uuid 用のグローバルアダプタを登録する。
register_uuid()


class PgVector(list):
    """pgvector カラムへ保存するためのベクトル（float の配列）を保持する軽量コンテナ。

    Python 側では単なる list[float] として扱いつつ、DB へ送る際には
    pgvector 拡張が期待する文字列表現（"[0.123456, 0.234567, ...]"）に変換される。

    初心者向けの背景説明:
        PostgreSQL の pgvector 拡張は、「ベクトル型」をサポートする拡張機能で、
        類似度検索（ベクトル検索）などに利用される。
        psycopg2 からこの型を扱うためには、Python オブジェクトを
        DB 側の文字列表現に変換するアダプタを登録する必要がある。
        このクラスは、そうした変換の対象となる「ベクトル」を表すコンテナである。

    Args:
        values (Optional[Sequence[float]]):
            初期値として詰める float のシーケンス。None の場合は空リストとして扱う。
    """

    def __init__(self, values: Optional[Sequence[float]] = None):
        # None の場合は空リストとして扱う。
        values = values or []
        # 親クラス list の初期化を呼び出し、すべて float 型にキャストした値を格納する。
        super().__init__(float(v) for v in values)


def _format_pgvector(values: Sequence[float]) -> str:
    """pgvector 型が期待する文字列表現（"[0.100000, ...]"）へ変換する。

    Args:
        values (Sequence[float]):
            ベクトルとして保存したい float 値のシーケンス。

    Returns:
        str:
            pgvector が受け付ける文字列表現。
            空のベクトルの場合は "[]" を返す。
    """
    # 要素が 1 つもない場合は "[]" を返す。
    if not values:
        return "[]"

    # 各要素を小数点以下 6 桁にフォーマットし、カンマ区切りで連結する。
    formatted = ", ".join(f"{float(value):.6f}" for value in values)
    return f"[{formatted}]"


def _adapt_pgvector(vector: PgVector) -> QuotedString:
    """psycopg2 が `PgVector` をシリアライズできるようにするためのアダプタ。

    psycopg2 側では、独自クラスを DB へ送る際に「どのような文字列に変換するか」を
    register_adapter() で登録しておく必要がある。この関数はそのアダプタとして使われ、
    PgVector → QuotedString(pgvector 形式の文字列) への変換を担う。

    Args:
        vector (PgVector):
            DB に保存したいベクトルコンテナ。

    Returns:
        QuotedString:
            pgvector 拡張が解釈できる文字列表現をラップした QuotedString。
    """
    # _format_pgvector() を呼び出して、pgvector 形式の文字列に変換する。
    return QuotedString(_format_pgvector(vector))


# register_adapter() を呼び出し、PgVector 型を psycopg2 が扱えるように登録する。
register_adapter(PgVector, _adapt_pgvector)

# ジェネリックな戻り値の型を表す TypeVar。
T = TypeVar("T")

# SQL をログに出す際に、どこまでの長さを表示するかの上限（文字数）。
_SQL_PREVIEW_LIMIT = 240


def _shorten_sql(sql: str) -> str:
    """SQL 文をログ向けに短縮し、1 行のコンパクトな文字列として返す。

    余分な改行・空白を詰めて 1 行にし、長すぎる場合は末尾に "..." を付けて切り詰める。

    Args:
        sql (str):
            元の SQL 文（複数行やインデント付きでもよい）。

    Returns:
        str:
            ログ出力に適した 1 行の SQL 文字列。
    """
    # split() / join() を使い、すべての空白を 1 つのスペースにまとめる。
    compact = " ".join(sql.split())
    # 長さが上限を超える場合は先頭だけを残して "..." を付ける。
    if len(compact) > _SQL_PREVIEW_LIMIT:
        return compact[:_SQL_PREVIEW_LIMIT] + "..."
    return compact


def _preview_params(params: Iterable[Any] | None) -> str | None:
    """バインドパラメータをログ出力向けに安全な形で短縮表示する。

    引数に渡された params のうち、先頭数件だけを repr() した文字列として返す。
    大量のパラメータや巨大な文字列が含まれていてもログが肥大化しないように、
    文字数は 200 文字までに制限する。

    Args:
        params (Iterable[Any] | None):
            SQL プレースホルダにバインドされる値のシーケンス。
            None の場合はパラメータなしとして扱う。

    Returns:
        str | None:
            ログ出力向けに短縮された文字列表現。
            params が None の場合は None。
    """
    if params is None:
        return None
    try:
        # list/tuple の場合は先頭 5 要素だけ取り出して repr() する。
        if isinstance(params, (list, tuple)):
            sliced = params[:5]
            text = repr(sliced)
        else:
            # それ以外はそのまま repr() した結果を使う。
            text = repr(params)
        # 文字数が 200 を超える場合は末尾に "..." を付けて切り詰める。
        return text[:200] + ("..." if len(text) > 200 else "")
    except Exception:
        # repr() 自体が失敗した場合でもログ出力が落ちないよう、固定文言を返す。
        return "(unavailable)"


@dataclass(slots=True)
class DatabaseConfig:
    """環境変数から読み取った DB 接続設定を保持する小さなコンフィグクラス。

    このクラスは「DB 接続に必要な情報」を 1 つの入れ物としてまとめておき、
    `psycopg2.connect` や `SimpleConnectionPool` に渡すための辞書を生成する役割を持つ。

    初心者向けの背景説明:
        DB 接続情報（ホスト名・ポート・ユーザー名など）をコードに直接書いてしまうと、
        環境ごとに値が変わるたびにコードを書き換える必要があり、非常に危険である。
        そのため、一般的には環境変数からこれらの値を読み取り、アプリケーションは
        「環境変数をどう構成するか」という契約だけを決めておく。

    Attributes:
        host (str):
            PostgreSQL サーバーのホスト名。
        port (int):
            PostgreSQL サーバーのポート番号。
        user (str):
            接続に使用するユーザー名。
        password (str):
            接続に使用するパスワード。
        database (str):
            接続先のデータベース名。
        sslmode (str):
            SSL 接続モード（"prefer" など）。
        min_size (int):
            コネクションプールの最小接続数。
        max_size (int):
            コネクションプールの最大接続数。
    """

    host: str = os.getenv("POSTGRES_HOST", "localhost")
    port: int = int(os.getenv("POSTGRES_PORT", "5432"))
    user: str = os.getenv("POSTGRES_USER", "rag")
    password: str = os.getenv("POSTGRES_PASSWORD", "rag")
    database: str = os.getenv("POSTGRES_DB", "rag")
    sslmode: str = os.getenv("POSTGRES_SSLMODE", "prefer")
    min_size: int = int(os.getenv("POSTGRES_POOL_MIN", "1"))
    max_size: int = int(os.getenv("POSTGRES_POOL_MAX", "10"))

    def connection_kwargs(self) -> dict[str, Any]:
        """`psycopg2.connect` にそのまま渡せるキーワード引数を組み立てて返す。

        RealDictCursor を cursor_factory として指定しているため、上位層では
        「1 行 = dict」として統一的に扱うことができる。

        Args:
            なし

        Returns:
            dict[str, Any]:
                psycopg2.connect / SimpleConnectionPool に渡すための設定辞書。
        """
        # psycopg2.connect() に渡すための基本的な接続情報を辞書として構築する。
        kwargs: dict[str, Any] = {
            "host": self.host,
            "port": self.port,
            "user": self.user,
            "password": self.password,
            "dbname": self.database,
            # RealDictCursor を指定して、結果を dict として取得できるようにする。
            "cursor_factory": RealDictCursor,
        }
        # sslmode が設定されている場合のみ、追加で指定する。
        if self.sslmode:
            kwargs["sslmode"] = self.sslmode
        return kwargs


class DatabaseConnectionPool:
    """PostgreSQL 用のコネクションプール管理クラス。

    アプリケーション全体で 1 つのコネクションプールを共有し、

    * プールの初期化 / クローズ
    * 接続の貸し出し / 返却（トランザクション管理込み）
    * 同期クエリヘルパー（execute / fetch_one / fetch_all）
    * 非同期ラッパー（async 関数から DB を叩くための薄い層）

    を一括して提供する。

    初心者向けの背景説明:
        毎回 `psycopg2.connect()` を呼んで接続を作り直すと、

        * パフォーマンスが悪くなる
        * コネクションが増えすぎて DB 側の制限を超える

        などの問題が起こりやすい。そこで、接続は「プール」にまとめておき、
        アプリケーションからは必要なときにプールから 1 本借りる、という形にする。
        本クラスは、その「借りる」「返す」「トランザクションを張る」といった
        一連の流れを隠蔽してくれる窓口である。
    """

    # 実際の psycopg2 コネクションプール（SimpleConnectionPool）を保持するクラス変数。
    _pool: SimpleConnectionPool | None = None

    # 使用する DB 設定（環境変数から読み取ったもの）を保持する。
    _config = DatabaseConfig()

    # configure_logging() を呼び出して、このモジュール用の構造化ロガーを取得する。
    _logger = configure_logging(__name__)

    # DB 接続取得時にリトライする最大回数（環境変数 DB_RETRY_ATTEMPTS で上書き可能）。
    _RETRY_ATTEMPTS = int(os.getenv("DB_RETRY_ATTEMPTS", "3"))
    # リトライ間隔（秒）。attempt 値に応じて増加させる。
    _RETRY_DELAY = float(os.getenv("DB_RETRY_DELAY", "0.5"))

    # ------------------------------------------------------------------
    # ライフサイクル管理
    # ------------------------------------------------------------------
    @classmethod
    def initialize(cls) -> None:
        """コネクションプールを初期化する（FastAPI の startup で 1 度だけ呼ぶ想定）。

        既にプールが初期化されている場合は何もしない（多重初期化を防ぐ）。
        成功すると SimpleConnectionPool インスタンスが `_pool` に格納される。

        Args:
            なし

        Returns:
            None:
                副作用として `_pool` が設定される。
        """
        # すでにプールが存在する場合は再初期化せず、デバッグログだけ出して終了する。
        if cls._pool is not None:
            cls._logger.debug(
                "接続プールは既に初期化済みです",
                extra={"event": "db_pool.already_initialized"},
            )
            return

        # 現在の DB 設定を取得する。
        cfg = cls._config
        # 接続プールの初期化を開始したことを情報ログとして記録する。
        cls._logger.info(
            "接続プールの初期化を開始",
            extra={
                "host": cfg.host,
                "port": cfg.port,
                "database": cfg.database,
                "min_size": cfg.min_size,
                "max_size": cfg.max_size,
            },
        )
        # SimpleConnectionPool を生成して、接続プールを初期化する。
        # connection_kwargs() を呼び出して、psycopg2.connect 用のキーワード引数を取得している。
        cls._pool = SimpleConnectionPool(
            cfg.min_size,
            cfg.max_size,
            **cfg.connection_kwargs(),
        )

    @classmethod
    def close(cls) -> None:
        """コネクションプールを安全に閉じる（FastAPI の shutdown で呼ぶ想定）。

        プールからすべてのコネクションを閉じ、内部状態をリセットする。
        既にプールが存在しない場合は何もしない。

        Args:
            なし

        Returns:
            None:
                副作用として、プールが破棄される。
        """
        if cls._pool is None:
            return
        # プールをクローズすることを情報ログとして記録する。
        cls._logger.info("接続プールをクローズ", extra={"event": "db_pool.close"})
        # SimpleConnectionPool.closeall() を呼び出して、全コネクションを閉じる。
        cls._pool.closeall()
        cls._pool = None

    # ------------------------------------------------------------------
    # 内部ユーティリティ
    # ------------------------------------------------------------------
    @classmethod
    def _ensure_pool(cls) -> SimpleConnectionPool:
        """コネクションプールを必ず初期化済みの状態で返す内部ヘルパー。

        未初期化の場合は initialize() を呼び出してプールを構築する。
        それでも `_pool` が None のままであれば、初期化失敗とみなして例外を送出する。

        Args:
            なし

        Returns:
            SimpleConnectionPool:
            利用可能なコネクションプールインスタンス。

        Raises:
            RuntimeError:
                initialize() による初期化が失敗し、プールが利用できない場合。
        """
        # まだプールが作られていない場合は initialize() を呼び出して初期化する。
        if cls._pool is None:
            cls.initialize()
        if cls._pool is None:  # pragma: no cover - initialize が失敗した場合
            raise RuntimeError("Database connection pool is not ready")
        return cls._pool

    @classmethod
    def _acquire(cls) -> PGConnection:
        """プールから接続を 1 つ取得し、オートコミットを無効化した状態で返す。

        接続取得に失敗した場合は、設定された回数だけリトライを行う。
        全ての試行に失敗した場合は RuntimeError を送出する。

        Args:
            なし

        Returns:
            PGConnection:
                オートコミットが False に設定された PostgreSQL 接続オブジェクト。

        Raises:
            RuntimeError:
                全てのリトライで OperationalError が発生し、接続取得に失敗した場合。
        """
        last_exc: OperationalError | None = None

        # 設定された回数だけ接続取得をリトライするループ。
        for attempt in range(1, cls._RETRY_ATTEMPTS + 1):
            try:
                # _ensure_pool() を呼び出して、必ず初期化済みのプールを取得する。
                pool = cls._ensure_pool()
                # プールからコネクションを 1 つ借り出す。
                conn = pool.getconn()
                # トランザクションを手動で制御するため、autocommit を False に設定する。
                conn.autocommit = False
                return conn
            except OperationalError as exc:
                # OperationalError が発生した場合は警告ログを残し、再試行する。
                last_exc = exc
                cls._logger.warning(
                    "DB接続の取得をリトライ",
                    extra={"attempt": attempt, "max": cls._RETRY_ATTEMPTS, "error": str(exc)},
                )
                if attempt == cls._RETRY_ATTEMPTS:
                    # 最終試行で失敗した場合はループを抜ける。
                    break
                # リトライ間隔として _RETRY_DELAY * attempt 秒スリープする。
                time.sleep(cls._RETRY_DELAY * attempt)

        # ここまで来たら全ての試行に失敗しているため、RuntimeError を送出する。
        raise RuntimeError("failed to acquire database connection") from last_exc

    @classmethod
    def _release(cls, conn: Optional[PGConnection]) -> None:
        """借り出した接続を安全にプールへ戻す。

        トランザクション中のエラーなどで不整合な状態になっている可能性を考慮し、
        プールへ返却する前に、必要に応じて rollback を試みる。

        Args:
            conn (Optional[PGConnection]):
                プールへ返却したいコネクション。None の場合は何もしない。

        Returns:
            None:
                副作用として、接続がプールへ返却される。
        """
        pool = cls._pool
        if pool is None or conn is None:
            return
        try:
            # get_transaction_status() を呼び出して現在のトランザクション状態を確認する。
            status = conn.get_transaction_status()
            if status not in (
                extensions.TRANSACTION_STATUS_IDLE,
                extensions.TRANSACTION_STATUS_UNKNOWN,
            ):
                # トランザクション中（IDLE 以外）の場合は、一旦 rollback を行ってから返却する。
                conn.rollback()
        except Exception:  # pragma: no cover - rollback失敗はログのみ
            # rollback 自体に失敗した場合でもアプリケーションが落ちないようにし、
            # 警告ログのみを出力する。
            cls._logger.warning(
                "プールへ戻す前のrollbackに失敗",
                extra={"event": "db_pool.rollback_before_return.failed"},
            )
        # SimpleConnectionPool.putconn() を呼び出して、接続をプールへ返却する。
        pool.putconn(conn)

    # ------------------------------------------------------------------
    # Context manager API
    # ------------------------------------------------------------------
    @classmethod
    @contextmanager
    def connection(cls) -> Iterable[PGConnection]:
        """単純な接続を `with` 構文で貸し出すコンテキストマネージャ。

        commit / rollback は呼び出し側に任せたいが、接続の取得・返却は共通化したい場合に使う。

        使用例::

            with DatabaseConnectionPool.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1")

        Args:
            なし

        Yields:
            PGConnection:
                psycopg2 のコネクションオブジェクト。
        """
        conn: PGConnection | None = None
        try:
            # _acquire() を呼び出して、プールから接続を借り出す。
            conn = cls._acquire()
            # 呼び出し側へコネクションを貸し出す。
            yield conn
        finally:
            # 処理が終わったら _release() を呼び出して接続をプールへ返却する。
            cls._release(conn)

    @classmethod
    @contextmanager
    def transaction(cls) -> Iterable[PGConnection]:
        """トランザクションを自動 commit / rollback 付きで扱うコンテキストマネージャ。

        with ブロックが正常に終了した場合は commit、例外が発生した場合は rollback を行う。
        これにより、commit / rollback の書き忘れを防ぎつつ、トランザクション境界を
        `with` ブロックで明示的に表現できる。

        使用例::

            with DatabaseConnectionPool.transaction() as conn:
                with conn.cursor() as cur:
                    cur.execute("INSERT ...")

        Args:
            なし

        Yields:
            PGConnection:
                トランザクション中の psycopg2 コネクションオブジェクト。
        """
        conn: PGConnection | None = None
        try:
            # _acquire() を呼び出して、プールから接続を借り出す。
            conn = cls._acquire()
            # 呼び出し側へコネクションを貸し出す。
            yield conn
            # with ブロックが正常終了した場合は commit を行う。
            conn.commit()
        except Exception:
            # 例外が発生した場合は rollback を行ってから例外を再送出する。
            if conn is not None:
                conn.rollback()
            raise
        finally:
            # 最終的には _release() を呼び出して接続をプールへ返却する。
            cls._release(conn)

    # ------------------------------------------------------------------
    # 同期クエリヘルパー
    # ------------------------------------------------------------------
    @classmethod
    def fetch_one(
        cls,
        sql: str,
        params: Iterable[Any] | None = None,
        *,
        connection: PGConnection | None = None,
    ) -> dict[str, Any] | None:
        """単一行を辞書形式で取得するためのヘルパー。

        RealDictCursor により、1 行分の結果が dict[str, Any] として返る。

        Args:
            sql (str):
                SELECT 文など、単一行の結果を想定した SQL。
            params (Iterable[Any] | None, optional):
                SQL のプレースホルダにバインドする値のシーケンス。
            connection (PGConnection | None, optional):
                既存の接続を明示的に渡す場合に使用。
                None の場合は内部でコネクションを借りて実行する。

        Returns:
            dict[str, Any] | None:
                取得した 1 行を表す辞書。結果が存在しない場合は None。
        """

        def _run(conn: PGConnection) -> dict[str, Any] | None:
            """実際に 1 行分の結果を取得する内部関数。"""
            start = time.monotonic()
            # conn.cursor() を呼び出し、RealDictCursor により dict として行を取得する。
            with conn.cursor() as cur:
                # execute() を呼び出して SQL を実行する。
                cur.execute(sql, params)
                # fetchone() を呼び出して、最初の 1 行だけ取得する。
                row = cur.fetchone()
            latency_ms = int((time.monotonic() - start) * 1000)
            # 取得結果があれば dict(row) で通常の dict に変換する。
            result = dict(row) if row else None
            # 実行結果を情報ログとして記録する。
            cls._logger.info(
                "DBクエリで1行取得",
                extra={
                    "operation": "fetch_one",
                    "latency_ms": latency_ms,
                    "found": bool(result),
                    "sql": _shorten_sql(sql),
                    "params_preview": _preview_params(params),
                },
            )
            return result

        # _with_connection() を呼び出して、トランザクションなしで _run を実行する。
        return cls._with_connection(connection, transactional=False, handler=_run)

    @classmethod
    def fetch_all(
        cls,
        sql: str,
        params: Iterable[Any] | None = None,
        *,
        connection: PGConnection | None = None,
    ) -> list[dict[str, Any]]:
        """複数行を辞書リストで取得するためのヘルパー。

        RealDictCursor により、各行が dict[str, Any] として返され、
        それらを要素とするリストを返す。

        Args:
            sql (str):
                SELECT 文など、複数行の結果を想定した SQL。
            params (Iterable[Any] | None, optional):
                SQL のプレースホルダにバインドする値のシーケンス。
            connection (PGConnection | None, optional):
                既存の接続を明示的に渡す場合に使用。
                None の場合は内部でコネクションを借りて実行する。

        Returns:
            list[dict[str, Any]]:
                各行を表す辞書のリスト。該当行がない場合は空リスト。
        """

        def _run(conn: PGConnection) -> list[dict[str, Any]]:
            """実際に複数行の結果を取得する内部関数。"""
            start = time.monotonic()
            # conn.cursor() を呼び出し、RealDictCursor により dict として行を取得する。
            with conn.cursor() as cur:
                # execute() を呼び出して SQL を実行する。
                cur.execute(sql, params)
                # fetchall() を呼び出して、すべての行を取得する。
                rows = cur.fetchall() or []
            latency_ms = int((time.monotonic() - start) * 1000)
            # RealDictRow のリストを通常の dict のリストに変換する。
            result = [dict(row) for row in rows]
            # 実行結果を情報ログとして記録する。
            cls._logger.info(
                "DBクエリで複数行取得",
                extra={
                    "operation": "fetch_all",
                    "latency_ms": latency_ms,
                    "row_count": len(result),
                    "sql": _shorten_sql(sql),
                    "params_preview": _preview_params(params),
                },
            )
            return result

        # _with_connection() を呼び出して、トランザクションなしで _run を実行する。
        return cls._with_connection(connection, transactional=False, handler=_run)

    @classmethod
    def run_in_transaction(cls, handler: Callable[[PGConnection], T]) -> T:
        """コールバックに同一接続を貸し出し、1 トランザクションでまとめて処理する。

        複数の SQL を 1 つのトランザクションとして扱いたい場合に利用する。
        handler 内で例外が発生した場合は rollback、それ以外は commit される。

        Args:
            handler (Callable[[PGConnection], T]):
                コネクションを引数に取り、任意の処理を行うコールバック関数。

        Returns:
            T:
                コールバック関数の戻り値。
        """
        # transaction() コンテキストマネージャを使ってトランザクションを開始する。
        with cls.transaction() as conn:
            # handler を呼び出して、トランザクション内で処理を実行する。
            return handler(conn)

    # ------------------------------------------------------------------
    # 非同期（async/await）から利用するためのラッパ
    # ------------------------------------------------------------------
    @classmethod
    async def _run_async(cls, func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
        """同期関数をスレッドプール経由で実行する内部ヘルパー。

        psycopg2 は同期ライブラリのため、そのまま async 関数から呼び出すと
        イベントループをブロックしてしまう。そこで asyncio.to_thread() を使って
        別スレッドで同期関数を実行し、async/await インターフェースを提供する。

        Args:
            func (Callable[..., T]):
                スレッドプール上で実行したい同期関数。
            *args (Any):
                同期関数へ渡す位置引数。
            **kwargs (Any):
                同期関数へ渡すキーワード引数。

        Returns:
            T:
                同期関数の戻り値。
        """
        # asyncio.to_thread() を呼び出して、指定した関数をスレッドプール上で実行する。
        return await asyncio.to_thread(func, *args, **kwargs)

    @classmethod
    async def fetch_one_async(
        cls,
        sql: str,
        params: Iterable[Any] | None = None,
    ) -> dict[str, Any] | None:
        """同期版 `fetch_one` を非同期コンテキストから利用できるようにするラッパ。

        asyncio.to_thread() 経由で `fetch_one` を実行し、イベントループをブロックしない。

        Args:
            sql (str):
                SELECT 文など、単一行の結果を想定した SQL。
            params (Iterable[Any] | None, optional):
                SQL のプレースホルダにバインドする値のシーケンス。

        Returns:
            dict[str, Any] | None:
                取得した 1 行を表す辞書。結果が存在しない場合は None。
        """
        # _run_async() を呼び出して、同期版 fetch_one をスレッドプール上で実行する。
        return await cls._run_async(cls.fetch_one, sql, params)

    @classmethod
    async def fetch_all_async(
        cls,
        sql: str,
        params: Iterable[Any] | None = None,
    ) -> list[dict[str, Any]]:
        """同期版 `fetch_all` を非同期コンテキストから利用できるようにするラッパ。

        大量データを取得する場合でも、イベントループを塞がないように
        スレッドプール経由で処理を実行する。

        Args:
            sql (str):
                SELECT 文など、複数行の結果を想定した SQL。
            params (Iterable[Any] | None, optional):
                SQL のプレースホルダにバインドする値のシーケンス。

        Returns:
            list[dict[str, Any]]:
                各行を表す辞書のリスト。
        """
        # _run_async() を呼び出して、同期版 fetch_all をスレッドプール上で実行する。
        return await cls._run_async(cls.fetch_all, sql, params)

    @classmethod
    async def run_in_transaction_async(cls, handler: Callable[[PGConnection], T]) -> T:
        """トランザクション付き処理を非同期コンテキストから利用できるようにしたラッパ。

        同期版 :meth:`run_in_transaction` をスレッドプール経由で実行し、
        async 関数からも「1 トランザクションでまとめて処理する」ことを可能にする。

        Args:
            handler (Callable[[PGConnection], T]):
                コネクションを引数に取り、任意の処理を行うコールバック関数。

        Returns:
            T:
                コールバック関数の戻り値。
        """
        # _run_async() を呼び出して、同期版 run_in_transaction をスレッドプール上で実行する。
        return await cls._run_async(cls.run_in_transaction, handler)

    # ------------------------------------------------------------------
    # 内部ヘルパー
    # ------------------------------------------------------------------
    @classmethod
    def _with_connection(
        cls,
        connection: PGConnection | None,
        *,
        transactional: bool,
        handler: Callable[[PGConnection], T],
    ) -> T:
        """共通化された「接続を貸し出して handler を実行する」ための内部ヘルパー。

        明示的に渡された connection があればそれをそのまま使用し、
        無い場合は transaction() または connection() を使って新たに接続を借りる。

        Args:
            connection (PGConnection | None):
                既存の接続を利用したい場合に渡すコネクション。
                None の場合は内部で新しく接続を借りる。
            transactional (bool):
                True の場合は transaction() を使ってトランザクションを開始し、
                False の場合は connection() を使って単純な接続として扱う。
            handler (Callable[[PGConnection], T]):
                コネクションを引数に取り、実際の DB 処理を行う関数。

        Returns:
            T:
                handler の戻り値。
        """
        # 既にコネクションが渡されている場合は、そのまま handler に渡して使ってもらう。
        if connection is not None:
            return handler(connection)

        # トランザクションが必要かどうかに応じて、適切なコンテキストマネージャを選択する。
        context = cls.transaction() if transactional else cls.connection()
        # with 構文でコンテキストマネージャを開き、conn を handler に渡して処理を実行する。
        with context as conn:  # type: ignore[assignment]
            return handler(conn)


__all__ = ["DatabaseConnectionPool", "DatabaseConfig", "PgVector"]