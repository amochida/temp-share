"""チャット機能に関する FastAPI ルーターを公開するパッケージ。

`backend.api.chat.router` が提供する `APIRouter` を外部へエクスポートし、
`router_registry` から簡潔に取り込めるようにしている。パッケージに
追加の初期化処理は存在せず、意図を明確化するための説明のみを用意する。
"""

from .router import router

# `from backend.api.chat import router` と書けるように公開シンボルを明示する。
__all__ = ["router"]
