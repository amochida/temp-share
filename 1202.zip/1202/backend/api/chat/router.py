"""チャット機能のHTTPエンドポイント群。

UI（Next.js）から送信されるチャット要求を受け取り、サービス層の処理に橋渡しするモジュール。
`docs/reference/api_spec.md` の *chat_api* セクションに定義されたエンドポイント仕様を
忠実に実装しており、以下の3系統の処理を提供する。

* `/ask`    : ハイブリッド検索＋LLM応答を行う stateless な問い合わせ
* `/save`   : 生成したメッセージ履歴を永続化するためのエンドポイント
* `/history`: 指定スレッドのメッセージ履歴を取得する読み取り専用API

リクエスト送信者の情報は `UserContextDependency` により Apache/SSO 経由で付与された
ヘッダから自動的に読み取られる。ここでは特権チェックなどの認可ロジックは
サービス層へ委譲し、ルーティング層の責務を「バリデーションとエラーハンドリング」に限定している。
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status

from backend.foundation.authentication import UserContextDependency
from backend.api.chat.schema import (
    ChatAnswer,
    ChatHistoryResponse,
    ChatMessage,
    ChatQueryRequest,
    ChatSaveRequest,
    ChatSaveResponse,
)
from backend.service.chat_service import ask_question, fetch_history, save_messages

# `APIRouter` を生成。prefix には共通パス `/api/chat` を設定し、
# OpenAPI ドキュメント上での分類名として `tags` を指定する。
router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("/ask", response_model=ChatAnswer)
async def ask_chat(
    payload: ChatQueryRequest,
    user: UserContextDependency,
) -> ChatAnswer:
    """ユーザーからの質問を受け取り、RAG検索＋LLM応答を返す。

    Parameters
    ----------
    payload : ChatQueryRequest
        クライアントから送られた質問内容やスレッドID。Validation は Pydantic が実施する。
    user : UserContextDependency
        Apache経由で挿入されたユーザー情報。サービス層での権限チェックに使用する。
    Returns
    -------
    ChatAnswer
        LLMが生成した回答と引用情報、スレッドIDなどを含むレスポンス。
    """

    try:
        # サービス層に実装された RAG 処理を呼び出し、回答生成を任せる。
        return await ask_question(payload, user=user)
    except PermissionError as exc:
        _raise_thread_not_found(exc)


@router.post("/save", response_model=ChatSaveResponse, status_code=status.HTTP_200_OK)
async def save_chat_transcript(
    payload: ChatSaveRequest,
    user: UserContextDependency,
) -> ChatSaveResponse:
    """チャットメッセージをデータベースに保存する。

    * ユーザーが画面上で Good/Bad 出し分けやスレッド保存を行ったタイミングで呼ばれる。
    * スレッドの所有者でない場合は `PermissionError` が送出され、404 としてマスクする。
    """

    try:
        # メッセージ永続化ロジックをサービス層へ委譲し、結果をそのまま返す。
        return await save_messages(payload, user=user)
    except PermissionError as exc:
        _raise_thread_not_found(exc)


@router.get("/history/{thread_id}", response_model=ChatHistoryResponse)
async def get_history(
    thread_id: UUID,
    user: UserContextDependency,
    limit: int = Query(50, ge=1, le=200),
) -> ChatHistoryResponse:
    """指定されたスレッドの発言履歴を取得する。

    `limit` を設けることで、画面ロード時のレスポンスサイズを制御する。
    戻り値は画面表示に合わせた整形済みの `ChatMessage` リスト。
    """

    rows = await fetch_history(thread_id, user=user, limit=limit)
    messages = [ChatMessage(**row) for row in rows]
    return ChatHistoryResponse(items=messages)


def _raise_thread_not_found(exc: PermissionError) -> None:
    """スレッドにアクセスできない場合に共通の 404 応答を返す。"""

    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="thread not found") from exc
