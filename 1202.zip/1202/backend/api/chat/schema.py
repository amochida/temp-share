"""チャット API の入出力を定義する Pydantic スキーマ群。

フロントエンドから送信されるリクエスト、FastAPI から返却するレスポンスを
型安全に扱うことを目的としたモジュール。設計書が無くても用途を把握できるよう、
各モデルに詳細なドキュメントとフィールド説明を付与している。
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional, Union
from uuid import UUID

from pydantic import Field

from backend.api.schema_base import APIModel


class ChatCitation(APIModel):
    """LLM 応答に添付される引用情報（エビデンス）を表現するモデル。

    LLM が回答を作成した際に参照したドキュメント／FAQ の断片を UI に伝える。
    これにより、ユーザーは根拠となる資料へ簡単に遷移できる。
    """

    document_id: Optional[UUID] = Field(None, description="引用元ドキュメントのID")
    chunk_id: Optional[UUID] = Field(None, description="引用元ドキュメントチャンクのID")
    faq_id: Optional[UUID] = Field(None, description="引用元FAQのID")
    title: Optional[str] = Field(None, description="引用元のタイトル（ドキュメント名や質問文）")
    score: Optional[float] = Field(None, description="検索スコア（関連度指標）")
    snippet: Optional[str] = Field(None, description="本文から抜粋したハイライトテキスト")
    source: Optional[str] = Field(None, description="検索タイプ（text/semantic/hybrid など）")
    source_uri: Optional[str] = Field(None, description="引用元の参照URI（ドキュメントの場合のみ設定）")


class ChatQueryFilters(APIModel):
    """チャット質問時に渡される検索フィルタ条件。"""

    document_category: Optional[Union[str, list[str]]] = Field(
        None,
        description="制度・ルール向けのドキュメントカテゴリ条件",
    )
    faq_category: Optional[Union[str, list[str]]] = Field(
        None,
        description="手続き・運用向けのFAQカテゴリ条件",
    )
    department: Optional[Union[str, list[str]]] = Field(
        None,
        description="対象とする部門コード",
    )
    priority: Optional[str] = Field(
        None,
        description="検索優先度ヒント（例: 'faq-first', 'document-first' など）",
    )
    answer_mode: Optional[Literal["documents", "all"]] = Field(
        None,
        description="回答モード（'documents' は規則・マニュアルのみ、'all' はFAQも含める）",
    )


class ChatHistoryTurn(APIModel):
    """チャット履歴1件分（ユーザーorAIの発話）。"""

    role: Literal["user", "assistant"] = Field(..., description="発話者の種別")
    content: str = Field(..., description="実際のメッセージ本文")


class ChatQueryRequest(APIModel):
    """チャット質問エンドポイント `/api/chat/ask` の入力モデル。"""

    thread_id: Optional[UUID] = Field(None, description="所属スレッドID。新規作成時は省略可")
    query: str = Field(..., min_length=1, description="ユーザーが入力した質問文")
    history: list[ChatHistoryTurn] = Field(
        default_factory=list,
        description="直近の会話履歴（LLMへコンテキストとして渡す）",
    )
    filters: Optional[ChatQueryFilters] = Field(None, description="検索対象を絞り込むための任意フィルタ")


class ChatMessage(APIModel):
    """スレッド履歴を返却する際の1件分のレコード。"""

    id: UUID = Field(..., description="メッセージID（messages.id）")
    thread_id: UUID = Field(..., description="紐付くスレッドID")
    role: Literal["user", "assistant"] = Field(..., description="発話者の種別")
    content: str = Field(..., description="メッセージ本文")
    created_at: datetime = Field(..., description="メッセージ作成日時")
    query_id: Optional[UUID] = Field(None, description="チャット応答の識別子（LLM問い合わせ単位）")
    citations: Optional[list[ChatCitation]] = Field(None, description="回答に添付された引用情報")


class ChatHistoryResponse(APIModel):
    """履歴取得APIのレスポンス。"""

    items: list[ChatMessage] = Field(..., description="取得した履歴の配列。古い順に整列済み")


class ChatAnswer(APIModel):
    """チャット質問に対する応答。"""

    query_id: UUID = Field(..., description="問い合わせ単位の識別子（messages.query_id と連携）")
    thread_id: Optional[UUID] = Field(None, description="応答したスレッドID")
    sources_used: list[str] = Field(default_factory=list, description="検索に利用したデータソース一覧")
    weights: Optional[dict[str, float]] = Field(None, description="documents/faqs への重みづけ")
    answer: str = Field(..., description="LLM が生成した回答本文")
    citations: list[ChatCitation] = Field(..., description="回答根拠として提示する引用情報")
    prompt_type: str = Field(..., description="採用したプロンプト種別（例: qa, summary, comparison, qa:no_evidence, error）")
    latency_ms: Optional[int] = Field(None, description="LLM 応答に要した時間（ミリ秒）")


class ChatSaveMessage(APIModel):
    """`/api/chat/save` が受け取るメッセージ配列の1件。"""

    id: UUID = Field(..., description="保存対象メッセージのID")
    role: Literal["user", "assistant"] = Field(..., description="発話者")
    content: str = Field(..., description="本文")
    created_at: datetime = Field(..., description="作成日時（ISO8601文字列で受信）")
    citations: list[ChatCitation] = Field(
        default_factory=list,
        description="回答に添付された引用情報。assistant メッセージのみ指定される",
    )


class ChatSaveRequest(APIModel):
    """チャット履歴保存リクエスト。"""

    thread_id: UUID = Field(..., description="保存対象スレッドID")
    messages: list[ChatSaveMessage] = Field(..., description="保存したいメッセージの配列")


class ChatSaveResponse(APIModel):
    """履歴保存完了時に返却する固定レスポンス。"""

    status: Literal["ok"] = Field(..., description="固定値 'ok'。失敗時は例外が送出される")
    saved_count: int = Field(ge=0, description="保存されたメッセージ件数")


# スキーマを外部に公開する際のエクスポート一覧。必要な型だけを明示的に露出する。
__all__ = [
    "ChatCitation",
    "ChatQueryFilters",
    "ChatHistoryTurn",
    "ChatQueryRequest",
    "ChatMessage",
    "ChatHistoryResponse",
    "ChatAnswer",
    "ChatSaveMessage",
    "ChatSaveRequest",
    "ChatSaveResponse",
]
