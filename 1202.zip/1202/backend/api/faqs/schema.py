"""FAQs API 用の入出力スキーマ。"""

from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional
from uuid import UUID

from pydantic import Field

from backend.api.schema_base import APIModel

# FAQ のライフサイクルを表すステータス定数群。
# draft    : 下書き保存で、まだ公開されていない状態。
# ready    : 公開済みで検索にも表示される通常状態。
# archived : 過去FAQとして保管するアーカイブ状態。
FAQStatus = Literal["draft", "ready", "archived"]

# FAQ が閲覧できる利用者範囲を示す定数群。
# internal   : 社内メンバー全体が閲覧可能。
# restricted : 特定部門・ロールなど限定公開。
# public     : 部外者を含めた全員が参照できる状態。
PublicScope = Literal["internal", "restricted", "public"]
FAQScope = PublicScope


class FAQPayload(APIModel):
    """FAQ登録・更新時の入力ペイロード。

    スタッフUIで入力されたフォーム値を包み込み、サービス層へと受け渡す際の
    データ構造を担う。バリデーションは Pydantic が実施し、欠落値や型違いを
    早期に検出できるようにしている。
    """

    question: str = Field(..., description="質問文")
    answer: str = Field(..., description="回答文")
    department_code: Optional[str] = Field(
        None,
        description="紐付け部門コード。空/未指定は全部門として扱われる",
    )
    category: Optional[str] = Field(None, description="カテゴリーラベル")
    faq_type: Optional[str] = Field(None, description="FAQ種別")
    summary: Optional[str] = Field(None, description="回答の要約")
    public_scope: PublicScope = Field("internal", description="公開範囲")
    status: FAQStatus = Field("draft", description="ステータス")


class FAQResponse(APIModel):
    """FAQ1件分のレスポンスモデル。

    一覧表示と詳細画面の双方で使い回しやすいよう、FAQ 本体に加えて
    スコアや抜粋テキストといった検索メタ情報も保持する。
    """

    id: UUID
    department_code: Optional[str]
    category: Optional[str]
    faq_type: Optional[str] = Field(None, alias="type")
    question: str
    answer: str
    summary: Optional[str]
    tokens_count: Optional[int]
    public_scope: PublicScope
    status: FAQStatus
    created_by: Optional[str]
    updated_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    snippet: Optional[str] = Field(None, description="検索で利用する抜粋テキスト")
    score: Optional[float] = Field(None, description="検索スコア")


class FAQListQuery(APIModel):
    """FAQ一覧取得時の検索条件モデル。

    ルーター層でクエリパラメータから生成され、サービス層の検索関数に
    そのまま渡される。複数指定の扱いや未指定時のデフォルト挙動を
    初心者でも理解しやすいようフィールド説明を付けている。
    """

    department_codes: Optional[list[str]] = Field(None, description="部門コードの絞り込み")
    categories: Optional[list[str]] = Field(None, description="カテゴリの絞り込み")
    faq_types: Optional[list[str]] = Field(None, description="FAQ種別の絞り込み")
    public_scopes: Optional[list[PublicScope]] = Field(None, description="公開範囲の絞り込み")
    statuses: Optional[list[FAQStatus]] = Field(None, description="ステータス複数指定")
    status: Optional[FAQStatus] = Field(
        None,
        description="単一ステータスの絞り込み（互換目的。指定時は statuses より優先）",
    )
    q: Optional[str] = Field(None, description="全文検索キーワード")
    semantic_query: Optional[str] = Field(None, description="意味検索用クエリ")
    limit: int = Field(20, ge=1, le=100)
    offset: int = Field(0, ge=0)


class FAQListResponse(APIModel):
    """FAQ一覧レスポンス。

    total 件数と個々の FAQ 詳細 (`FAQResponse`) を束ね、ページング結果を
    そのままクライアントへ返却するための薄いコンテナモデル。
    """

    total: int
    items: list[FAQResponse]


class FAQUploadResponse(APIModel):
    """FAQ登録直後に返すレスポンスモデル。

    新規作成された FAQ のIDと確定したステータスを返却し、フロント側で
    リダイレクトやトースト表示に利用できるようにする。
    """

    faq_id: UUID
    status: FAQStatus


# 外部モジュールから import するときに利用可能なシンボルを一覧化しておく。
__all__ = [
    "FAQStatus",
    "FAQScope",
    "PublicScope",
    "FAQPayload",
    "FAQResponse",
    "FAQListQuery",
    "FAQListResponse",
    "FAQUploadResponse",
]
