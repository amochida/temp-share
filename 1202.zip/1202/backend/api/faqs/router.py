"""FAQ管理のエンドポイント群。

スタッフUIから送信されるFAQの登録・更新・削除・検索要求を受け付ける。
各処理の実体はアプリケーション層（`backend.service.faqs_service`）に置き、ルーティング層では
リクエストの検証とレスポンス用スキーマへの変換に専念する。
"""

from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Form, HTTPException, Query, status

from backend.foundation.authentication import UserContextDependency
from backend.api.faqs.schema import (
    FAQListQuery,
    FAQListResponse,
    FAQPayload,
    FAQResponse,
    FAQScope,
    FAQStatus,
    FAQUploadResponse,
)
from backend.infrastructure.embedding_client import EmbeddingError
from backend.service.faqs_service import create_faq, delete_faq, fetch_faq, list_faqs, update_faq

# FAQ 関連エンドポイントをまとめるルーター。タグ名は OpenAPI 上の表示に利用する。
router = APIRouter(prefix="/api/faqs", tags=["faqs"])


@router.get("", response_model=FAQListResponse)
async def list_faqs_endpoint(
    user: UserContextDependency,
    department_codes: Optional[list[str]] = Query(None),
    categories: Optional[list[str]] = Query(None),
    faq_types: Optional[list[str]] = Query(None),
    public_scopes: Optional[list[FAQScope]] = Query(None),
    statuses: Optional[list[FAQStatus]] = Query(None),
    status_value: Optional[FAQStatus] = Query(None, alias="status"),
    q: Optional[str] = Query(None),
    semantic_query: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
) -> FAQListResponse:
    """スタッフ UI 向け FAQ 一覧。フィルタ・意味検索を統合して返す。"""

    query = FAQListQuery(
        department_codes=department_codes or None,
        categories=categories or None,
        faq_types=faq_types or None,
        public_scopes=public_scopes or None,
        statuses=statuses or None,
        status=status_value,
        q=q,
        semantic_query=semantic_query,
        limit=limit,
        offset=offset,
    )
    result = await list_faqs(query)
    items = [FAQResponse(**row) for row in result["items"]]
    return FAQListResponse(total=result["total"], items=items)


@router.post("/upload", response_model=FAQUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_faq(
    user: UserContextDependency,
    question: str = Form(...),
    answer: str = Form(...),
    department_code: Optional[str] = Form(None),
    category: Optional[str] = Form(None),
    faq_type: Optional[str] = Form(None),
    summary: Optional[str] = Form(None),
    public_scope: str = Form("internal"),
    status_value: str = Form("draft", alias="status"),
) -> FAQUploadResponse:
    """FAQを新規登録する。

    スタッフUIで入力された質問・回答を受け取り、サービス層でベクトル化・トークン数計算を
    実施したうえで `faqs` テーブルへ登録する。戻り値は作成された FAQ のIDとステータス。
    """
    # 受け取ったフォーム入力を Pydantic モデルへ詰め替えて型安全に扱う。
    payload = FAQPayload(
        question=question,
        answer=answer,
        department_code=department_code,
        category=category,
        faq_type=faq_type,
        summary=summary,
        public_scope=public_scope,
        status=status_value,
    )

    try:
        # ユースケース層へ委譲。ここで埋め込み生成や DB 登録が行われる。
        result = await create_faq(payload, user=user)
    except EmbeddingError as exc:
        _raise_embedding_unavailable(exc)
    # 生成された FAQ 情報をレスポンススキーマへ写像して返却する。
    return FAQUploadResponse(**result)


@router.put("/{faq_id}", response_model=FAQResponse)
async def update_faq_entry(
    faq_id: UUID,
    payload: FAQPayload,
    user: UserContextDependency,
) -> FAQResponse:
    """既存FAQを更新する。対象が存在しなければ 404 を返す。"""
    try:
        # 既存 FAQ の上書き。ベクトル生成も再実施されるため同様に例外を捕捉する。
        updated = await update_faq(faq_id, payload, user=user)
    except EmbeddingError as exc:
        _raise_embedding_unavailable(exc)
    if not updated:
        _raise_faq_not_found()
    if "department_code" not in updated:
        refreshed = await fetch_faq(faq_id)
        if not refreshed:
            _raise_faq_not_found()
        updated = refreshed
    # 再取得したレコードを API レスポンス用モデルに整形する。
    return FAQResponse(**updated)


@router.delete("/{faq_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_faq(
    faq_id: UUID,
    user: UserContextDependency,
) -> None:
    """FAQを削除する。

    本システムでは FAQ を再公開する要件がないため物理削除を行う。削除結果は204で通知。
    """
    await delete_faq(faq_id, user=user)  # FAQ を物理削除。例外はそのまま伝播。


@router.get("/{faq_id}", response_model=FAQResponse)
async def get_faq(faq_id: UUID) -> FAQResponse:
    """FAQをIDで取得する。存在しない場合は404。"""
    row = await fetch_faq(faq_id)  # DB から該当 FAQ を取得。
    if not row:
        _raise_faq_not_found()
    # 生データをレスポンスモデルへ変換してクライアントへ返す。
    return FAQResponse(**row)

def _raise_faq_not_found() -> None:
    """FAQ が見つからない場合の共通 404 応答。"""

    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="faq not found")


def _raise_embedding_unavailable(exc: EmbeddingError) -> None:
    """埋め込み生成失敗時の 503 応答を共通化。"""

    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail="埋め込み生成に失敗しました。時間をおいて再試行してください。",
    ) from exc
