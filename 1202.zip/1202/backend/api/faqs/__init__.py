"""FAQs API パッケージの公開窓口。

FAQ 管理系のエンドポイントを束ねたルーターを外部に提供する役割を担う。
サービス層やスキーマ定義など、機能を支える詳細な実装は内部モジュールに
閉じ込め、本ファイルでは最小限の公開インターフェースのみを明示する。
"""

from .router import router

# `from backend.api.faqs import router` の形でシンプルに利用できるよう公開シンボルを限定する。
__all__ = ["router"]
