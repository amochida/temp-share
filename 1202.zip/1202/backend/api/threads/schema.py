"""Threads API 用スキーマ。"""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import Field

from backend.api.schema_base import APIModel


class ThreadCreateRequest(APIModel):
    """スレッド新規作成時に利用するリクエストモデル。

    フロントエンドから送られるフォーム値を受け取り、タイトルが未指定の場合は
    サービス層側で自動生成される想定。入力値の検証とドキュメント化を兼ねる。
    """

    title: Optional[str] = Field(None, description="任意のスレッドタイトル")


class ThreadResponse(APIModel):
    """スレッド1件分の情報。

    API レスポンスでクライアントに返す基本構造で、論理削除フラグや更新日時など
    UI 表示に必要な最小限のフィールドを保持する。
    """

    id: UUID = Field(..., description="スレッドID")
    title: Optional[str] = Field(None, description="スレッドタイトル")
    is_deleted: bool = Field(..., description="論理削除フラグ")
    created_at: datetime = Field(..., description="作成日時")
    updated_at: datetime = Field(..., description="最終更新日時")


class ThreadListResponse(APIModel):
    """スレッド一覧レスポンスを包むコンテナモデル。

    複数件の `ThreadResponse` をまとめ、将来的にページング情報を追加する余地を
    残しつつ現在はシンプルな配列のみを保持する。
    """

    items: list[ThreadResponse] = Field(..., description="スレッド情報のリスト")


class ThreadDeleteResponse(APIModel):
    """スレッド削除処理の結果を表すレスポンスモデル。

    実際に削除できたかどうか（論理削除フラグ）と対象IDをセットで返却し、
    クライアント側で再描画やエラーハンドリングを行いやすくする。
    """

    id: UUID = Field(..., description="削除対象のスレッドID")
    deleted: bool = Field(..., description="削除結果")


# パッケージ外へ公開するスキーマクラスを明示し、予期せぬシンボル露出を防ぐ。
__all__ = [
    "ThreadCreateRequest",
    "ThreadResponse",
    "ThreadListResponse",
    "ThreadDeleteResponse",
]
