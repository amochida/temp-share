"""スレッド管理APIのルーティング定義。
このモジュールは「スレッド（thread）」の作成・取得・削除を行う API エンドポイントを定義しています。

ここで言う「スレッド」とは、ユーザーごとのやり取り（会話のまとまり）や、
ドキュメント・コメントなどをグルーピングする単位を指します。

このファイルは FastAPI の「ルーティング層」であり、
外部からの HTTP リクエストを受け取り、サービス層の処理に橋渡しをする役割を持ちます。
"""

# --- 未来の型ヒント機能（Python3.7互換） ---
from __future__ import annotations

# --- 標準ライブラリのインポート ---
from typing import Optional
from uuid import UUID  # スレッドID（ユニークな識別子）に使用

# --- FastAPI関連のインポート ---
from fastapi import APIRouter, Form, HTTPException, status

# --- 認証コンテキスト（ログイン中のユーザー情報を取得する仕組み） ---
from backend.foundation.authentication import UserContextDependency

# --- データ構造（スキーマ） ---
from backend.api.threads.schema import ThreadDeleteResponse, ThreadListResponse, ThreadResponse

# --- ビジネスロジック層（DB操作など実処理） ---
from backend.service.threads_service import create_thread, delete_thread, list_threads


# ==========================================================
# FastAPIのルーターを定義
# ==========================================================
# prefix="/api/threads" → URLの共通部分
# つまり、全てのエンドポイントは /api/threads/... の形で呼ばれます。
# tags=["threads"] はドキュメント（Swagger UIなど）でのグルーピング名。
router = APIRouter(prefix="/api/threads", tags=["threads"])


# ==========================================================
# 1. スレッド作成（POST /api/threads）
# ==========================================================
@router.post(
    "",  # URLパス（空文字なので /api/threads に対応）
    response_model=ThreadResponse,              # レスポンス形式
    status_code=status.HTTP_201_CREATED,        # 成功時のHTTPステータスコード：201 = Created
)
async def create_thread_endpoint(
    user: UserContextDependency,               # 認証されたユーザー情報。自動的に依存注入される。
    title: Optional[str] = Form(None),         # タイトルは任意（フロントエンドで自動生成される場合がある）
) -> ThreadResponse:
    """
    新しいスレッドを作成するエンドポイント。
    ユーザーごとにスレッドが作成され、DBに登録されます。

    - 入力: JSON形式でタイトル（任意）
    - 出力: 作成されたスレッド情報（id, title, 作成日時など）
    """
    # サービス層に処理を委譲してDB登録を行う
    row = await create_thread(title, user=user)

    # DBから返ってきた行データ（dict）をThreadResponseモデルに変換して返す
    return ThreadResponse(**row)


# ==========================================================
# 2. スレッド削除（DELETE /api/threads/{thread_id}）
# ==========================================================
@router.delete(
    "/{thread_id}",                   # URLパスパラメータにスレッドIDを指定
    response_model=ThreadDeleteResponse,  # レスポンスモデル
)
async def delete_thread_endpoint(
    thread_id: UUID,                  # 削除対象のスレッドID
    user: UserContextDependency,      # 操作するユーザー情報（認証必須）
) -> ThreadDeleteResponse:
    """
    指定したスレッドを削除（論理削除）するエンドポイント。
    「論理削除」とは、実際のデータを消さずに is_deleted=True に変更する方式です。

    - 入力: スレッドID（UUID形式）
    - 出力: 削除結果（idと削除フラグ）
    """
    # サービス層で削除処理を実行（DBのis_deletedをTrueにする）
    row = await delete_thread(thread_id, user=user)

    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="thread not found")

    return ThreadDeleteResponse(id=row["id"], deleted=row["is_deleted"])


# ==========================================================
# 3. スレッド一覧取得（GET /api/threads）
# ==========================================================
@router.get(
    "",                             # /api/threads に対応
    response_model=ThreadListResponse,  # 複数件のスレッド一覧
)
async def list_threads_endpoint(
    user: UserContextDependency,    # 認証されたユーザー情報（このユーザーのスレッドのみ取得）
) -> ThreadListResponse:
    """
    現在ログインしているユーザーが持つスレッド一覧を取得するエンドポイント。

    - 削除されていないスレッドのみ返す
    - 新しい順（更新日時の降順）で並べる
    - 出力: 各スレッドのid、タイトル、作成日時、更新日時など
    """
    # サービス層に処理を委譲してDBからスレッド一覧を取得
    rows = await list_threads(user=user)

    # 取得した各行をThreadResponseモデルに変換
    items = [ThreadResponse(**row) for row in rows]

    # ThreadListResponse（リスト形式のレスポンスモデル）にまとめて返す
    return ThreadListResponse(items=items)
