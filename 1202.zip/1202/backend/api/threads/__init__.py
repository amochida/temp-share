"""Threads API パッケージの役割。

チャット履歴をグルーピングする「スレッド」機能のエンドポイント群を公開する。
ここでは FastAPI の `APIRouter` を外部へ渡すだけにとどめ、内部モジュールの詳細を
カプセル化することで、呼び出し側の import がシンプルになるよう配慮している。
"""

from .router import router

# ワイルドカード import 時に公開されるシンボルを明示的に制御する。
__all__ = ["router"]
