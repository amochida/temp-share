"""FastAPIへルーターを登録する集中管理モジュール。

本ファイルは UI 層（Next.js）から到達する HTTP エンドポイントを FastAPI アプリへ
組み込む役割を担う。初心者がコードを追いやすいように、登録順序・責務・依存関係を
このモジュールに明記し、エントリーポイントからは `register_routes(app)` を呼ぶだけで
全ルーターが揃う構造にしている。

* 想定入出力
  * 入力: `FastAPI` インスタンス
  * 出力: なし（アプリへルーターを副作用的に登録）
* 依存関係
  * `backend.api.routers.*` 各モジュールが `APIRouter` を公開していること
"""

from __future__ import annotations

from fastapi import FastAPI

from backend.api.chat import router as chat_router
from backend.api.documents import router as documents_router
from backend.api.faqs import router as faqs_router
from backend.api.feedback import router as feedback_router
from backend.api.search import router as search_router
from backend.api.threads import router as threads_router

# 画面での利用頻度順に並べることで、将来ルーターが増えても意図を把握しやすい。
# ルーター登録順をタプルで保持する。
# - ドキュメント/FAQ スタッフ向け画面で最も利用頻度が高いものを先頭に配置
# - スタッフ向け -> 利用者向け (検索/チャット) -> 補助API (スレッド/フィードバック) の順で読みやすくする
ROUTER_REGISTRATION_ORDER = (
    documents_router,  # スタッフが最初に利用するドキュメント管理 API
    faqs_router,       # FAQ 管理 API
    search_router,     # 一般ユーザー・スタッフ双方が利用する検索 API
    chat_router,       # RAG チャット API
    threads_router,    # チャット履歴（スレッド）を扱う API
    feedback_router,   # 回答に対するフィードバックを登録する API
)


def register_routes(app: FastAPI) -> None:
    """FastAPI アプリに既定のルーター群を登録する。

    Parameters
    ----------
    app : FastAPI
        ルーターを組み込みたい FastAPI インスタンス。

    Notes
    -----
    `backend/app.py` から呼び出されることを想定しており、ここでルーターを一括登録することで
    エントリーポイント側の記述を最小限に抑えている。
    今後ルーターが追加された場合は `ROUTER_REGISTRATION_ORDER` へ要素を追加するだけで済む。
    """

    for router in ROUTER_REGISTRATION_ORDER:
        # FastAPI へルーターを組み込む。include_router は副作用のみで戻り値はない。
        app.include_router(router)
