"""Pydanticモデルの共通基底クラス。

FastAPIの入出力に用いるスキーマはすべてこのクラスを継承する。
日本語コメントを添えることで、初学者でも設定内容を追いやすくしている。
"""

from __future__ import annotations

from pydantic import BaseModel
from pydantic import ConfigDict


class APIModel(BaseModel):
    """プロジェクト全体で共通利用する BaseModel 派生クラス。"""

    model_config = ConfigDict(
        from_attributes=True,
        str_strip_whitespace=True,
        validate_by_name=True,
        use_enum_values=True,
    )
