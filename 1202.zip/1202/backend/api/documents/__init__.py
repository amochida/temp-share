"""Documents API パッケージの公開インターフェース。

フロントエンドや他モジュールが `backend.api.documents` を import した際に
最初に読み込まれるエントリーポイント。ここでは FastAPI のルーター
オブジェクトのみを公開し、内部構造（schema や補助関数）は隠蔽する。
これにより、呼び出し側は `from backend.api.documents import router` と書くだけで
HTTP エンドポイント集合を取得でき、詳細実装を意識する必要がなくなる。
"""

from .router import router

# ワイルドカード import 時に露出させるシンボルを制限して意図しない公開を防ぐ。
__all__ = ["router"]
