"""
==============================================
 Documents API 用 入出力スキーマ定義
==============================================

このモジュールは、RAGシステムにおける
「検索対象ドキュメントの登録・更新・参照API」
で使用されるデータ構造（スキーマ）を定義します。

FastAPI + pydantic の思想に基づき、
・APIの入力（リクエスト）
・APIの出力（レスポンス）
の双方を明確に型で表現しています。

これにより次のメリットがあります：
-------------------------------------
1. **ドキュメントの自動生成**
   → FastAPIがこの定義を元にSwagger UIなどのAPI仕様書を自動生成します。

2. **入力データの自動検証**
   → 不正な型・不足フィールド・範囲外値を受け付けない安全な設計。

3. **チーム間での共通認識**
   → 「APIがどんなデータをやり取りするか」をスキーマを見れば即わかる。

設計方針：
----------
- `DocumentResponse` や `DocumentChunk` は DBの構造に近い形を保ちつつ、
  外部APIで返しても安全なフィールドだけを公開します。
- `DocumentListQuery` のように「検索条件」を受け取るモデルも同一モジュールで管理し、
  リクエスト／レスポンス両方の整合性を確保します。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Optional
from uuid import UUID
from pydantic import Field

from backend.api.schema_base import APIModel


# ------------------------------------------------------------
# 定数（Enum相当）: ステータスや区分値をLiteralで制限
# ------------------------------------------------------------

DocumentStatus = Literal["processing", "ready", "error", "archived"]
"""
ドキュメントの処理状態を表すステータス。
- processing  : 登録・解析中（まだ検索対象に反映されていない）
- ready       : 検索対象として利用可能
- error       : 登録や分割処理でエラーが発生
- archived    : 利用終了・アーカイブ済み（将来用）
"""

RegistrationType = Literal["manual", "auto"]
"""
登録区分。
- manual : ユーザーが手動で登録したドキュメント
- auto   : 自動取り込み（ファイル監視やスケジューラ連携など）による登録
"""

PublicScope = Literal["internal", "restricted", "public"]
"""
公開範囲の制約。
- internal   : 社内限定
- restricted : 特定部門・ロールのみアクセス可能
- public     : 全体公開（検索対象も拡張）
"""

# ------------------------------------------------------------
# メタ情報
# ------------------------------------------------------------

class DocumentMetadata(APIModel):
    """
    ドキュメント登録時に送られてくる **メタ情報** を表現するモデル。

    メタ情報とは、本文コンテンツ以外の付加属性のことです。
    たとえば「どの部署の文書か」「どの種類の資料か」といった分類情報。

    Attributes
    ----------
    title : str
        ドキュメントのタイトル。
    department_code : Optional[str]
        紐づけ部門コード（例: HR, IT, SALES など）。
        バックエンドではマスタ照合を行わず、受け取った文字列をそのまま保存する。
        空文字または `null` の場合は「全部門」で利用できるドキュメントとして扱う。
    document_type : Optional[str]
        ドキュメントの種類（例: 規程, マニュアル, Q&A）。
    registration_type : RegistrationType
        登録区分。手動(manual)か自動(auto)か。
    is_auto_import_target : bool
        「自動取り込み対象」かどうかを示すフラグ。
        Trueならファイル監視などの対象になる。
    source_uri : Optional[str]
        原本ファイルのSharePintのURI。
    public_scope : PublicScope
        公開範囲を制御。internal / restricted / public のいずれか。
    """

    title: str = Field(..., description="ドキュメントタイトル")
    department_code: Optional[str] = Field(
        None,
        description="紐付け部門コード。空/未指定は全部門扱いで保存される",
    )
    document_type: Optional[str] = Field(None, description="ドキュメント種別")
    registration_type: RegistrationType = Field(
        "manual", description="登録区分（manual/auto）"
    )
    is_auto_import_target: bool = Field(False, description="自動インポート対象か")
    source_uri: Optional[str] = Field(None, description="原本の場所を示すURI")
    public_scope: PublicScope = Field(
        "internal", description="公開範囲（internal/restricted/public）"
    )


# ------------------------------------------------------------
# アップロード結果レスポンス
# ------------------------------------------------------------

class DocumentUploadResponse(APIModel):
    """
    アップロード完了時に返すレスポンスモデル。

    RAGシステムの前処理（例: 解析・分割・ベクトル化）が
    非同期的に行われるため、アップロード時点では
    「status=processing」で返されるのが一般的。

    Attributes
    ----------
    document_id : UUID
        登録されたドキュメントのUUID。
    status : DocumentStatus
        現在の処理ステータス。
    """

    document_id: UUID
    status: DocumentStatus


# ------------------------------------------------------------
# メタ情報更新用リクエスト
# ------------------------------------------------------------

class DocumentUpdateRequest(DocumentMetadata):
    """
    既存ドキュメントのメタ情報を更新するためのリクエスト。

    基本的には DocumentMetadata と同じ構造だが、
    ステータス上書き用のフィールドを追加している。

    Attributes
    ----------
    status : Optional[DocumentStatus]
        ステータスを任意に変更したい場合に指定する。
        例: processing → ready など。
    """

    status: Optional[DocumentStatus] = Field(
        None, description="ステータスを任意に上書きする場合に指定"
    )


# ------------------------------------------------------------
# 単一ドキュメントの詳細レスポンス
# ------------------------------------------------------------

class DocumentResponse(APIModel):
    """
    ドキュメント1件分の詳細情報を表現するレスポンスモデル。

    APIレスポンスや検索結果一覧の各要素として利用される。

    Attributes
    ----------
    id : UUID
        ドキュメントID。
    department_code : Optional[str]
        部門コード。
    title : str
        ドキュメントタイトル。
    document_type : Optional[str]
        ドキュメント種別。
    registration_type : RegistrationType
        登録区分。
    is_auto_import_target : bool
        自動インポート対象フラグ。
    source_uri : Optional[str]
        原本URI。
    public_scope : PublicScope
        公開範囲。
    status : DocumentStatus
        現在の処理状態。
    created_at : datetime
        登録日時。
    updated_at : datetime
        最終更新日時。
    snippet : Optional[str]
        検索結果の抜粋表示などに使うサマリテキスト。
    score : Optional[float]
        ベクトル検索（意味検索）時のスコア値。
    """

    id: UUID
    department_code: Optional[str]
    title: str
    document_type: Optional[str] = Field(None, alias="type")
    registration_type: RegistrationType
    is_auto_import_target: bool
    source_uri: Optional[str]
    public_scope: PublicScope
    status: DocumentStatus
    created_at: datetime
    updated_at: datetime
    snippet: Optional[str] = Field(None, description="検索結果などで利用する抜粋テキスト")
    score: Optional[float] = Field(None, description="検索スコア（意味検索時）")


# ------------------------------------------------------------
# 一覧取得用クエリ（検索条件）
# ------------------------------------------------------------

class DocumentListQuery(APIModel):
    """
    ドキュメント一覧取得時の検索条件モデル。

    クエリパラメータやリクエストボディで受け取るフィルタ条件を表す。
    SQLのWHERE句や全文検索、意味検索（ベクトル検索）の入力に使われる。

    Attributes
    ----------
    department_codes : Optional[list[str]]
        部門コードで絞り込み。
    document_types : Optional[list[str]]
        ドキュメント種別で絞り込み。
    status : Optional[DocumentStatus]
        ステータスで絞り込み。
    q : Optional[str]
        通常の全文検索用キーワード。
    semantic_query : Optional[str]
        意味検索（ベクトル検索）用クエリ。
    limit : int
        最大取得件数（1〜100の範囲で指定）。
    offset : int
        取得開始位置（ページネーション用）。
    """

    department_codes: Optional[list[str]] = Field(
        None, description="部門コードで絞り込み"
    )
    document_types: Optional[list[str]] = Field(
        None, description="ドキュメント種別で絞り込み"
    )
    public_scopes: Optional[list[PublicScope]] = Field(
        None, description="公開範囲の絞り込み"
    )
    statuses: Optional[list[DocumentStatus]] = Field(
        None, description="ステータスの複数指定"
    )
    status: Optional[DocumentStatus] = Field(
        None,
        description="単一ステータスでの絞り込み（互換目的。指定時は statuses より優先）",
    )
    q: Optional[str] = Field(None, description="全文検索キーワード")
    semantic_query: Optional[str] = Field(None, description="意味検索用クエリ")
    limit: int = Field(20, ge=1, le=100)
    offset: int = Field(0, ge=0)


# ------------------------------------------------------------
# 一覧レスポンス
# ------------------------------------------------------------

class DocumentListResponse(APIModel):
    """
    ドキュメント一覧APIのレスポンス。

    total件数と items（DocumentResponse のリスト）を返す。

    Attributes
    ----------
    total : int
        全体件数（ページング総数）。
    items : list[DocumentResponse]
        ドキュメントの詳細リスト。
    """

    total: int
    items: list[DocumentResponse]


# ------------------------------------------------------------
# チャンク（文書分割単位）情報
# ------------------------------------------------------------

class DocumentChunk(APIModel):
    """
    ドキュメントをRAG用に「チャンク（小単位）」へ分割した際の1件分情報。

    チャンクとは、ベクトル埋め込みや検索インデックス化の際に、
    大きなドキュメントを一定サイズに切り出した最小単位。

    Attributes
    ----------
    id : UUID
        チャンクID。
    document_id : UUID
        紐付くドキュメントID。
    chunk_order : int
        元の文書内での出現順序。
    chunk_label : Optional[str]
        チャンクに付けられたラベル（章タイトルなど）。
    content : str
        チャンク本文。
    summary : Optional[str]
        チャンクの短い要約文。
    tokens_count : Optional[int]
        トークン数（埋め込みサイズ管理用）。
    page_start : int
        チャンクがカバーする開始ページ番号（1 始まり）。
    page_end : int
        チャンクがカバーする終了ページ番号（1 始まり）。
    metadata : dict[str, Any]
        章タイトルや element type、Excel 情報などの柔軟メタデータ。
    created_at : datetime
        作成日時。
    """

    id: UUID
    document_id: UUID
    chunk_order: int
    chunk_label: Optional[str]
    content: str
    summary: Optional[str]
    tokens_count: Optional[int]
    page_start: int = Field(1, description="チャンクの開始ページ番号")
    page_end: int = Field(1, description="チャンクの終了ページ番号")
    metadata: dict[str, Any] = Field(default_factory=dict, description="チャンク固有メタデータ")
    created_at: datetime


class DocumentChunkListResponse(APIModel):
    """
    チャンク一覧レスポンス。

    1つのドキュメントに紐づくすべてのチャンク情報を返す。
    """

    items: list[DocumentChunk]


# ------------------------------------------------------------
# 公開シンボル
# ------------------------------------------------------------

__all__ = [
    "DocumentStatus",
    "RegistrationType",
    "PublicScope",
    "DocumentMetadata",
    "DocumentUploadResponse",
    "DocumentUpdateRequest",
    "DocumentResponse",
    "DocumentListQuery",
    "DocumentListResponse",
    "DocumentChunk",
    "DocumentChunkListResponse",
]
