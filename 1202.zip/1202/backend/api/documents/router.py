"""
=============================================================
 Documents API: ルーティング定義モジュール
=============================================================

このモジュールは、FastAPIを使って「ドキュメント管理API」を定義しています。

RAGシステムの中核となる「検索対象ドキュメント」を
- アップロード（新規登録）
- 更新（メタ情報の変更）
- 削除
- 一覧・詳細取得
- チャンク情報取得（文書分割後の情報）

といった操作を行うための HTTP エンドポイント群をまとめています。

-----------------------------------------
設計の役割分担（層ごとの責務）
-----------------------------------------
- **Router層（このファイル）**
  → FastAPIのルーティング定義。「HTTPリクエストを受け取り」「サービス層へ渡し」「レスポンスを返す」
- **Service層（backend/service/documents_service.py）**
  → 実際の業務処理（DB保存、チャンク分割、埋め込みなど）を担当。
- **Schema層（backend/api/documents/schema.py）**
  → API入出力データの形式を定義し、型検証と自動ドキュメント生成を行う。

この三層構造により、責務が明確になり、
開発者は「どこを見れば何がわかるか」が直感的に理解できる設計になっています。

-----------------------------------------
命名規則とURI設計の方針
-----------------------------------------
- `/api/documents/...` : ドキュメント管理機能に関するすべてのAPI
- `/upload` : ファイルアップロード専用エンドポイント
- `/{document_id}` : 特定ドキュメントの操作
- `/chunks/{document_id}` : 文書分割結果の取得

-----------------------------------------
トランザクションや非同期処理について
-----------------------------------------
FastAPIの各エンドポイント関数は `async def` で定義されています。
これにより、I/O（DBアクセス、ファイル読み込み、ネットワーク処理）を
効率的に非同期化できます。内部では `await create_document(...)` のように
サービス層の非同期関数を呼び出しています。
"""

from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, File, Form, HTTPException, Query, UploadFile, status

# ------------------------------------------------------------
# 認証コンテキスト：ユーザー情報の自動注入
# ------------------------------------------------------------
from backend.foundation.authentication import UserContextDependency

# ------------------------------------------------------------
# API入出力スキーマ（pydanticモデル）
# ------------------------------------------------------------
from backend.api.documents.schema import (
    DocumentChunk,
    DocumentChunkListResponse,
    DocumentListQuery,
    DocumentListResponse,
    DocumentMetadata,
    DocumentResponse,
    DocumentStatus,
    DocumentUpdateRequest,
    DocumentUploadResponse,
    PublicScope,
)

# ------------------------------------------------------------
# サービス層：実際のDB操作・ビジネスロジック
# ------------------------------------------------------------
from backend.infrastructure.embedding_client import EmbeddingError
from backend.service.documents_service import (
    create_document,
    delete_document,
    fetch_document,
    fetch_document_chunks,
    list_documents,
    update_document,
)
from backend.rag.ingestion import DocumentParsingError

# ============================================================
# ルーター設定
# ============================================================
# ルーターインスタンスを生成。`tags` はドキュメント上の分類に利用する。
router = APIRouter(
    prefix="/api/documents",
    tags=["documents"],
)


# ============================================================
# 1. ドキュメント一覧取得
# ============================================================
@router.get("", response_model=DocumentListResponse)
async def list_documents_endpoint(
    user: UserContextDependency,
    department_codes: Optional[list[str]] = Query(None),
    document_types: Optional[list[str]] = Query(None),
    public_scopes: Optional[list[PublicScope]] = Query(None),
    statuses: Optional[list[DocumentStatus]] = Query(None),
    status_value: Optional[DocumentStatus] = Query(None, alias="status"),
    q: Optional[str] = Query(None),
    semantic_query: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
) -> DocumentListResponse:
    """スタッフ UI 向けのドキュメント一覧。フィルタや意味検索を組み合わせて取得する。"""

    query = DocumentListQuery(
        department_codes=department_codes or None,
        document_types=document_types or None,
        public_scopes=public_scopes or None,
        statuses=statuses or None,
        status=status_value,
        q=q,
        semantic_query=semantic_query,
        limit=limit,
        offset=offset,
    )
    result = await list_documents(query)
    items = [DocumentResponse(**row) for row in result["items"]]
    return DocumentListResponse(total=result["total"], items=items)


# ============================================================
# 2. ドキュメントアップロード（新規登録）
# ============================================================
@router.post(
    "/upload",
    response_model=DocumentUploadResponse,
    status_code=status.HTTP_201_CREATED,
)
async def upload_document(
    user: UserContextDependency,
    title: str = Form(...),
    department_code: Optional[str] = Form(None),
    document_type: Optional[str] = Form(None),
    registration_type: str = Form("manual"),
    is_auto_import_target: str = Form("false"),
    source_uri: Optional[str] = Form(None),
    public_scope: str = Form("internal"),
    file: UploadFile = File(...),
) -> DocumentUploadResponse:
    """
    ドキュメントを新規にアップロードして登録する。

    Parameters
    ----------
    user : UserContextDependency
        認証済みユーザー情報（FastAPIが自動で注入）。
    title : str
        アップロード対象のドキュメントタイトル。
    department_code : Optional[str]
        所属部門コード。
    document_type : Optional[str]
        種別（マニュアル・手順書など）。
    registration_type : str
        manual（手動）または auto（自動登録）。
    is_auto_import_target : str
        "true"/"false" などの文字列として送られるフラグ。
    source_uri : Optional[str]
        元ファイルのURI。
    public_scope : str
        公開範囲（internal/restricted/public）。
    file : UploadFile
        実際にアップロードされたファイル本体。
    Returns
    -------
    DocumentUploadResponse
        登録されたドキュメントのIDとステータス。
    """

    # フォームデータを Pydantic モデルに変換（バリデーション兼ねる）
    metadata = DocumentMetadata(
        title=title,
        department_code=department_code,
        document_type=document_type,
        registration_type=registration_type,
        is_auto_import_target=_to_bool(is_auto_import_target),
        source_uri=source_uri,
        public_scope=public_scope,
    )

    # サービス層に処理を委譲。内部でベクトル化やDB登録が行われる。
    try:
        result = await create_document(file, metadata, user=user)
    except EmbeddingError as exc:
        _raise_embedding_unavailable(exc)
    except DocumentParsingError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    # サービスから返った dict を Pydantic モデルへ変換して返す
    return DocumentUploadResponse(**result)


# ============================================================
# 2. ドキュメントメタ情報更新
# ============================================================
@router.put(
    "/{document_id}",
    response_model=DocumentResponse,
)
async def update_document_metadata(
    document_id: UUID,
    payload: DocumentUpdateRequest,
    user: UserContextDependency,
) -> DocumentResponse:
    """
    既存ドキュメントのメタ情報を更新する。

    指定されたドキュメントIDが存在しない場合は 404 を返す。

    Notes
    -----
    ここでの更新は「メタデータ」のみであり、
    ファイル本体の差し替えは対象外。
    """

    updated = await update_document(document_id, payload, user=user)

    if not updated:
        # 更新対象が見つからなかった場合は 404 を返し、UI 側で再取得を促す。
        _raise_document_not_found()

    if "department_code" not in updated:
        refreshed = await fetch_document(document_id)
        if not refreshed:
            # UPDATE 直後に取得できないケースはほぼ無いが、念のため同様に 404 を通知する。
            _raise_document_not_found()
        updated = refreshed

    return DocumentResponse(**updated)


# ============================================================
# 2-1. ドキュメント更新（ファイル差し替えを含む）
# ============================================================
@router.put(
    "/{document_id}/replace",
    response_model=DocumentResponse,
)
async def replace_document(
    document_id: UUID,
    user: UserContextDependency,
    title: str = Form(...),
    department_code: Optional[str] = Form(None),
    document_type: Optional[str] = Form(None),
    registration_type: str = Form("manual"),
    is_auto_import_target: str = Form("false"),
    source_uri: Optional[str] = Form(None),
    public_scope: str = Form("internal"),
    status_value: Optional[str] = Form(None, alias="status"),
    file: UploadFile | None = File(None),
) -> DocumentResponse:
    """既存ドキュメントのメタ情報と本体ファイルを同時に更新する。"""

    normalized_department = _normalize_optional(department_code)
    normalized_document_type = _normalize_optional(document_type)
    normalized_source_uri = _normalize_optional(source_uri)
    normalized_status = _normalize_optional(status_value)

    payload = DocumentUpdateRequest(
        title=title,
        department_code=normalized_department,
        document_type=normalized_document_type,
        registration_type=registration_type,
        is_auto_import_target=_to_bool(is_auto_import_target),
        source_uri=normalized_source_uri,
        public_scope=public_scope,
        status=normalized_status,
    )

    if file is None:
        updated = await update_document(document_id, payload, user=user)

        if not updated:
            _raise_document_not_found()

        if "department_code" not in updated:
            refreshed = await fetch_document(document_id)
            if not refreshed:
                _raise_document_not_found()
            updated = refreshed

        return DocumentResponse(**updated)

    existing = await fetch_document(document_id)
    if not existing:
        _raise_document_not_found()

    await delete_document(document_id, user=user)

    metadata_kwargs = payload.dict(exclude={"status"}, exclude_none=True)
    metadata = DocumentMetadata(**metadata_kwargs)

    try:
        created = await create_document(file, metadata, user=user)
    except EmbeddingError as exc:
        _raise_embedding_unavailable(exc)
    except DocumentParsingError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    new_document_id = created["document_id"]

    if payload.status:
        await update_document(new_document_id, payload, user=user)

    refreshed = await fetch_document(new_document_id)
    if not refreshed:
        _raise_document_not_found()

    return DocumentResponse(**refreshed)


# ============================================================
# 3. ドキュメント削除
# ============================================================
@router.delete(
    "/{document_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def remove_document(
    document_id: UUID,
    user: UserContextDependency,
) -> None:
    """
    指定されたドキュメントを削除する。

    - DB上の document レコードを削除
    - 関連する document_chunks も cascade削除（サービス層で実施）

    成功時は内容なし(204 No Content)を返す。
    """
    await delete_document(document_id, user=user)


# ============================================================
# 4. ドキュメント詳細取得
# ============================================================
@router.get(
    "/{document_id}",
    response_model=DocumentResponse,
)
async def get_document(document_id: UUID) -> DocumentResponse:
    """
    特定ドキュメントの詳細情報を取得する。

    Returns
    -------
    DocumentResponse
        該当ドキュメントの詳細情報。
    Raises
    ------
    HTTPException
        該当IDが存在しない場合、404エラーを返す。
    """
    row = await fetch_document(document_id)
    if not row:
        _raise_document_not_found()
    return DocumentResponse(**row)


# ============================================================
# 6. チャンク一覧取得
# ============================================================
@router.get(
    "/chunks/{document_id}",
    response_model=DocumentChunkListResponse,
)
async def get_document_chunks(document_id: UUID) -> DocumentChunkListResponse:
    """
    指定ドキュメントに紐づく「チャンク情報（文書分割単位）」を取得する。

    チャンクには、以下のような要素が含まれる：
    - content : 本文テキスト
    - summary : 要約文
    - tokens_count : トークン数（埋め込みサイズ）

    Returns
    -------
    DocumentChunkListResponse
        チャンク情報の一覧。
    """
    rows = await fetch_document_chunks(document_id)
    items = [DocumentChunk(**row) for row in rows]
    return DocumentChunkListResponse(items=items)


# ============================================================
# 内部補助関数（外部APIでは使用しない）
# ============================================================

def _to_bool(value: Optional[str]) -> bool:
    """
    文字列を Python の bool 型に変換する小ヘルパー関数。

    "true", "1", "yes", "on" → True  
    それ以外、または None → False
    """
    if value is None:
        return False
    return value.lower() in {"true", "1", "yes", "on"}


def _normalize_optional(value: Optional[str]) -> Optional[str]:
    """フォーム入力で渡される空文字列を None へ正規化する。"""

    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def _raise_document_not_found() -> None:
    """共通の 404 レスポンスを送出する。"""

    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="document not found")


def _raise_embedding_unavailable(exc: EmbeddingError) -> None:
    """埋め込み生成失敗時の 503 応答を統一する。"""

    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail="埋め込み生成に失敗しました。時間をおいて再試行してください。",
    ) from exc
