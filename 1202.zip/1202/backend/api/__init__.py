"""API 層（FastAPI ルーター）をまとめたパッケージ。

本パッケージは以下の役割を分担している。

* `router_registry` … エンドポイント群を FastAPI アプリへ一括登録するハブ
* `chat` / `documents` / `faqs` / ... … 各機能領域ごとのルーターとスキーマ定義

`backend.app` 側では `register_routes()` を呼ぶだけで済むように、ここで
公開関数を集約している。これによりアプリ起動コードがシンプルに保たれ、
API の追加や削除に伴ってエントリーポイントを書き換える必要がなくなる。
"""

from backend.api.router_registry import register_routes

# export するシンボルを `register_routes` のみに限定し、`from backend.api import *`
# としてインポートした場合でも意図しないモジュールが公開されないよう制御する。
__all__ = ["register_routes"]
