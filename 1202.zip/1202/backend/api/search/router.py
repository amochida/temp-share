"""検索系エンドポイントのルーティングモジュール。

ドキュメント検索とFAQ検索は絞り込み条件が大きく異なるため、エンドポイントを
明確に分離して提供する。ここではリクエストボディのバリデーションと、
サービス層で組み立てられた検索結果をレスポンススキーマへ変換する処理のみを担当する。
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status

from backend.api.search.schema import (
    DocumentSearchRequest,
    DocumentSearchResponse,
    DocumentSearchResult,
    FAQSearchRequest,
    FAQSearchResponse,
    FAQSearchResult,
)
from backend.foundation.authentication import UserContextDependency
from backend.infrastructure.embedding_client import EmbeddingError
from backend.service import search_service

# `/api/search` 配下のエンドポイントをまとめるルーターを定義する。
router = APIRouter(prefix="/api/search", tags=["search"])


@router.post("/documents", response_model=DocumentSearchResponse)
async def search_documents(
    payload: DocumentSearchRequest,
    user: UserContextDependency,
) -> DocumentSearchResponse:
    """ドキュメント用の全文・意味検索を実行する。

    UI から送られてきた検索条件をサービス層へ渡し、検索結果をスコア順に整列して返却する。
    ユーザー情報はヘッダー経由で注入され、サービス層がログ出力や監査連携を行う。
    """

    try:
        # サービス層に検索処理を委譲し、スコア付き結果一覧を受け取る。
        results = await search_service.search_documents(payload, user=user)
    except EmbeddingError as exc:
        _raise_embedding_unavailable(exc)
    # dict 形式の検索結果を Pydantic モデルへ写像してレスポンス整形する。
    items = [DocumentSearchResult(**item) for item in results]
    return DocumentSearchResponse(items=items)


@router.post("/faqs", response_model=FAQSearchResponse)
async def search_faqs(
    payload: FAQSearchRequest,
    user: UserContextDependency,
) -> FAQSearchResponse:
    """FAQ 検索を実行するエンドポイント。

    FAQ 特有のカテゴリ／種別フィルタを考慮しつつ、全文・意味検索を統合した結果を返す。
    """

    try:
        # FAQ 向け検索ロジックを呼び出し、ランキング済み結果を取得する。
        results = await search_service.search_faqs(payload, user=user)
    except EmbeddingError as exc:
        _raise_embedding_unavailable(exc)
    # 結果の各行を FAQ 用レスポンスモデルへと変換する。
    items = [FAQSearchResult(**item) for item in results]
    return FAQSearchResponse(items=items)


def _raise_embedding_unavailable(exc: EmbeddingError) -> None:
    """ベクトル検索初期化に失敗した際の共通ハンドラ。"""

    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail="ベクトル検索の初期化に失敗しました。時間をおいて再試行してください。",
    ) from exc
