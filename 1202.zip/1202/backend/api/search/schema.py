"""検索APIで利用するPydanticスキーマ。

ドキュメント検索とFAQ検索で入力項目が異なるため、それぞれ独立した
リクエスト／レスポンスモデルを定義している。各クラスには利用シーンや
絞り込み条件の意味を詳しく書き添え、実装を追いやすくしている。
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional
from uuid import UUID

from pydantic import Field

from backend.api.schema_base import APIModel


class DocumentSearchFilters(APIModel):
    """ドキュメント検索で指定可能なフィルタ条件。

    同一項目内で複数値を指定した場合は OR 条件、別の項目と組み合わせると AND 条件。
    UI のチェックボックスやタグ選択の入力内容をそのまま渡す想定。
    """

    departments: Optional[list[str]] = Field(
        None,
        description="対象とする部門コード。空/未指定レコードは常にヒット",
    )
    document_types: Optional[list[str]] = Field(
        None,
        description="ドキュメント種別（documents.type）。空なら全種別",
    )
    public_scopes: Optional[list[str]] = Field(
        None,
        description="公開範囲（documents.public_scope）。内部/限定/公開など",
    )
    statuses: Optional[list[str]] = Field(None, description="処理ステータス（documents.status）")


class DocumentSearchRequest(APIModel):
    """ドキュメント検索API `/api/search/documents` の入力。"""

    text_query: Optional[str] = Field(
        None,
        description="全文検索キーワード。タイトル／チャンク本文に対して LIKE/tsvector 検索",
    )
    semantic_query: Optional[str] = Field(
        None,
        description="意味検索キーワード。ベクトル検索を実行したい場合に指定",
    )
    limit: int = Field(20, ge=1, le=100, description="検索結果の最大件数")
    filters: Optional[DocumentSearchFilters] = Field(
        None,
        description="部門や種別による絞り込み条件。未指定なら全件",
    )


class DocumentSearchResult(APIModel):
    """ドキュメント検索結果の1件分レコード。"""

    document_id: UUID = Field(..., description="ヒットしたドキュメントのID")
    chunk_id: Optional[UUID] = Field(None, description="チャンク単位でヒットした場合のチャンクID")
    title: Optional[str] = Field(None, description="ドキュメントタイトル")
    document_type: Optional[str] = Field(None, description="ドキュメント種別")
    department_code: Optional[str] = Field(None, description="紐付く部門コード")
    public_scope: Optional[str] = Field(None, description="公開範囲（internal / restricted / public）")
    status: Optional[str] = Field(None, description="登録ステータス（ready 等）")
    source_uri: Optional[str] = Field(None, description="原本の参照URI（SharePoint 等）")
    registration_type: Optional[str] = Field(None, description="登録区分（manual/auto）")
    is_auto_import_target: Optional[bool] = Field(None, description="自動取り込み対象フラグ")
    created_at: Optional[datetime] = Field(None, description="作成日時")
    updated_at: Optional[datetime] = Field(None, description="最終更新日時")
    snippet: Optional[str] = Field(None, description="本文から切り出したプレビュー")
    score: float = Field(..., ge=0, description="統合スコア（テキスト＋ベクトルの加重値）")
    source: Literal["metadata", "text", "semantic", "hybrid"] = Field(
        ..., description="この結果が得られた検索手法"
    )


class DocumentSearchResponse(APIModel):
    """ドキュメント検索のレスポンス。"""

    items: list[DocumentSearchResult] = Field(..., description="スコア順に整列済みの結果一覧")


class FAQSearchFilters(APIModel):
    """FAQ検索向けフィルタ。"""

    departments: Optional[list[str]] = Field(None, description="対象とする部門コード")
    categories: Optional[list[str]] = Field(None, description="FAQカテゴリ（複数指定でOR）")
    faq_types: Optional[list[str]] = Field(None, description="FAQ種別（例: policy / procedure）")
    public_scopes: Optional[list[str]] = Field(None, description="公開範囲（internal など）")
    statuses: Optional[list[str]] = Field(None, description="登録ステータス")


class FAQSearchRequest(APIModel):
    """FAQ検索API `/api/search/faqs` の入力。"""

    text_query: Optional[str] = Field(None, description="FAQ質問・回答に対する全文検索キーワード")
    semantic_query: Optional[str] = Field(None, description="意味検索キーワード（埋め込み検索）")
    limit: int = Field(20, ge=1, le=100, description="取得件数の上限")
    filters: Optional[FAQSearchFilters] = Field(None, description="カテゴリ等の絞り込み条件")


class FAQSearchResult(APIModel):
    """FAQ検索結果1件分。"""

    faq_id: UUID = Field(..., description="ヒットしたFAQのID")
    question: str = Field(..., description="質問文")
    answer: str = Field(..., description="回答文")
    category: Optional[str] = Field(None, description="FAQカテゴリ")
    faq_type: Optional[str] = Field(None, description="FAQ種別")
    department_code: Optional[str] = Field(None, description="担当部門コード")
    public_scope: Optional[str] = Field(None, description="公開範囲")
    status: Optional[str] = Field(None, description="登録ステータス")
    created_by: Optional[str] = Field(None, description="登録担当者")
    updated_by: Optional[str] = Field(None, description="最終更新者")
    created_at: Optional[datetime] = Field(None, description="作成日時")
    updated_at: Optional[datetime] = Field(None, description="最終更新日時")
    score: float = Field(..., ge=0, description="合成スコア。値が大きいほど関連性が高い")
    source: Literal["metadata", "text", "semantic", "hybrid"] = Field(
        ..., description="ヒットした検索種別（テキスト／意味／ハイブリッド）"
    )


class FAQSearchResponse(APIModel):
    """FAQ検索レスポンス。"""

    items: list[FAQSearchResult] = Field(..., description="スコア順に整列したFAQの一覧")


__all__ = [
    "DocumentSearchFilters",
    "DocumentSearchRequest",
    "DocumentSearchResult",
    "DocumentSearchResponse",
    "FAQSearchFilters",
    "FAQSearchRequest",
    "FAQSearchResult",
    "FAQSearchResponse",
]
