"""
===========================================
 Feedback API: フィードバック登録エンドポイント
===========================================

このモジュールは、FastAPI のルーター定義を行います。

ユーザーがチャットAIの回答に対して
「Good」または「Bad」と評価したとき、
フロントエンド（例: Web UIやチャット画面）からこのAPIが呼ばれます。

主な役割は以下の通りです：

1. HTTP POST リクエストを受け取る（/api/feedback）
2. 送信データ（FeedbackCreateRequest 型）を検証する
3. 認証済みユーザー情報を受け取る
4. ビジネスロジック層（feedback_service.py）を呼び出す
5. 登録結果をレスポンスとして返す

この層は「HTTP通信の入り口」にあたります。
実際の保存処理はサービス層に委譲し、責務を分離しています。
"""

from __future__ import annotations
from uuid import UUID

from fastapi import APIRouter, Query, status

from backend.foundation.authentication import UserContextDependency
from backend.api.feedback.schema import (
    FeedbackCreateRequest,
    FeedbackCreateResponse,
    FeedbackLatestResponse,
)
from backend.service.feedback_service import create_feedback, list_latest_feedback

# ------------------------------------------------------------
# ルーター定義
# ------------------------------------------------------------
router = APIRouter(
    prefix="/api/feedback",   # APIのルートパス（例: /api/feedback）
    tags=["feedback"],        # OpenAPIドキュメント上の分類タグ
)


@router.post(
    "",
    response_model=FeedbackCreateResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_feedback_endpoint(
    payload: FeedbackCreateRequest,
    user: UserContextDependency,
) -> FeedbackCreateResponse:
    """
    チャット回答に対するフィードバック（Good/Bad）を登録する。

    Parameters
    ----------
    payload : FeedbackCreateRequest
        クライアントから送られてくる評価内容。
        （どのスレッド・どんなメッセージ・どんな評価か）

    user : UserContextDependency
        現在ログインしているユーザー情報。
        認証ミドルウェアが自動で注入する。

    Returns
    -------
    FeedbackCreateResponse
        登録結果として、生成された feedback_id と
        登録日時（created_at）を返す。

    Notes
    -----
    この関数は「APIエンドポイント関数」です。
    実際のDB保存ロジックは service 層の
    `create_feedback()` 関数に委譲しています。
    これにより、API層は「通信と入力検証」だけを担い、
    ロジック層は「ビジネス処理」に専念できる構造となっています。
    """

    # サービス層でフィードバック登録を実行し、保存結果のレコードを受け取る。
    record = await create_feedback(payload, user=user)

    # 返却用スキーマへ詰め替えてクライアントに返す。
    return FeedbackCreateResponse(
        feedback_id=record.id,
        created_at=record.created_at,
    )


@router.get(
    "/latest",
    response_model=FeedbackLatestResponse,
    status_code=status.HTTP_200_OK,
)
async def list_latest_feedback_endpoint(
    user: UserContextDependency,
    thread_id: UUID = Query(..., description="対象スレッドID"),
) -> FeedbackLatestResponse:
    """スレッド内の各アシスタント発話に対する最新評価をまとめて返す。"""

    items = await list_latest_feedback(thread_id, user=user)
    return FeedbackLatestResponse(thread_id=thread_id, items=items)
