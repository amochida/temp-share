"""
=====================================
 Feedback API パッケージの概要
=====================================

このディレクトリ（パッケージ）は、
「AIチャットの回答に対するユーザーフィードバック（good / bad）」を
受け取り、保存するための API を提供します。

FastAPI では、機能ごとに API のルーター（endpoint の集まり）を
独立したモジュールとして管理することが推奨されています。
この `feedback` パッケージもその設計方針に従っています。

本パッケージの構造は以下の通りです。

    feedback/
    ├── __init__.py   ← パッケージのエントリポイント（router を公開）
    ├── router.py     ← APIルート定義（HTTP通信部分）
    ├── schema.py     ← リクエスト・レスポンス形式（データ構造定義）
    └── service/      ← 実際の処理（DB保存など）を行うビジネスロジック層

この __init__.py では、router オブジェクトを外部へ公開します。
これにより、アプリ本体からは以下のように import できます。

    from backend.api.feedback import router

こうしておくと、他のモジュール側では
「feedback の詳細構造」を意識せず router を使えるようになります。
"""

from .router import router

__all__ = ["router"]
