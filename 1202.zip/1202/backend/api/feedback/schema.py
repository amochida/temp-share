"""
====================================
 Feedback API スキーマ定義
====================================

このモジュールは「APIの入出力形式」を定義します。

FastAPIでは、pydanticモデルを使うことで
・データ構造の明確化
・自動バリデーション
・OpenAPI（ドキュメント）自動生成
を実現しています。

ここでは以下のモデルを定義します：

- FeedbackContextMessage … 会話履歴1件分の情報
- FeedbackCreateRequest … クライアントが送るリクエストデータ
- FeedbackCreateResponse … サーバーが返すレスポンス
- FeedbackStoredRecord … DB保存後の内部用レコード表現
"""

from __future__ import annotations
from datetime import datetime
from typing import Literal
from uuid import UUID
from pydantic import Field

from backend.api.schema_base import APIModel

# 評価の選択肢を定義（Literal型により good / bad / cancel のみ許可）
RatingLiteral = Literal["good", "bad", "cancel"]


class FeedbackContextMessage(APIModel):
    """
    会話履歴を1件分保持するモデル。

    Attributes
    ----------
    role : Literal["user", "assistant"]
        どちらの発話かを示す（ユーザー or AI）。

    content : str
        実際のメッセージ内容。
    """

    role: Literal["user", "assistant"]
    content: str


class FeedbackCreateRequest(APIModel):
    """
    フィードバック登録リクエスト。

    クライアント（フロントエンド）から送信されるデータを定義します。

    Attributes
    ----------
    thread_id : UUID
        フィードバック対象のスレッドID。
    assistant_message_id : UUID
        評価したアシスタント発話のメッセージID（messages.id）。
    user_message : str
        ユーザーが送信したメッセージ（質問など）。
    assistant_message : str
        AIが返答したメッセージ。
    rating : RatingLiteral
        good / bad の評価。
    context_messages : list[FeedbackContextMessage]
        フィードバック時点の直近会話履歴（過去10件など）。
    """

    thread_id: UUID
    assistant_message_id: UUID
    user_message: str
    assistant_message: str
    rating: RatingLiteral
    context_messages: list[FeedbackContextMessage] = Field(default_factory=list)


class FeedbackCreateResponse(APIModel):
    """
    フィードバック登録結果のレスポンス。

    Attributes
    ----------
    feedback_id : UUID
        登録されたフィードバックの一意ID。
    status : Literal["ok"]
        登録成功を示す固定値。
    created_at : datetime
        登録日時。
    """

    feedback_id: UUID
    status: Literal["ok"] = "ok"
    created_at: datetime


class FeedbackStoredRecord(APIModel):
    """
    データベースに保存された1件分のレコードを表す内部用モデル。

    Attributes
    ----------
    id : UUID
        フィードバックID。
    created_at : datetime
        登録日時。
    """

    id: UUID
    created_at: datetime


class FeedbackLatestRecord(APIModel):
    """1 件分の最新評価を表す軽量レスポンス。"""

    assistant_message_id: UUID
    rating: RatingLiteral


class FeedbackLatestResponse(APIModel):
    """最新評価一覧を返す API のレスポンス構造。"""

    thread_id: UUID
    items: list[FeedbackLatestRecord] = Field(default_factory=list)
