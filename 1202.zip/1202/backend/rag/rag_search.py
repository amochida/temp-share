"""PostgreSQL 上の文書群を全文×ベクトルのハイブリッドで検索する層。

社内ドキュメントと FAQ を同一インターフェースで扱えるようにし、Retriever
からはテーブル差異を意識せず候補集合を取得できるようにしている。
"""
from __future__ import annotations

import time

from dataclasses import dataclass
from typing import Any, Sequence

from backend.api.search.schema import DocumentSearchFilters, FAQSearchFilters
from backend.foundation.database import DatabaseConnectionPool
from backend.foundation.logging import configure_logging
from backend.infrastructure.embedding_client import compute_embeddings
from backend.rag.text import tokenize_japanese

logger = configure_logging(__name__)

# ファイル名 similarity がこの値未満ならスコアに使わない（soft boost）
FILENAME_SCORE_SOFT_THRESHOLD = 0.5

@dataclass(slots=True)
class HybridWeights:
    """キーワード検索とベクトル検索、およびファイル名ブーストの加重方法を保持する設定値。"""

    keyword: float = 0.4
    vector: float = 0.6
    # ファイル名の一致度に対する重み（デフォルト 0.0 なので既存挙動は変わらない）
    filename: float = 0.0


# 文書インデックスを全文検索とベクトル検索の両方で走査する。
async def search_documents_hybrid(
    *,
    text_query: str,
    semantic_queries: Sequence[str],
    filters: DocumentSearchFilters | None,
    limit: int,
    weights: HybridWeights,
    file_name_hints: Sequence[str] | None = None,
) -> list[dict[str, Any]]:
    """ドキュメントテーブルに対しハイブリッド検索を実行する。"""

    tokens = tokenize_japanese(text_query, mode="query")
    tsquery = _build_tsquery(tokens)

    where_clauses = []
    params: list[Any] = []
    if filters:
        if filters.departments:
            where_clauses.append("(d.department_code = ANY(%s) OR d.department_code IS NULL OR d.department_code = '')")
            params.append(filters.departments)
        if filters.document_types:
            where_clauses.append("(d.type = ANY(%s) OR d.type IS NULL OR d.type = '')")
            params.append(filters.document_types)
        if filters.public_scopes:
            where_clauses.append("d.public_scope = ANY(%s)")
            params.append(filters.public_scopes)
        if filters.statuses:
            where_clauses.append("d.status = ANY(%s)")
            params.append(filters.statuses)

    where_sql = " AND ".join(where_clauses)
    if where_sql:
        where_sql = " AND " + where_sql

    semantic_inputs = [item for item in semantic_queries if item and item.strip()]

    # --------------------------------------------------------
    # ファイル名ヒント（複数）を正規化して最大 5 件に絞る
    # --------------------------------------------------------
    normalized_file_name_hints: list[str] = []
    if file_name_hints:
        for h in file_name_hints:
            if not h:
                continue
            s = h.strip()
            if s:
                normalized_file_name_hints.append(s)
    # LLM 側も「最大 5 件」で返す想定だが、念のためここでも 5 件に制限
    normalized_file_name_hints = normalized_file_name_hints[:5]

    # ファイル名ヒントがある場合だけ similarity を計算し、なければ常に 0 を返す
    # NOTE: d.file_name は実際の「ファイル名」を持っているカラムに置き換える
    if normalized_file_name_hints:
        sim_exprs = ["similarity(coalesce(d.title, ''), %s)" for _ in normalized_file_name_hints]
        file_name_score_select = f"GREATEST({', '.join(sim_exprs)}) AS file_name_score,"
        file_name_hint_params: list[Any] = list(normalized_file_name_hints)
    else:
        file_name_score_select = "0.0 AS file_name_score,"
        file_name_hint_params = []

    logger.debug(
        "ドキュメントハイブリッド検索を開始",
        extra={
            "query_preview": text_query[:80],
            "token_count": len(tokens),
            "tokens": tokens,
            "tsquery": tsquery,
            "tsvector_column": "document_chunks.content_tsv",
            "vector_column": "document_chunks.embedding",
            "limit": limit,
            "filters": filters.model_dump(exclude_none=True) if filters else None,
            "where_sql": where_sql.strip() if where_sql else None,
            "semantic_queries": semantic_inputs,
            "file_name_hints": normalized_file_name_hints,
            "weights": {
                "keyword": weights.keyword,
                "vector": weights.vector,
                "filename": getattr(weights, "filename", 0.0),
            },
        },
    )

    # ----------------
    # テキスト検索
    # ----------------
    text_rows: list[dict[str, Any]] = []
    if tsquery:
        sql = f"""
            SELECT
                d.id AS document_id,
                dc.id AS chunk_id,
                d.title,
                d.type AS document_type,
                d.department_code,
                d.public_scope,
                d.status,
                d.source_uri,
                d.registration_type,
                d.is_auto_import_target,
                d.created_at,
                d.updated_at,
                dc.chunk_order,
                dc.chunk_label,
                dc.page_start,
                dc.page_end,
                dc.metadata AS chunk_metadata,
                dc.content AS snippet,
                {file_name_score_select}
                ts_rank_cd(dc.content_tsv, to_tsquery('simple', %s)) AS text_score
            FROM document_chunks dc
            JOIN documents d ON d.id = dc.document_id
            WHERE dc.content_tsv @@ to_tsquery('simple', %s)
            {where_sql}
            ORDER BY text_score DESC
            LIMIT %s
        """
        text_params: list[Any] = [*file_name_hint_params, tsquery, tsquery, *params, limit]
        text_start = time.monotonic()
        text_rows = await DatabaseConnectionPool.fetch_all_async(sql, text_params)
        text_latency_ms = int((time.monotonic() - text_start) * 1000)
        logger.info(
            "ドキュメントの全文検索が完了",
            extra={
                "event": "documents.text_search.complete",
                "latency_ms": text_latency_ms,
                "row_count": len(text_rows),
                "token_count": len(tokens),
                "tsquery": tsquery,
                "limit": limit,
            },
        )

    # ----------------
    # ベクトル検索
    # ----------------
    semantic_rows: list[dict[str, Any]] = []
    if semantic_inputs:
        vectors = await compute_embeddings(semantic_inputs)
        sql = f"""
            SELECT
                d.id AS document_id,
                dc.id AS chunk_id,
                d.title,
                d.type AS document_type,
                d.department_code,
                d.public_scope,
                d.status,
                d.source_uri,
                d.registration_type,
                d.is_auto_import_target,
                d.created_at,
                d.updated_at,
                dc.chunk_order,
                dc.chunk_label,
                dc.page_start,
                dc.page_end,
                dc.metadata AS chunk_metadata,
                dc.content AS snippet,
                {file_name_score_select}
                1 - (dc.embedding <=> %s::vector) AS vector_score
            FROM document_chunks dc
            JOIN documents d ON d.id = dc.document_id
            WHERE dc.embedding IS NOT NULL
            {where_sql}
            ORDER BY dc.embedding <=> %s::vector
            LIMIT %s
        """
        for idx, vector in enumerate(vectors, start=1):
            semantic_params: list[Any] = [*file_name_hint_params, vector, *params, vector, limit]
            vector_start = time.monotonic()
            rows = await DatabaseConnectionPool.fetch_all_async(sql, semantic_params)
            vector_latency_ms = int((time.monotonic() - vector_start) * 1000)
            semantic_rows.extend(rows)
            logger.info(
                "ドキュメントのベクトル検索が完了",
                extra={
                    "event": "documents.vector_search.complete",
                    "latency_ms": vector_latency_ms,
                    "row_count": len(rows),
                    "query_index": idx,
                    "limit": limit,
                    "semantic_query": semantic_inputs[idx - 1] if idx - 1 < len(semantic_inputs) else None,
                },
            )

    merged = _merge_candidates(text_rows, semantic_rows, origin="documents", weights=weights)
    logger.debug(
        "ドキュメントハイブリッド検索が完了",
        extra={
            "text_rows": len(text_rows),
            "semantic_rows": len(semantic_rows),
            "merged": len(merged),
            "top_candidates": [
                {
                    "document_id": row.get("document_id"),
                    "chunk_id": row.get("chunk_id"),
                    "score": row.get("score"),
                    "source": row.get("source"),
                    "file_name_score": row.get("file_name_score"),
                }
                for row in merged[:5]
            ],
            "score_breakdown": _debug_score_breakdown(merged, weights),
        },
    )
    logger.info(
        "ドキュメントのハイブリッド検索結果を統合しました",
        extra={
            "event": "documents.hybrid.merge.complete",
            "text_rows": len(text_rows),
            "semantic_rows": len(semantic_rows),
            "merged": len(merged),
            "file_name_hints": normalized_file_name_hints,
        },
    )
    return merged


# FAQ インデックスを全文検索とベクトル検索の両方で走査する。
async def search_faqs_hybrid(
    *,
    text_query: str,
    semantic_queries: Sequence[str],
    filters: FAQSearchFilters | None,
    limit: int,
    weights: HybridWeights,
) -> list[dict[str, Any]]:
    """FAQ テーブルに対してハイブリッド検索を実行する。

    Args:
        text_query: ユーザー質問の原文。
        semantic_queries: LLM などから得た意味検索用の補助クエリ群。
        filters: FAQ 種別やカテゴリなどの絞り込み条件。
        limit: 取得上限件数。
        weights: テキスト／ベクトルスコアを合成するための重み設定。

    Returns:
        dict のリスト。`origin` に ``"faqs"`` が含まれ、回答文は `answer` に格納される。
    """
    tokens = tokenize_japanese(text_query, mode="query")
    tsquery = _build_tsquery(tokens)

    where_clauses = []
    params: list[Any] = []
    if filters:
        if filters.departments:
            where_clauses.append("(f.department_code = ANY(%s) OR f.department_code IS NULL OR f.department_code = '')")
            params.append(filters.departments)
        if filters.categories:
            where_clauses.append("(f.category = ANY(%s) OR f.category IS NULL OR f.category = '')")
            params.append(filters.categories)
        if filters.faq_types:
            where_clauses.append("(f.type = ANY(%s) OR f.type IS NULL OR f.type = '')")
            params.append(filters.faq_types)
        if filters.public_scopes:
            where_clauses.append("f.public_scope = ANY(%s)")
            params.append(filters.public_scopes)
        if filters.statuses:
            where_clauses.append("f.status = ANY(%s)")
            params.append(filters.statuses)

    where_sql = " AND ".join(where_clauses)
    if where_sql:
        where_sql = " AND " + where_sql

    semantic_inputs = [item for item in semantic_queries if item and item.strip()]

    logger.debug(
        "FAQハイブリッド検索を開始",
        extra={
            "query_preview": text_query[:80],
            "token_count": len(tokens),
            "tokens": tokens,
            "tsquery": tsquery,
            "tsvector_column": "faqs.content_tsv",
            "vector_column": "faqs.embedding",
            "limit": limit,
            "filters": filters.model_dump(exclude_none=True) if filters else None,
            "where_sql": where_sql.strip() if where_sql else None,
            "semantic_queries": semantic_inputs,
        },
    )

    text_rows: list[dict[str, Any]] = []
    if tsquery:
        sql = f"""
            SELECT
                f.id AS faq_id,
                f.question,
                f.answer,
                f.category,
                f.type AS faq_type,
                f.department_code,
                f.public_scope,
                f.status,
                f.created_by,
                f.updated_by,
                f.created_at,
                f.updated_at,
                ts_rank_cd(f.content_tsv, to_tsquery('simple', %s)) AS text_score
            FROM faqs f
            WHERE f.content_tsv @@ to_tsquery('simple', %s)
            {where_sql}
            ORDER BY text_score DESC
            LIMIT %s
        """
        text_start = time.monotonic()
        text_rows = await DatabaseConnectionPool.fetch_all_async(sql, [tsquery, tsquery, *params, limit])
        text_latency_ms = int((time.monotonic() - text_start) * 1000)
        logger.info(
            "FAQの全文検索が完了",
            extra={
                "event": "faqs.text_search.complete",
                "latency_ms": text_latency_ms,
                "row_count": len(text_rows),
                "tsquery": tsquery,
                "limit": limit,
            },
        )

    semantic_rows: list[dict[str, Any]] = []
    if semantic_inputs:
        vectors = await compute_embeddings(semantic_inputs)
        sql = f"""
            SELECT
                f.id AS faq_id,
                f.question,
                f.answer,
                f.category,
                f.type AS faq_type,
                f.department_code,
                f.public_scope,
                f.status,
                f.created_by,
                f.updated_by,
                f.created_at,
                f.updated_at,
                1 - (f.embedding <=> %s::vector) AS vector_score
            FROM faqs f
            WHERE f.embedding IS NOT NULL
            {where_sql}
            ORDER BY f.embedding <=> %s::vector
            LIMIT %s
        """
        for idx, vector in enumerate(vectors, start=1):
            vector_start = time.monotonic()
            rows = await DatabaseConnectionPool.fetch_all_async(sql, [vector, *params, vector, limit])
            vector_latency_ms = int((time.monotonic() - vector_start) * 1000)
            semantic_rows.extend(rows)
            logger.info(
                "FAQのベクトル検索が完了",
                extra={
                    "event": "faqs.vector_search.complete",
                    "latency_ms": vector_latency_ms,
                    "row_count": len(rows),
                    "query_index": idx,
                    "limit": limit,
                },
            )

    merged = _merge_candidates(text_rows, semantic_rows, origin="faqs", weights=weights)
    logger.debug(
        "FAQハイブリッド検索が完了",
        extra={
            "text_rows": len(text_rows),
            "semantic_rows": len(semantic_rows),
            "merged": len(merged),
            "top_candidates": [
                {
                    "faq_id": row.get("faq_id"),
                    "score": row.get("score"),
                    "source": row.get("source"),
                }
                for row in merged[:5]
            ],
            "score_breakdown": _debug_score_breakdown(merged, weights),
        },
    )
    logger.info(
        "FAQのハイブリッド検索結果を統合しました",
        extra={
            "event": "faqs.hybrid.merge.complete",
            "text_rows": len(text_rows),
            "semantic_rows": len(semantic_rows),
            "merged": len(merged),
        },
    )
    return merged


def _build_tsquery(tokens: Sequence[str]) -> str:
    """日本語トークン列から PostgreSQL simple 辞書向け tsquery を生成する。

    Args:
        tokens: 形態素分解後のトークン配列。

    Returns:
        str: tsquery 文字列。空トークンの場合は空文字列を返す。
    """

    sanitized = [token.replace("'", "") for token in tokens if token]
    return " | ".join(sanitized)


def _merge_candidates(
    text_rows: Sequence[dict[str, Any]],
    vector_rows: Sequence[dict[str, Any]],
    *,
    origin: str,
    weights: HybridWeights,
) -> list[dict[str, Any]]:
    """全文検索結果とベクトル検索結果を統合し最終スコアを算出する。"""

    merged: dict[str, dict[str, Any]] = {}

    for row in text_rows:
        key = _candidate_key(row, origin)
        entry = merged.setdefault(key, row.copy())
        entry["text_score"] = float(row.get("text_score", 0.0))
        entry.setdefault("vector_score", 0.0)
        entry["file_name_score"] = max(
            float(row.get("file_name_score", 0.0)),
            float(entry.get("file_name_score", 0.0)),
        )
        entry["origin"] = origin
        entry["source"] = "text"

    for row in vector_rows:
        key = _candidate_key(row, origin)
        entry = merged.setdefault(key, row.copy())
        entry["vector_score"] = max(
            float(row.get("vector_score", 0.0)),
            float(entry.get("vector_score", 0.0)),
        )
        entry.setdefault("text_score", 0.0)
        entry["file_name_score"] = max(
            float(row.get("file_name_score", 0.0)),
            float(entry.get("file_name_score", 0.0)),
        )
        entry["origin"] = origin
        entry["source"] = "semantic"

    filename_weight = getattr(weights, "filename", 0.0)

    results: list[dict[str, Any]] = []
    for entry in merged.values():
        text_score = float(entry.get("text_score", 0.0))
        vector_score = float(entry.get("vector_score", 0.0))

        raw_file_name_score = float(entry.get("file_name_score", 0.0))
        # 類似度が低いものは 0 に落として完全に無視（soft boost）
        file_name_score = (
            raw_file_name_score
            if raw_file_name_score >= FILENAME_SCORE_SOFT_THRESHOLD
            else 0.0
        )

        hybrid = (
            weights.keyword * text_score
            + weights.vector * vector_score
            + filename_weight * file_name_score
        )
        entry["score"] = hybrid
        results.append(entry)

    return sorted(results, key=lambda item: item.get("score", 0.0), reverse=True)


def _candidate_key(row: dict[str, Any], origin: str) -> str:
    """同一レコードを判定するためのキーを生成する。

    Args:
        row: クエリで返却された 1 レコード分の辞書。
        origin: documents か faqs かを示す識別子。

    Returns:
        str: Document の場合は document_id:chunk_id、FAQ の場合は faq_id を返す。
    """

    if origin == "documents":
        return f"{row.get('document_id')}:{row.get('chunk_id')}"
    return str(row.get("faq_id"))


def _debug_score_breakdown(
    rows: Sequence[dict[str, Any]],
    weights: HybridWeights,
    *,
    limit: int = 5,
) -> list[dict[str, Any]]:
    """上位候補のスコア内訳をデバッグログ向けにまとめる。"""

    filename_weight = getattr(weights, "filename", 0.0)
    breakdown: list[dict[str, Any]] = []
    for row in rows[:limit]:
        text_score = float(row.get("text_score") or 0.0)
        vector_score = float(row.get("vector_score") or 0.0)
        raw_file_name_score = float(row.get("file_name_score") or 0.0)
        effective_file_name_score = (
            raw_file_name_score
            if raw_file_name_score >= FILENAME_SCORE_SOFT_THRESHOLD
            else 0.0
        )
        breakdown.append(
            {
                "document_id": row.get("document_id"),
                "chunk_id": row.get("chunk_id"),
                "faq_id": row.get("faq_id"),
                "score": row.get("score"),
                "source": row.get("source"),
                "text_score": text_score,
                "vector_score": vector_score,
                "file_name_score_raw": raw_file_name_score,
                "file_name_score_effective": effective_file_name_score,
                "weighted_components": {
                    "keyword": weights.keyword * text_score,
                    "vector": weights.vector * vector_score,
                    "filename": filename_weight * effective_file_name_score,
                },
            }
        )
    return breakdown


__all__ = [
    "HybridWeights",
    "search_documents_hybrid",
    "search_faqs_hybrid",
]
