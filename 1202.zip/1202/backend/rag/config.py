"""RAG パイプライン全体で共有するチューニング用定数群。"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RagTuning:
    """RAG の主要パラメータをひとまとめにした不変の設定値。"""

    # Retriever / search
    doc_candidate_limit: int = 40
    faq_candidate_limit: int = 20
    hybrid_vector_weight: float = 0.6
    hybrid_keyword_weight: float = 0.4

    # Reranker / prompt
    rerank_top_k: int = 8
    prompt_document_limit: int = 8
    doc_citation_limit: int = 5
    faq_citation_limit: int = 5

    # Conversation context handling
    prompt_history_turns: int = 12
    query_rewrite_history_turns: int = 12
    query_rewrite_char_limit: int = 800


rag_tuning = RagTuning()
"""デフォルト値を保持する RAG チューニング設定。"""

__all__ = ["RagTuning", "rag_tuning"]
