"""LLM に会話内容を評価させ、検索モード（docs / faqs の優先度）を判定するモジュール。

RAG パイプラインの最初の LLM 呼び出しとして、
「履歴（history）＋ 最新質問（question）」をもとに、
どのデータソースを優先して検索すべきかを決定する。

LangChain の ChatPromptTemplate と Runnable（prompt | llm）を使い、
1-shot 推論で以下のいずれかを JSON で返させる：

    - docs_only
    - faqs_only
    - both_docs_and_faqs
    - docs_priority
    - faqs_priority

この判定結果は、その後の検索件数・検索方式（document / FAQ）に影響する
RAG パイプライン上の重要な分岐となる。
"""
from __future__ import annotations

import json
import time
from typing import Literal

from langchain_core.prompts import ChatPromptTemplate

from backend.foundation.logging import configure_logging
from backend.foundation.llm_client import extract_token_usage, get_langchain_chat_llm

logger = configure_logging(__name__)

# 検索モード定義
# LLM が返してくる "retrieval_mode" の値を型として定義しておく。
RetrievalMode = Literal[
    "docs_only",
    "faqs_only",
    "both_docs_and_faqs",
    "docs_priority",
    "faqs_priority",
]

# JSON パース失敗など「LLM 応答が正常でない場合」のフォールバックとして使う。
DEFAULT_MODE: RetrievalMode = "both_docs_and_faqs"

def _build_prompt() -> ChatPromptTemplate:
    """検索モード判定に使う ChatPromptTemplate を構築する。

    ChatPromptTemplate は LangChain が提供する
    「役割（system/human）付きメッセージのテンプレート構造体」。

    このテンプレートでは、履歴（history）と質問（question）を埋め込み、
    LLM に JSON 形式 {"retrieval_mode": "..."} を返させるよう指示する。

    Returns:
        ChatPromptTemplate:
            system / human メッセージを構造化し、
            {history}, {question} に変数を注入できるプロンプト。
    """

    return ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "あなたは会話の文脈を分析し、検索モードを決定するアナリストです。"
                "常に最新のユーザー質問を最優先しつつ、直近の履歴から関連情報があれば補足的に考慮してください。"
                "必ず JSON 形式 {{\"retrieval_mode\": \"mode\"}} だけを返してください。"
            ),
            (
                "human",
                "会話履歴（必要なら参照。空の場合は無視してよい）:\n{history}\n\n"
                "最新の質問（必ずこれを優先）:\n{question}\n\n"
                "以下から最適なモードを1つ選び、JSONで返してください:\n"
                "docs_only / faqs_only / both_docs_and_faqs / docs_priority / faqs_priority"
            ),
        ]
    )

def _parse_mode(text: str) -> RetrievalMode:
    """LLM の JSON 応答を解析し、検索モードを抽出する。

    LLM が返した文字列は JSON の前提だが、
    - JSON 形式の崩壊
    - retrieval_mode キーの欠落
    - 想定外の文字列
    が起こりうるため、すべてにフォールバックを用意して堅牢性を確保する。

    Args:
        text (str):
            LLM から返却された JSON 文字列（想定）。

    Returns:
        RetrievalMode:
            バリデーション済みの検索モード。
            問題があれば DEFAULT_MODE にフォールバックする。
    """

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.debug(
            "検索モード応答のJSON解析に失敗",
            extra={"raw_response": text, "error": str(exc)},
        )
        return DEFAULT_MODE

    mode = data.get("retrieval_mode", DEFAULT_MODE)

    # 予期しない文字列なら DEFAULT_MODE に丸める
    if mode not in {
        "docs_only",
        "faqs_only",
        "both_docs_and_faqs",
        "docs_priority",
        "faqs_priority",
    }:
        logger.debug(
            "検索モード応答に未知の値を検出",
            extra={"raw_mode": mode, "raw_response": text},
        )
        return DEFAULT_MODE
    return mode

async def infer_retrieval_mode(history: str, question: str) -> RetrievalMode:
    """「履歴 + 最新質問」を LLM に渡して検索モードを1つ推定させる。

     LangChain Runnable の仕組みにより：

        ChatPromptTemplate（テンプレート） | Chat LLM（推論）

    のパイプラインが構築され、
    ainvoke() によって LLM が実際に実行される。

    本関数は RAG パイプラインの最初の LLM 呼び出しとして、
    「どの情報源（docs / faqs）を優先すべきか」を決定する重要なステップ。

    Args:
        history (str):
            直近の会話履歴テキスト。空でもよい。
            history="" の場合はプロンプト上で「無視してよい」と指示してある。
        question (str):
            最新のユーザー質問（最優先で参照）。

    Returns:
        RetrievalMode:
            LLM が推論した検索モード。
            JSON パースに失敗した場合や未知値は DEFAULT_MODE へフォールバック。
    """

    llm = get_langchain_chat_llm(temperature=0.0)

    # 検索モード判定に使う ChatPromptTemplate を構築
    prompt = _build_prompt()

    # prompt → llm をパイプ（チェーン）で接続
    chain = prompt | llm

    # llm の実行
    logger.debug(
        "検索モード判定リクエストを送信",
        extra={
            "history": history,
            "question": question,
        },
    )
    start_ts = time.monotonic()
    response = await chain.ainvoke({"history": history, "question": question})
    latency_ms = int((time.monotonic() - start_ts) * 1000)

    # ChatMessage 形式 / 生文字列 の両方に対応
    text = response.content if hasattr(response, "content") else str(response)
    normalized = text.strip()
    mode = _parse_mode(normalized)
    logger.debug(
        "検索モード判定レスポンスを受信",
        extra={
            "raw_response": normalized,
            "mode": mode,
        },
    )
    usage = extract_token_usage(response)
    logger.info(
        "検索モード判定のLLM呼び出しが完了",
        extra={
            "event": "retrieval_mode.llm_usage",
            "latency_ms": latency_ms,
            "prompt_tokens": usage["prompt_tokens"],
            "completion_tokens": usage["completion_tokens"],
            "total_tokens": usage["total_tokens"],
            "mode": mode,
        },
    )
    # JSON 応答を解析し、検索モードを抽出し返却
    return mode


__all__ = ["RetrievalMode", "DEFAULT_MODE", "infer_retrieval_mode"]
