"""RAG の検索結果（Retriever の候補）を CrossEncoder で再ランキングするモジュール。

このモジュールは LangChain とは直接関係しないが、LangChain Document を入力として
「検索候補をより賢く順位付けする」ために使われる。

RAG の一般的な構成は：

    Retriever（pgvector） → Reranker（CrossEncoder） → LLM（rag_chain）

Reranker は Retriever の弱点（文脈理解が浅い）を補う重要なステップであり、
質問と文書をペアで入力し “意味的関連度” を推定することで候補を並べ直す。
"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any, Sequence

from langchain_core.documents import Document

from backend.foundation.logging import configure_logging
from backend.foundation.settings import settings
from sentence_transformers import CrossEncoder

# 利用するクロスエンコーダーモデル名と格納ディレクトリ。
_DEFAULT_MODEL_NAME = "hotchpotch/japanese-reranker-tiny-v2"
_DEFAULT_MODEL_DIR = "/app/models/japanese-reranker-tiny-v2"


def _resolve_model_name() -> str:
    """環境変数経由で指定されたリランカーモデル名を settings から取得する。"""

    configured = (settings.reranker.model_name or "").strip()
    return configured or _DEFAULT_MODEL_NAME


MODEL_NAME = _resolve_model_name()
MODEL_DIR = Path(os.getenv("RERANKER_MODEL_DIR", _DEFAULT_MODEL_DIR)).expanduser()

logger = configure_logging(__name__)
_reranker: CrossEncoder | None = None       # モデル本体（キャッシュ用）
_reranker_lock: asyncio.Lock | None = None  # 非同期ロード用のロック


async def rerank_candidates(
    *,
    query: str,
    candidates: Sequence[dict[str, Any]],
    top_k: int,
) -> list[dict[str, Any]]:
    """再ランキング対象の候補辞書を CrossEncoder でスコアリングする。

    この関数は実際に CrossEncoder を使う「本体」。
    Retriever（pgvector）が返した候補は「似ている順」ではあるが、
    “質問に本当に答えているか”は判断できない。

    CrossEncoder は質問と文書をペアでモデルに入力し、
    文脈理解に基づいた「関連度スコア」を算出する。

    最終スコアは retriever_score と crossencoder_score を混合した値：
        combined_score = 0.6 * retriever_score + 0.4 * cross_score

    Args:
        query (str):
            ユーザーの最新質問文。
        candidates (Sequence[dict[str, Any]]):
            Retriever が返した候補辞書（snippet や title が含まれる）。
        top_k (int):
            返却する最大件数（上位 k 件）。

    Returns:
        list[dict[str, Any]]:
            combined score による上位 top_k 件の候補辞書。
            metadata["score"] が更新されて返される。
    """
    # 候補が空 or 上位件数が 0 の場合は何も返さない
    if not candidates or top_k <= 0:
        return []

    # CrossEncoder モデルをロード（初回のみ読み込み、以後キャッシュ）
    encoder = await _load_reranker()

    logger.debug(
        "CrossEncoderによる再ランキングを開始",
        extra={
            "query": query,
            "candidate_count": len(candidates),
            "top_k": top_k,
        },
    )

    # 文書ごとに "タイトル + 本文" のテキストを作る
    # この「質問 + 文書」のセットを CrossEncoder に食わせる。
    texts: list[str] = []
    for item in candidates:
        snippet = item.get("snippet") or item.get("answer") or ""
        title = item.get("title") or item.get("question") or ""
        texts.append(f"{title}\n{snippet}".strip())

    # CrossEncoder は (query, passage) のペアを入力形式とする
    pairs = list(zip([query] * len(texts), texts))

    # CrossEncoder は CPU でも動くが重いので thread に逃がす
    scores = await asyncio.to_thread(encoder.predict, pairs)
    sample_meta = []
    for i in range(min(len(scores), 3)):
        cand = candidates[i] if i < len(candidates) else {}
        snippet_text = cand.get("snippet") or cand.get("answer") or ""
        sample_meta.append(
            {
                "document_id": cand.get("document_id"),
                "chunk_id": cand.get("chunk_id"),
                "faq_id": cand.get("faq_id"),
                "title": cand.get("title") or cand.get("question"),
                "snippet_length": len(snippet_text),
                "score": float(scores[i]),
            }
        )
    logger.debug(
        "CrossEncoderのスコアを取得",
        extra={
            "sample_candidates": sample_meta,
        },
    )

    # Retriever スコアと CrossEncoder スコアを混ぜて「最終スコア」を作る
    reranked: list[dict[str, Any]] = []
    for item, score in zip(candidates, scores):
        base_score = float(item.get("score", 0.0))
        combined = base_score * 0.6 + float(score) * 0.4
        enriched = item.copy()
        enriched["score"] = combined
        reranked.append(enriched)

    # スコアの高い順にソートし、上位 top_k を返す
    reranked.sort(key=lambda entry: entry.get("score", 0.0), reverse=True)
    top_results = reranked[:top_k]
    logger.debug(
        "再ランキング処理が完了",
        extra={
            "returned": len(top_results),
            "top_candidates": [
                {
                    "document_id": item.get("document_id"),
                    "faq_id": item.get("faq_id"),
                    "score": item.get("score"),
                }
                for item in top_results[:5]
            ],
        },
    )
    return top_results


async def rerank_documents(
    *,
    query: str,
    documents: Sequence[Document],
    top_k: int,
) -> list[Document]:
    """LangChain Document 配列を CrossEncoder で再ランキングする。

    この関数は「LangChain RAG パイプラインの一部として Document を扱うための橋渡し」。

    retriever → Document[]
    reranker  → Document[]（score 更新済み）
    rag_chain → Document[]（LLM の context）

    の流れをつなぐ重要な位置にある。

    Args:
        query (str):
            最新のユーザー質問文。
        documents (Sequence[Document]):
            Retriever が返した Document 配列。
        top_k (int):
            上位何件を返すか。

    Returns:
        list[Document]:
            CrossEncoder で関連度が高い順に並び替えられた Document 配列。
            metadata["score"] が更新されている。
    """

    if not documents or top_k <= 0:
        return []

    # Document → dict へ変換（CrossEncoder は dict を扱う）
    candidates: list[dict[str, Any]] = []
    for idx, doc in enumerate(documents):
        metadata = dict(doc.metadata)
        metadata.setdefault("snippet", doc.page_content)
        metadata["__doc_index"] = idx
        candidates.append(metadata)

    logger.debug(
        "Documentを再ランキング用に整形",
        extra={
            "document_count": len(documents),
            "top_k": top_k,
            "sample_scores": [doc.metadata.get("score") for doc in documents[:5]],
        },
    )

    # dict 形式で再ランキング
    reranked_dicts = await rerank_candidates(query=query, candidates=candidates, top_k=top_k)

    # dict → Document に戻す
    reranked_docs: list[Document] = []
    for entry in reranked_dicts:
        idx = entry.pop("__doc_index", None)
        page_content = entry.get("snippet") or entry.get("answer") or ""
        if idx is not None and 0 <= idx < len(documents):
            # snippet が空なら元の Document の本文を fallback として使う
            page_content = page_content or documents[idx].page_content
        reranked_docs.append(Document(page_content=str(page_content), metadata=dict(entry)))
    logger.debug(
        "Documentの再ランキングが完了",
        extra={
            "returned": len(reranked_docs),
            "sample_scores": [doc.metadata.get("score") for doc in reranked_docs[:5]],
        },
    )
    return reranked_docs


async def _load_reranker() -> CrossEncoder:
    """モデルを一度だけロードし、以後はキャッシュを使い回す。

    モデルロードは重いため、
    グローバル変数と asyncio.Lock により「初回のみロード」する設計になっている。

    Returns:
        CrossEncoder:
            再利用可能な CrossEncoder モデルインスタンス。

    Raises:
        FileNotFoundError:
            モデルディレクトリが存在しない、または空のとき。
    """

    global _reranker, _reranker_lock

    # すでにロード済みなら即返す
    if _reranker is not None:
        return _reranker
    
    # 非同期ロック（複数リクエストが同時にロードしようとしないようにする）
    if _reranker_lock is None:
        _reranker_lock = asyncio.Lock()

    async with _reranker_lock:
        # 二重チェック：ロック待ち中に他のタスクがロードした可能性がある
        if _reranker is None:
            model_path = MODEL_DIR
            
            # モデルディレクトリの存在確認
            if not model_path.exists() or not any(model_path.iterdir()):
                message = f"モデルディレクトリ {model_path} が見つからない、または空です"
                logger.error("リランカーのモデルディレクトリが存在しません", extra={"path": str(model_path)})
                raise FileNotFoundError(message)

            logger.info(
                "リランカーモデルの読み込みを開始", extra={"model": MODEL_NAME, "path": str(model_path)}
            )
            try:
                # trust_remote_code=True:
                #   このモデルフォルダには「重み」だけでなく「モデル専用の Python コード
                #   （forward の実装など）」が含まれている可能性がある。
                #   SentenceTransformers はそれらのコードを実行してモデルをロードする仕組み。
                #   そのため「このモデル内の Python コードは信頼して実行してよい」と
                #   明示的に許可する必要がある。
                _reranker = CrossEncoder(str(model_path), trust_remote_code=True)
            except Exception as exc:
                logger.exception("リランカーモデルのロードで例外が発生", extra={"error": str(exc)})
                raise
            logger.info("リランカーモデルの初期化が完了", extra={"model": MODEL_NAME})
        return _reranker


__all__ = ["rerank_candidates", "rerank_documents"]
