"""Sudachi ベースの日本語トークナイズユーティリティ。

本モジュールは、RAG 全体で共通して利用される「日本語向けトークナイズ／トークン数推定」の
ユーティリティ関数群を提供する。

主な責務:
    - SudachiPy を用いた日本語テキストの形態素解析
    - インデックス用／クエリ用で挙動を変えるトークン列の構築
    - Unicode 正規化（NFKC）および、ひらがな → 全角カタカナへの変換
    - RAG における「おおよそのトークン数」の簡易推定

設計方針:
    - SudachiPy のトークナイザー初期化コストが高いため、モジュールロード時に 1 度だけ生成し、
      以降の関数呼び出しでは同一インスタンスを共有する。
    - 名詞は連続するものを「名詞句」としてまとめて扱い、用途（index / query）によって
      複合語のみを使うか、複合語 + 構成要素の両方を使うかを切り替える。
    - ひらがなとカタカナの揺れを減らすため、最終的なトークンは全角カタカナへ統一する。
"""

from __future__ import annotations

from typing import Literal
import unicodedata

from sudachipy import dictionary as sudachi_dictionary
from sudachipy import tokenizer as sudachi_tokenizer
from sudachipy.morpheme import Morpheme

# SudachiPy のトークナイザーは生成コストが高く、スレッドセーフでもあるため、
# モジュールロード時に 1 度だけ初期化してグローバルで共有する。
_SUDACHI_TOKENIZER = sudachi_dictionary.Dictionary().create()


def _normalize_text_for_tokenizer(text: str) -> str:
    """SudachiPy に渡す前のテキストを Unicode 正規化 (NFKC) する。

    日本語テキストには、全角／半角／互換文字など、見た目が近いが Unicode コードポイントが
    異なる文字が多数存在する。この関数では、トークナイザーに入力する前に NFKC 正規化をかけ、
    できる限り表記の揺れを減らす。

    例:
        - "ｱｲｳｴｵ" → "アイウエオ"
        - "①" → "1"
        - "１" → "1"

    Args:
        text (str): 正規化対象の生テキスト。

    Returns:
        str: NFKC 正規化済みテキスト。入力が空文字 / None 相当の場合はそのまま返す。
    """
    if not text:
        return text
    # Sudachi に渡す前にテキスト全体を NFKC で正規化しておく。
    return unicodedata.normalize("NFKC", text)


def _normalize_token(token: str) -> str:
    """トークンを Unicode 正規化し、ひらがなを全角カタカナへ統一する。

    インデックスや検索クエリのトークンとして扱う上で、
    以下のような表記の揺れを吸収することを目的としている。

        - 全角／半角の揺れ
        - ひらがな／カタカナの揺れ（ここでは「全角カタカナ」に統一）

    ひらがなをカタカナに変換することで、「よみ」がひらがなで入力された場合でも、
    カタカナで書かれた用語（例: システム名）とマッチしやすくなる。

    Args:
        token (str): 正規化対象のトークン文字列。

    Returns:
        str: NFKC 正規化＋ひらがな→全角カタカナ変換後のトークン文字列。
    """
    if not token:
        return token

    # まずは NFKC で全角／半角などを正規化。
    token = unicodedata.normalize("NFKC", token)

    chars: list[str] = []
    for ch in token:
        code = ord(ch)
        # ひらがなの主要ブロック: U+3041 (ぁ) ～ U+3096 (ゖ)
        if 0x3041 <= code <= 0x3096:
            # ひらがな → カタカナはコードポイント +0x60 のシフトで対応できる。
            ch = chr(code + 0x60)
        chars.append(ch)

    return "".join(chars)


def tokenize_japanese(
    text: str,
    mode: Literal["index", "query"] = "query",
) -> list[str]:
    """日本語テキストを SudachiPy ベースでトークン配列へ変換する。

    SplitMode.C（比較的粗い分割）をベースに形態素解析を行い、
    - 名詞は連続するものを「名詞句」としてバッファリング
    - 動詞・形容詞・副詞・形状詞などの内容語のみをトークンとして採用
    - 名詞句は `_flush_noun_phrase` で用途に応じたトークン列に変換
    という方針でトークン列を構築する。

    mode によって名詞句の扱いが変わる:

        - "index":
            - 名詞句から複合名詞（すべて結合したもの）を 1 トークンとして登録するのが基本
            - 長い固有表現などを 1 つのキーとしてインデックスに載せたい場合に有効
        - "query":
            - 複合名詞トークンに加え、構成要素の名詞トークンも列挙する
            - ユーザーのクエリが部分一致でもヒットしやすくするためのモード

    Args:
        text (str): トークナイズ対象となる日本語テキスト。
        mode (Literal["index", "query"], optional): 名詞句の扱い方を制御するモード。
            "index" はインデックス構築向け、"query" はクエリ解析向け。
            デフォルトは "query"。

    Returns:
        list[str]: 正規化済みトークン文字列のリスト。
    """
    if not text:
        return []

    # Sudachi に渡す前にテキスト全体を NFKC 正規化しておく。
    normalized = _normalize_text_for_tokenizer(text)
    # Sudachi の SplitMode.C で形態素解析を実行し、Morpheme の列を取得する。
    morphemes = _SUDACHI_TOKENIZER.tokenize(
        normalized,
        sudachi_tokenizer.Tokenizer.SplitMode.C,
    )

    tokens: list[str] = []
    # 連続する名詞を一時的に貯めておくバッファ。
    noun_buffer: list[Morpheme] = []

    for m in morphemes:
        pos = m.part_of_speech()
        if not pos:
            # 品詞情報が取れないものはスキップする。
            continue

        if pos[0] == "名詞":
            # 名詞が続く限りバッファに溜めておき、後で名詞句として処理する。
            noun_buffer.append(m)
            continue

        # 名詞以外の品詞に到達した段階で、
        # これまで溜めていた名詞句を mode に応じてトークン化して tokens に追加する。
        _flush_noun_phrase(noun_buffer, tokens, mode=mode)

        # 名詞以外の品詞のうち、内容語と見なせるものだけをトークンとして採用する。
        if pos[0] in {"動詞", "形容詞", "副詞", "形状詞"}:
            normalized_form = m.normalized_form()
            if normalized_form:
                # 形態素の正規化形を NFKC＋ひらがな→カタカナで正規化し、トークン列に追加。
                tokens.append(_normalize_token(normalized_form))

    # 末尾が名詞で終わっている場合に備え、最後に名詞句バッファをフラッシュする。
    _flush_noun_phrase(noun_buffer, tokens, mode=mode)
    return tokens


def _flush_noun_phrase(
    buffer: list[Morpheme],
    tokens: list[str],
    *,
    mode: Literal["index", "query"],
) -> None:
    """名詞句バッファを mode に応じたトークン列へ変換して追加する。

    `tokenize_japanese` 内で、連続して現れる名詞を一時的に `buffer` に溜めておき、
    品詞の切り替わりタイミングでこの関数を呼び出してフラッシュする。

    処理の流れ:
        1. 各 Morpheme を SplitMode.A でさらに細かく分割し、
           「名詞」に該当するものだけを `fine_nouns` に積む。
        2. SplitMode.A で名詞を得られなかった場合は、元の Morpheme の normalized_form を利用する。
        3. mode が "index" の場合:
            - `fine_nouns` が 2 語以上 → それらを結合した複合名詞のみを tokens に追加。
            - 1 語のみ → その語だけを tokens に追加。
        4. mode が "query" の場合:
            - `fine_nouns` が 2 語以上 → 複合名詞トークンを 1 つ追加した上で、
              各構成要素の名詞トークンも tokens に追加。
            - 1 語のみ → その語だけを tokens に追加。

    Args:
        buffer (list[Morpheme]): 連続する名詞を保持したバッファ。
        tokens (list[str]): 生成したトークンを追加する出力先リスト。
        mode (Literal["index", "query"]): 名詞句の扱いモード。
            "index" はインデックス用（複合名詞中心）、
            "query" はクエリ用（複合＋各構成名詞）。

    Returns:
        None: 副作用として `tokens` を更新し、`buffer` をクリアする。
    """
    if not buffer:
        # バッファが空の場合は何もしない。
        return

    fine_nouns: list[str] = []

    # まずは、より細かい粒度（SplitMode.A）で名詞を抽出してみる。
    for morph in buffer:
        # Morpheme を SplitMode.A で再分割し、サブ形態素列を取得。
        # 分割結果が空（異常ケース）の場合のフォールバックとして、元の morph を使う。
        sub = list(morph.split(sudachi_tokenizer.Tokenizer.SplitMode.A)) or [morph]
        for sm in sub:
            pos = sm.part_of_speech()
            if not pos or pos[0] != "名詞":
                # 名詞以外の品詞は名詞句構成要素とはみなさない。
                continue
            normalized = sm.normalized_form()
            if normalized:
                # 名詞の正規化形を NFKC＋ひらがな→カタカナで統一。
                fine_nouns.append(_normalize_token(normalized))

    # SplitMode.A で名詞を抽出できなかった場合は、元の Morpheme 単位で名詞を拾う。
    if not fine_nouns:
        for morph in buffer:
            normalized = morph.normalized_form()
            if normalized:
                fine_nouns.append(_normalize_token(normalized))

    if mode == "index":
        # インデックス用モード:
        # - 複合名詞を重視し、原則として 1 名詞句 = 1 トークンとしてインデックスに載せる。
        if len(fine_nouns) >= 2:
            # 名詞句（複数語）を 1 つの複合名詞トークンとして結合。
            compound = _normalize_token("".join(fine_nouns))
            tokens.append(compound)
        elif len(fine_nouns) == 1:
            # 単語のみの名詞句はそのまま 1 トークンとして追加。
            tokens.append(fine_nouns[0])
    else:
        # クエリ用モード:
        # - 複合名詞トークンに加え、構成要素の名詞トークンも追加し、
        #   部分一致クエリにもヒットしやすくする。
        if len(fine_nouns) >= 2:
            compound = _normalize_token("".join(fine_nouns))
            tokens.append(compound)
        # 構成要素の名詞トークンもすべて追加。
        tokens.extend(fine_nouns)

    # 処理済みの名詞句バッファをクリアし、次の名詞句に備える。
    buffer.clear()


def build_search_terms(text: str) -> str:
    """インデックス用モードで tokenize した結果を空白連結した文字列を生成する。

    検索インデックス側で「検索用キーワード列」として保存することを想定したヘルパー。
    内部的には `tokenize_japanese(..., mode="index")` を呼び出し、
    生成されたトークンを空白区切りで連結した 1 行の文字列を返す。

    Args:
        text (str): トークン化したい日本語テキスト。

    Returns:
        str: インデックス用モードでトークン化した結果を空白区切りで連結した文字列。
    """
    # インデックス用モードで日本語テキストをトークン列に変換する。
    tokens = tokenize_japanese(text, mode="index")
    return " ".join(tokens)


def estimate_token_count(text: str) -> int:
    """Sudachi ベースでの概算トークン数を返すユーティリティ。

    RAG のチャンク分割処理などで、「テキストの長さ」を文字数ではなく
    「おおよそのトークン数」として扱いたい場合に利用する。

    実装上は、`tokenize_japanese(..., mode="index")` の結果の長さをそのまま用いており、
    空文字のときは 0、それ以外は最低 1 を返す。

    Args:
        text (str): トークン数を見積もりたい日本語テキスト。

    Returns:
        int: 概算のトークン数。空文字は 0、それ以外は少なくとも 1。
    """
    if not text:
        return 0
    # インデックス用モードでトークン化し、その個数をトークン数の近似として利用する。
    tokens = tokenize_japanese(text, mode="index")
    return max(len(tokens), 1)
