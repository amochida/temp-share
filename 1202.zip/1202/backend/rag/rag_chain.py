"""RAG 回答生成を担う LangChain Runnable チェーン定義。"""

from __future__ import annotations

import time
from typing import Any, Sequence

from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_core.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field

from backend.foundation.logging import configure_logging
from backend.foundation.llm_client import extract_token_usage, get_langchain_chat_llm
from backend.rag.config import rag_tuning
from backend.rag.prompts import PromptPattern, get_prompt

logger = configure_logging(__name__)


class RagChainAnswer(BaseModel):
    """RAG チェーンから返す構造化出力のスキーマ。"""

    answer_markdown: str = Field(
        ...,
        description="ユーザーに提示する最終回答本文。Markdown 形式で記載する。",
    )
    cited_document_ids: list[str] = Field(
        default_factory=list,
        description=(
            "回答を作成する際に特に参考になったドキュメントの ID。"
            "重要度の高い順に並べる。"
        ),
    )
    cited_faq_ids: list[str] = Field(
        default_factory=list,
        description=(
            "回答を作成する際に特に参考になった FAQ の ID。"
            "重要度の高い順に並べる。"
        ),
    )


def _format_context(documents: Sequence[Document]) -> str:
    """LangChain Document 配列を LLM に与えるための文脈テキストへ整形する。"""

    def _as_int(value: Any | None) -> int | None:
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    def _format_page_range(start: Any | None, end: Any | None) -> str:
        start_int = _as_int(start)
        end_int = _as_int(end)
        if start_int is None and end_int is None:
            return "-"
        if start_int is None:
            start_int = end_int
        if end_int is None:
            end_int = start_int
        if start_int == end_int:
            return f"p.{start_int}"
        if start_int > end_int:
            start_int, end_int = end_int, start_int
        return f"p.{start_int}-{end_int}"

    lines: list[str] = []
    for idx, doc in enumerate(documents[: rag_tuning.prompt_document_limit], start=1):
        title = doc.metadata.get("title") or doc.metadata.get("question") or "Unnamed"
        metadata = doc.metadata or {}
        chunk_meta = metadata.get("chunk_metadata")
        if not isinstance(chunk_meta, dict):
            chunk_meta = {}
        document_id = metadata.get("document_id") or "-"
        chunk_id = metadata.get("chunk_id") or "-"
        file_name = chunk_meta.get("file_name") or metadata.get("file_name") or "-"
        page_info = _format_page_range(metadata.get("page_start"), metadata.get("page_end"))
        document_type = (
            metadata.get("document_type")
            or metadata.get("faq_type")
            or chunk_meta.get("document_type")
            or "-"
        )
        lines.append(
            f"[#{idx}] ドキュメントタイトル: {title}\n"
            f"本文:\n{doc.page_content}\n"
            f"メタ情報: ドキュメントID={document_id} / チャンクID={chunk_id} / "
            f"ファイル名={file_name} / ページ={page_info} / 種別={document_type}"
        )
    return "\n\n".join(lines)


def _build_prompt(
    pattern: PromptPattern,
    *,
    format_instructions: str | None = None,
) -> ChatPromptTemplate:
    """PromptPattern から ChatPromptTemplate を生成する。"""

    human_template = (
        "参考情報:\n{context}\n\n"
        "履歴:\n{history}\n\n"
        "質問: {question}\n"
        f"{pattern.user_instruction or ''}\n"
        f"{pattern.output_hint or ''}\n"
    )

    if format_instructions:
        human_template += (
            "\n"
            "各参考情報の末尾には「メタ情報: ドキュメントID=... / FAQ ID=... / チャンクID=... / "
            "ファイル名=... / ページ=... / 種別=...」の形式で ID や種別が示されています。\n"
            "あなたは回答を作成する際に特に参考になった出典のみを選び、"
            "そのドキュメントID（および FAQ の場合は FAQ ID）を重要度の高い順に並べてください。\n"
            "最終出力は必ず 1 つの JSON オブジェクトとし、上記で求められている Markdown 形式の回答全文は "
            "`answer_markdown` フィールドの文字列値として格納してください。\n"
            "以下のフォーマット指示に厳密に従ってください:\n"
            "{format_instructions}"
        )

    template = ChatPromptTemplate.from_messages(
        [
            ("system", pattern.system_prompt),
            ("human", human_template),
        ]
    )

    if format_instructions:
        template = template.partial(format_instructions=format_instructions)

    return template


def build_rag_chain(prompt_key: str):
    """指定プロンプト構成で LangChain Runnable を構築する。"""

    pattern = get_prompt(prompt_key)

    # 構造化出力用の PydanticOutputParser を用意し、
    # get_format_instructions() をプロンプトに埋め込む。
    parser = PydanticOutputParser(pydantic_object=RagChainAnswer)
    format_instructions = parser.get_format_instructions()

    prompt = _build_prompt(pattern, format_instructions=format_instructions)
    llm = get_langchain_chat_llm(temperature=0.2, purpose="rag_chain")

    def to_prompt_inputs(data: dict[str, Any]) -> dict[str, Any]:
        """RAG パイプライン内部表現からプロンプト入力を作成する。"""

        context = _format_context(data.get("docs", []))
        history = data.get("history", "")
        question = data.get("question", "")
        logger.debug(
            "RAGチェーン向けプロンプト入力を構築",
            extra={
                "prompt_key": pattern.key,
                "history": history,
                "question": question,
                "context": context,
            },
        )
        return {"context": context, "history": history, "question": question}

    # LLM までは従来通り。構造化出力への変換は run_rag_chain 側で行う。
    chain = RunnableLambda(to_prompt_inputs) | prompt | llm
    return chain


async def run_rag_chain(
    *,
    prompt_key: str,
    documents: Sequence[Document],
    history: str,
    question: str,
) -> tuple[str, list[str], list[str]]:
    """回答生成チェーンを起動し、LLM からの最終出力を取得する。

    Returns:
        tuple[str, list[str], list[str]]:
            - answer_text: Markdown 形式の回答本文
            - cited_document_ids: 回答作成時に参考になったドキュメントIDのリスト（優先度順）
            - cited_faq_ids: 回答作成時に参考になったFAQ IDのリスト（優先度順）
    """

    chain = build_rag_chain(prompt_key)
    start_ts = time.monotonic()
    raw_response = await chain.ainvoke({"docs": documents, "history": history, "question": question})
    latency_ms = int((time.monotonic() - start_ts) * 1000)
    usage = extract_token_usage(raw_response)

    # ChatMessage などから素のテキストを取り出す
    if hasattr(raw_response, "content"):
        raw_text = str(raw_response.content).strip()
    else:
        raw_text = str(raw_response).strip()

    parser = PydanticOutputParser(pydantic_object=RagChainAnswer)

    cited_document_ids: list[str] = []
    cited_faq_ids: list[str] = []

    try:
        structured = parser.parse(raw_text)
        answer_text = structured.answer_markdown.strip()
        cited_document_ids = [doc_id for doc_id in structured.cited_document_ids if doc_id]
        cited_faq_ids = [faq_id for faq_id in structured.cited_faq_ids if faq_id]
    except Exception as exc:  # noqa: BLE001
        # JSON パースに失敗した場合は既存挙動にフォールバック
        logger.warning(
            "RAGチェーンの構造化出力をパースできなかったため、生のテキストをそのまま利用します",
            extra={
                "prompt_key": prompt_key,
                "error": str(exc),
                "raw_preview": raw_text[:200],
            },
        )
        answer_text = raw_text

    logger.debug(
        "RAGチェーンからの回答を受信",
        extra={
            "prompt_key": prompt_key,
            "answer_preview": answer_text[:200],
            "answer_length": len(answer_text),
            "document_ids": [doc.metadata.get("document_id") for doc in documents],
            "cited_document_ids": cited_document_ids,
            "cited_faq_ids": cited_faq_ids,
        },
    )
    logger.info(
        "RAGチェーンでのLLM呼び出しが完了",
        extra={
            "event": "rag_chain.llm_usage",
            "prompt_key": prompt_key,
            "latency_ms": latency_ms,
            "prompt_tokens": usage["prompt_tokens"],
            "completion_tokens": usage["completion_tokens"],
            "total_tokens": usage["total_tokens"],
        },
    )
    return answer_text, cited_document_ids, cited_faq_ids


__all__ = ["run_rag_chain", "build_rag_chain"]
