"""UploadFile からチャンク生成までをオーケストレーションするエントリーポイント。

FastAPI の `UploadFile` を入力として受け取り、ファイル種別ごとに適切なパーサー・
チャンク生成ロジックを呼び出し、最終的に RAG 用のチャンク (`ChunkPayload`) の
リストを返すモジュール。

主な責務:
    - アップロードファイルの拡張子チェックとバリデーション
    - 一時ディレクトリへのファイル保存（ディスク上の Path に変換）
    - Excel 系ファイル（.xls / .xlsx）の専用チャンク処理ルートの呼び出し
    - それ以外のドキュメント（PDF/Word/PPT/TXT）について Docling ベースの
      正規化処理と標準チャンク処理の呼び出し
    - すべてのチャンクに共通で付与するメタデータ（ファイル名や拡張子など）の組み立て

このモジュールは「UploadFile → ChunkPayload[]」の上位フローのみを担当し、
各フォーマットに固有のパース・チャンクロジックは専用モジュール
（`loaders`, `excel`, `chunking`）へ委譲する。
"""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any, Sequence

from fastapi import UploadFile

from backend.foundation.logging import configure_logging
from backend.rag.ingestion.chunking import build_standard_chunks
from backend.rag.ingestion.excel import build_excel_chunks_from_file
from backend.rag.ingestion.loaders import load_normalized_elements_from_file
from backend.rag.ingestion.types import (
    ChunkPayload,
    UnsupportedDocumentTypeError,
    _NormalizedElement,
)

# モジュール専用のロガー。
# アップロードされたファイル情報やチャンク数など、インジェスト処理全体のログを記録する。
logger = configure_logging(__name__)

# Excel として扱う拡張子の集合。
_EXCEL_SUFFIXES = {".xls", ".xlsx"}

# 本インジェストルートが受け付ける拡張子の一覧。
# ここに無い拡張子は早期にバリデーションエラーとする。
_ALLOWED_SUFFIXES = (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt")


async def build_hybrid_chunks_from_upload(
    upload: UploadFile,
    *,
    max_chars: int = 2000,
    min_chars: int = 1200,
    max_excel_rows_per_chunk: int = 200,
) -> list[ChunkPayload]:
    """アップロードされたファイルからチャンクを生成するメインエントリーポイント。

    UploadFile（FastAPI 経由のアップロードファイル）を受け取り、次の流れで処理する:

        1. 拡張子を検査し、サポート対象外なら UnsupportedDocumentTypeErrorで処理終了
        2. ファイル内容をメモリに読み込み、一時ディレクトリに書き出す
        3. 拡張子に応じて以下のいずれかのルートへ振り分ける
            - Excel 系（.xls, .xlsx）: `build_excel_chunks_from_file()`
            - それ以外: `load_normalized_elements_from_file()` で正規化 → `build_standard_chunks()` でチャンク化
        4. 全チャンクに共通で付与するメタデータ（file_name, origin_suffix など）を組み立てる

    Args:
        upload (UploadFile): FastAPI の UploadFile オブジェクト。
            ユーザーがアップロードしたファイルのメタデータと内容を含む。
        max_chars (int): チャンク化で 1チャンクあたりの最大文字数。
        min_chars (int): チャンク化で 1 チャンクとして許容する最小文字数。
        max_excel_rows_per_chunk (int): Excel チャンク処理において、
            1 チャンクあたりに含める最大行数の目安。

    Returns:
        list[ChunkPayload]: 生成されたチャンクのリスト。
            アップロードファイルが空の場合は空リストを返す。

    Raises:
        UnsupportedDocumentTypeError: サポートされていない拡張子のファイルがアップロードされた場合。
    """
    # アップロードされたファイル名から拡張子を取得（大文字・小文字の揺れを吸収）
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in _ALLOWED_SUFFIXES:
        # サポートされていない拡張子の場合、早期にエラーとして返す
        allowed = ", ".join(_ALLOWED_SUFFIXES)
        raise UnsupportedDocumentTypeError(
            f"サポート対象外のファイル形式です（{suffix}）。対応拡張子: {allowed}"
        )

    original_file_name = upload.filename or ""
    # アップロードファイルの中身を一度メモリ上に読み込む
    data = await upload.read()
    data_size = len(data or b"")
    logger.debug(
        "アップロードファイルを受信",
        extra={
            "file_name": original_file_name,
            "suffix": suffix,
            "size_bytes": data_size,
            "max_chars": max_chars,
            "min_chars": min_chars,
            "max_excel_rows_per_chunk": max_excel_rows_per_chunk,
        },
    )
    if not data:
        # ファイル内容が空（0 バイト）の場合はこれ以上処理できないため、空リストを返す
        logger.debug("アップロードファイルが空のため処理を終了", extra={"file_name": original_file_name})
        return []

    # すべてのチャンクに共通で付与するメタデータ
    # 元ファイル名・元拡張子・論理フォーマット名などを保持する
    base_metadata: dict[str, Any] = {
        "file_name": original_file_name,
        "origin_suffix": suffix,
        "origin_format": suffix.lstrip(".").lower(),
    }

    # 一時ディレクトリを作成し、その中にアップロードファイルを書き出す
    # Docling や各種ローダーはファイルパスを前提としているため、このステップで
    # メモリ上のバイト列 → ファイルパス の変換を行う
    with tempfile.TemporaryDirectory() as tmpdir_str:
        tmpdir = Path(tmpdir_str)
        tmp_path = tmpdir / f"upload{suffix}"
        tmp_path.write_bytes(data)
        logger.debug(
            "アップロードファイルを一時ディスクに保存",
            extra={"path": str(tmp_path), "size_bytes": data_size},
        )

        # Excel 系ファイルのチャンク化
        if suffix in _EXCEL_SUFFIXES:
            logger.debug(
                "Excelのチャンク化開始",
                extra={"path": str(tmp_path), "max_rows": max_excel_rows_per_chunk},
            )
            # Excel ファイル専用のチャンク処理に渡す
            chunks = build_excel_chunks_from_file(
                tmp_path,
                max_rows=max_excel_rows_per_chunk,
                max_chars=max_chars,
                base_metadata=base_metadata,
            )
            logger.debug(
                "Excelのチャンク化完了",
                extra={"file_name": original_file_name, "chunk_count": len(chunks)},
            )
            return chunks

        # それ以外のドキュメント（PDF / Word / PPT / TXT）のチャンク化
        # Docling ベースのローダーで、ファイルを _NormalizedElement の列に正規化する
        elements = load_normalized_elements_from_file(tmp_path, suffix)
        logger.debug(
            "正規化済み要素の読み込みが完了",
            extra={
                "file_name": original_file_name,
                "suffix": suffix,
                "element_count": len(elements),
            },
        )
        if not elements:
            # 正規化結果が空であれば、それ以上チャンクを作ることはできない。
            logger.debug("正規化済み要素が空のため処理を終了", extra={"file_name": original_file_name})
            return []

        # ページ番号と `_order` メタデータを用いて、論理的な読み順にソートする。
        elements = _sorted_elements(elements)

        # 標準チャンクパイプラインでチャンクを生成する。
        chunks = build_standard_chunks(
            elements,
            max_chars=max_chars,
            min_chars=min_chars,
            overlap_chars=200,
            base_metadata=base_metadata,
        )
        logger.debug(
            "標準チャンク生成が完了",
            extra={"file_name": original_file_name, "chunk_count": len(chunks)},
        )
        return chunks


def _sorted_elements(elements: Sequence[_NormalizedElement]) -> list[_NormalizedElement]:
    """正規化済みエレメントを「ページ番号＋文書内順序」でソートする。

    `_NormalizedElement` には
    - `page`: 元ドキュメント内のページ番号
    - `metadata["_order"]`: Docling の走査順などに基づくドキュメント内順序
    が設定されていることを前提とし、「ページ番号 → _order」の優先順位で
    安定した並び順を構築する。

    これにより、変換や抽出の過程で多少順序が揺らいだ場合でも、
    元の読み順に近い形に再整列することを意図している。

    Args:
        elements (Sequence[_NormalizedElement]): ソート対象の `_NormalizedElement` のシーケンス。

    Returns:
        list[_NormalizedElement]: ページ番号と `_order` に基づいてソート済みのリスト。
    """

    def key(e: _NormalizedElement) -> tuple[int, int]:
        """ソート用のキー関数。

        Args:
            e (_NormalizedElement): ソート対象の `_NormalizedElement`。

        Returns:
            tuple[int, int]: (page, _order) のタプル。
        """
        # metadata を dict 化し、_order が無い場合は 0 として扱う。
        meta = dict(e.metadata or {})
        order = int(meta.get("_order", 0))
        return (e.page, order)

    # ページ → ドキュメント内順序 の優先度で昇順ソートする。
    return sorted(elements, key=key)


__all__ = ["build_hybrid_chunks_from_upload", "_ALLOWED_SUFFIXES"]
