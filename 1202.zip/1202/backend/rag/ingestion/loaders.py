"""Docling/TXT ローダーのシンプル版。

- doc/docx は LibreOffice で PDF 変換してから Docling
- pdf/pptx はそのまま Docling
- ppt は pptx へ変換してから Docling
- txt はそのまま読み込み

Docling で得られるテキストは picture を除きフィルタせず全て取り込む。
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Any

from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling_core.types.doc import DoclingDocument
from docling_core.types.doc.document import ContentLayer

from backend.foundation.logging import configure_logging
from backend.rag.ingestion.types import (
    DocumentParsingError,
    UnsupportedDocumentTypeError,
    _NormalizedElement,
)

logger = configure_logging(__name__)

_pdf_pipeline_options = PdfPipelineOptions()
_pdf_pipeline_options.do_table_structure = True

# ヘッダー/フッターを取り込むかどうか。
_INCLUDE_HEADERS_AND_FOOTERS = True

# ヘッダー/フッターと見なす Docling ラベル（正規化後）
_HEADER_FOOTER_LABELS = {
    "header",
    "footer",
    "page-header",
    "page-footer",
    "page_header",
    "page_footer",
}

_DOCLING_ARTIFACTS_PATH = os.getenv("DOCLING_ARTIFACTS_PATH")
if _DOCLING_ARTIFACTS_PATH:
    try:
        _pdf_pipeline_options.artifacts_path = _DOCLING_ARTIFACTS_PATH
    except Exception:
        logger.warning(
            "Docling の artifacts_path 設定が無効のためスキップ",
            extra={"path": _DOCLING_ARTIFACTS_PATH},
        )

_DOCLING_CONVERTER = DocumentConverter(
    format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=_pdf_pipeline_options)}
)


def load_normalized_elements_from_file(path: Path, suffix: str) -> list[_NormalizedElement]:
    """拡張子に応じて `_NormalizedElement` のリストへ変換する。"""
    try:
        if suffix in {".docx", ".doc"}:
            pdf_path = _convert_office_to_pdf(path, suffix)
            try:
                return _load_docling_elements(pdf_path)
            finally:
                pdf_path.unlink(missing_ok=True)

        if suffix == ".pdf":
            return _load_docling_elements(path)

        if suffix == ".pptx":
            return _load_docling_elements(path)

        if suffix == ".ppt":
            modern_path = _convert_legacy_office_to_modern(path, suffix)
            try:
                return _load_docling_elements(modern_path)
            finally:
                modern_path.unlink(missing_ok=True)

        if suffix == ".txt":
            return _load_txt_elements(path)

    except DocumentParsingError:
        raise
    except Exception as exc:
        logger.exception("ファイルの正規化処理に失敗", extra={"suffix": suffix, "path": str(path)})
        raise DocumentParsingError("ファイルの解析に失敗しました。内容を確認してください。") from exc

    raise UnsupportedDocumentTypeError(f"未対応のファイル形式です: {suffix}")


def _load_docling_elements(path: Path) -> list[_NormalizedElement]:
    """Docling で解析し、絞り込みせず要素を集める。"""
    try:
        result = _DOCLING_CONVERTER.convert(str(path))
        doc: DoclingDocument = result.document
    except Exception as exc:
        logger.exception("Docling による変換に失敗", extra={"path": str(path)})
        raise DocumentParsingError("ファイルの解析に失敗しました。内容を確認してください。") from exc

    elements: list[_NormalizedElement] = []
    order = 0

    # ContentLayer が利用できる場合は、ここで BODY/FURNITURE のどちらを含めるかを制御する。
    iterate_kwargs: dict[str, Any] = {}
    if ContentLayer is not None:
        if _INCLUDE_HEADERS_AND_FOOTERS:
            content_layers = {ContentLayer.BODY, ContentLayer.FURNITURE}
        else:
            content_layers = {ContentLayer.BODY}
        iterate_kwargs["included_content_layers"] = content_layers

    # 古い Docling で included_content_layers が無い場合にも落ちないようにフォールバック。
    try:
        iterator = doc.iterate_items(**iterate_kwargs)
    except TypeError:
        if iterate_kwargs:
            logger.warning(
                "Docling の iterate_items が included_content_layers を受け付けないため、"
                "デフォルトレイヤーでの走査にフォールバックします。",
            )
        iterator = doc.iterate_items()

    for node, _ in iterator:
        label_str = _normalize_docling_label(getattr(node, "label", None))

        # ヘッダー/フッター OFF 時は、ラベルでフィルタして除外
        if not _INCLUDE_HEADERS_AND_FOOTERS and label_str in _HEADER_FOOTER_LABELS:
            continue

        # 画像本体は除外（従来どおり）
        if label_str == "picture":
            continue

        text = _extract_docling_text(node, doc)
        if not text or not text.strip():
            continue

        page = _normalize_page_from_prov(getattr(node, "prov", []))
        elements.append(
            _NormalizedElement(
                type=label_str or "Text",
                text=text.strip(),
                page=page,
                metadata={"source": "docling", "label": label_str or None, "_order": order},
            )
        )
        order += 1

    logger.debug(
        "Docling 変換完了",
        extra={"path": str(path), "element_count": len(elements)},
    )
    return elements


def _extract_docling_text(node: Any, doc: DoclingDocument) -> str:
    label = _normalize_docling_label(getattr(node, "label", None))
    if label == "table":
        try:
            return node.export_to_markdown(doc=doc)
        except Exception:
            return getattr(node, "text", "") or ""
    return getattr(node, "text", "") or ""


def _normalize_docling_label(label: Any) -> str:
    if label is None:
        return ""
    for attr in ("value", "name"):
        v = getattr(label, attr, None)
        if isinstance(v, str):
            return v.lower()
    if isinstance(label, str):
        return label.lower()
    return str(label).lower()


def _normalize_page(page: Any | None) -> int:
    try:
        if page is None:
            return 1
        page_int = int(page)
        return max(page_int, 1)
    except (TypeError, ValueError):
        return 1


def _normalize_page_from_prov(prov: Any) -> int:
    if not prov:
        return 1
    first = prov[0]
    page = getattr(first, "page_no", None) or getattr(first, "page", None)
    return _normalize_page(page)


def _convert_office_to_pdf(path: Path, suffix: str) -> Path:
    if suffix not in {".doc", ".docx"}:
        raise ValueError(f"unsupported suffix for PDF conversion: {suffix}")

    outdir = path.parent
    cmd_candidates = [["soffice"], ["libreoffice"]]
    last_error: Exception | None = None

    env = os.environ.copy()
    env.setdefault("LANG", "ja_JP.UTF-8")
    env.setdefault("LC_CTYPE", "ja_JP.UTF-8")
    env.setdefault("LC_ALL", "ja_JP.UTF-8")

    profile_dir = os.getenv("LIBREOFFICE_USER_PROFILE_DIR")
    profile_arg: list[str] = []
    if profile_dir:
        try:
            profile_url = Path(profile_dir).resolve().as_uri()
            profile_arg = [f"-env:UserInstallation={profile_url}"]
        except Exception:
            logger.warning(
                "LIBREOFFICE_USER_PROFILE_DIR の指定が無効のため無視",
                extra={"profile_dir": profile_dir},
            )

    convert_to = 'pdf:writer_pdf_Export:{"SelectPdfVersion":{"type":"long","value":1}}'

    for base in cmd_candidates:
        cmd = base + profile_arg + [
            "--headless",
            "--invisible",
            "--nologo",
            "--norestore",
            "--nodefault",
            "--nolockcheck",
            "--nofirststartwizard",
            "--convert-to",
            convert_to,
            "--outdir",
            str(outdir),
            str(path),
        ]
        try:
            completed = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
                env=env,
                timeout=120,
            )
        except FileNotFoundError as exc:
            last_error = exc
            continue
        except subprocess.TimeoutExpired as exc:
            last_error = exc
            continue

        if completed.returncode != 0:
            last_error = RuntimeError(
                f"conversion failed: {' '.join(cmd)}; "
                f"stderr={completed.stderr.decode(errors='ignore')}"
            )
            continue

        candidate = path.with_suffix(".pdf")
        if candidate.exists():
            return candidate

        for p in outdir.glob("*.pdf"):
            if p.stem == path.stem:
                return p

        last_error = RuntimeError("converted PDF file not found after soffice call")

    msg = (
        "Word ファイル（.doc / .docx）の PDF 変換に失敗しました。"
        "サーバーに LibreOffice(soffice) / libreoffice がインストールされているか確認するか、"
        "あらかじめ PDF へ変換してからアップロードしてください。"
    )
    if last_error:
        logger.exception(
            "Word から PDF への変換に失敗",
            extra={"path": str(path)},
        )
    raise DocumentParsingError(msg)


def _convert_legacy_office_to_modern(path: Path, suffix: str) -> Path:
    if suffix == ".ppt":
        target_ext = ".pptx"
        convert_to_arg = "pptx"
    else:
        raise ValueError(f"unsupported legacy suffix for conversion: {suffix}")

    outdir = path.parent
    cmd_candidates = [["soffice"], ["libreoffice"]]
    last_error: Exception | None = None

    env = os.environ.copy()
    env.setdefault("LANG", "ja_JP.UTF-8")
    env.setdefault("LC_CTYPE", "ja_JP.UTF-8")

    for base in cmd_candidates:
        cmd = base + [
            "--headless",
            "--convert-to",
            convert_to_arg,
            "--outdir",
            str(outdir),
            str(path),
        ]
        try:
            completed = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
                env=env,
            )
        except FileNotFoundError as exc:
            last_error = exc
            continue

        if completed.returncode != 0:
            last_error = RuntimeError(
                f"conversion failed: {' '.join(cmd)}; "
                f"stderr={completed.stderr.decode(errors='ignore')}"
            )
            continue

        candidate = path.with_suffix(target_ext)
        if candidate.exists():
            return candidate

        for p in outdir.glob(f"*{target_ext}"):
            if p.stem == path.stem:
                return p

        last_error = RuntimeError("converted file not found after soffice call")

    msg = (
        "古い PowerPoint 形式ファイル（.ppt）の変換に失敗しました。"
        "サーバーに LibreOffice(soffice) / libreoffice がインストールされているか確認するか、"
        "あらかじめ .pptx へ変換してからアップロードしてください。"
    )
    if last_error:
        logger.exception(
            "旧形式 PowerPoint の変換に失敗",
            extra={"path": str(path)},
        )
    raise DocumentParsingError(msg)


def _load_txt_elements(path: Path) -> list[_NormalizedElement]:
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        content = path.read_text(encoding="utf-8", errors="ignore")

    content = content.strip()
    if not content:
        return []

    meta = {"source": "txt", "type": "Text", "_order": 0}
    return [
        _NormalizedElement(
            type="Text",
            text=content,
            page=1,
            metadata=meta,
        )
    ]


__all__ = ["load_normalized_elements_from_file"]
