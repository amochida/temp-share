"""ドキュメントインジェストで共通利用するデータクラスと例外クラス群。

このモジュールは、インジェスト処理全体で共有される「最小限の共通型」を定義する。

主な責務:
    - パースエラーを表現する共通の例外クラス
    - サポート外拡張子を表現する例外クラス
    - RAG インデックスに登録する 1 チャンク分のペイロード表現 (`ChunkPayload`)
    - Docling/TXT ローダーが出力する中間表現 (`_NormalizedElement`)

これらの型は、インジェストパイプラインの各ステージ（ロード・チャンク化・登録）の間を
つなぐ「共通インタフェース」として機能し、モジュール間の結合度を下げる役割を持つ。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


class DocumentParsingError(Exception):
    """アップロードファイルの解析（パース）に失敗したことを表す例外。

    Docling による PDF/Office 文書解析、LibreOffice を用いた変換処理、
    テキストファイルの読み込みなど、インジェストの前段で発生する
    各種パースエラーを一括して扱うための基底例外クラス。

    役割:
        - ユーザー向けには「ファイルの内容や形式に問題がある」ことを伝える。
        - 内部的には、Docling/LibreOffice/TXT の具体的な例外をラップし、
          呼び出し側が処理を共通化しやすいようにする。

    Note:
        この例外を継承したクラス（例: UnsupportedDocumentTypeError）も、
        インジェストパイプライン全体で同様に「パース関連の失敗」として扱われる。
    """


class UnsupportedDocumentTypeError(DocumentParsingError):
    """サポート対象外のファイル形式でインジェストが要求されたことを表す例外。

    アップロードされたファイルの拡張子が、インジェストパイプライン側で定めた
    許可リスト（例: .pdf, .docx, .pptx, .txt など）に含まれていない場合に用いる。

    役割:
        - ユーザーに対して「この拡張子は現時点では扱えない」ことを明示する。
        - 呼び出し側はこの例外をキャッチし、HTTP レスポンスなどで
          適切なエラーメッセージやステータスコード（400/415 等）を返す。

    Example:
        拡張子 .zip や .psd など、インジェストパイプラインが想定していない
        ファイルがアップロードされた際に raise される。
    """


@dataclass(frozen=True)
class ChunkPayload:
    """RAG インデックスに登録する 1 チャンク分のペイロード。

    チャンクとは:
        - 検索インデックスに登録される、ある程度まとまったテキストの単位。
        - 元ドキュメントの一部分（1 〜数段落、数行の表など）に対応する。

    本クラスは、インジェスト済みのチャンクを表現するための最小限の情報を持つ。

    Attributes:
        chunk_label (str | None):
            チャンクを代表するラベル（セクションタイトルなど）。
            無い場合は None。UI 側でリスト表示する際の見出し等に使える。
        content (str):
            実際に埋め込みや検索の対象となるテキスト本文。
        page_start (int):
            このチャンクがまたがるページ範囲の開始ページ番号。
            単一ページの場合は page_end と同じ値になる。
        page_end (int):
            このチャンクがまたがるページ範囲の終了ページ番号。
        metadata (dict[str, Any]):
            チャンクに紐づく任意のメタデータ。
            例:
                - 元ファイル名 (`file_name`)
                - 元拡張子 (`origin_suffix`)
                - 含まれる要素タイプ一覧 (`element_types`)
                - 各要素の text_preview やページ情報 (`elements`)
                - 推定トークン数 (`estimated_tokens`) など。
    """

    chunk_label: str | None
    content: str
    page_start: int
    page_end: int
    metadata: dict[str, Any]


@dataclass(frozen=True)
class _NormalizedElement:
    """チャンク化前の中間表現として扱うドキュメント要素。

    Docling/TXT ローダーが「元ファイル → 構造化された要素列」に変換した結果を表す。
    ここではファイル形式に依存しない共通の構造のみを持ち、
    チャンク化ロジック（段落分割・セクション分割など）の入力として利用される。

    役割:
        - 生の Docling ノードやテキスト行などを抽象化し、チャンク処理から
          Docling/TXT 依存の詳細を隠蔽する。
        - ページ番号や元ノードのラベル情報、順序情報などを `metadata` に含めることで、
          後続処理（ソート・メタ情報付加）に活用できるようにする。

    Attributes:
        type (str):
            要素の種別を表す文字列。
            例: "NarrativeText", "Title", "SectionHeader", "ListItem", "Table" など。
        text (str):
            この要素に対応するプレーンテキスト。
            チャンク化の際には、このテキストが段落分割や長さ制御の対象となる。
        page (int):
            元ドキュメントにおけるページ番号（1 始まりを想定）。
            ページ情報が取得できないフォーマットでは 1 などのフォールバック値が入る。
        metadata (Mapping[str, Any]):
            追加情報を保持する読み取り専用マッピング。
            例:
                - "source": ローダー種別（"docling", "txt" など）
                - "_order": ドキュメント内での出現順を表す整数
                - "label": Docling で付与されたラベル名 など。
    """

    type: str
    text: str
    page: int
    metadata: Mapping[str, Any]


# モジュール外へ公開するシンボル一覧。
# `_NormalizedElement` は内部用であるが、インジェストパイプライン内の他モジュールから
# 利用されるため、ここではあえてエクスポートしている。
__all__ = [
    "ChunkPayload",
    "DocumentParsingError",
    "UnsupportedDocumentTypeError",
    "_NormalizedElement",
]
