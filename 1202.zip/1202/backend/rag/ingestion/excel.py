"""Excel (.xls / .xlsx) 向けのチャンク生成ロジック。

Docling ベースの標準ルートとは別に、Excel ファイルは pandas で直接読み取り、
シート / 行単位のまとまりをテキスト化した上で `ChunkPayload` を構築する。

設計ポリシー:
    - `max_rows` と `max_chars` を両方考慮し、読みやすい大きさのチャンクを作る
    - Row 番号や Sheet 情報など、後段でトレースしやすいメタデータを付与する
    - pandas / openpyxl の例外は `DocumentParsingError` にラップして FastAPI に伝播させる
"""

from __future__ import annotations

from datetime import date, datetime
import math
from pathlib import Path
from typing import Any, Iterable, Sequence

import pandas as pd

from backend.foundation.logging import configure_logging
from backend.rag.ingestion.types import ChunkPayload, DocumentParsingError
from backend.rag.ingestion.utils import text_preview
from backend.rag.text import estimate_token_count

logger = configure_logging(__name__)

def build_excel_chunks_from_file(
    path: Path,
    *,
    max_rows: int,
    max_chars: int,
    base_metadata: Mapping[str, Any] | None = None,
) -> list[ChunkPayload]:
    """Excel ファイルを sheet × 行 のテキストとして取り出し、チャンク化する。

    ポリシー:
      - 1 行が横に長い場合でも 1 チャンクが肥大化し過ぎないよう、
        行数・文字数・推定トークン数をトリプルで制限。
      - 1 シート = 1 論理テーブルとして扱い、ヘッダー行を特別視しない。
        （header=None で全行をデータとして扱う）

    Args:
        path: Excel ファイルのパス。
        max_rows: 1 チャンクに含める最大行数。
        max_chars: 1 チャンクの最大文字数。
        base_metadata: 親から受け取ったベースメタデータ。

    Returns:
        ChunkPayload のリスト。シートごとに複数チャンクが生成される可能性がある。

    Raises:
        DocumentParsingError: pandas による Excel 読み込みが失敗した場合。
    """

    try:
        # sheet_name=None により全シートを dict[str, DataFrame] として取得
        sheets: dict[str, pd.DataFrame] = pd.read_excel(
            path,
            sheet_name=None,
            dtype=str,
            header=None,  # ★ 全行をデータとして扱う（ヘッダー行なし）
        )
    except Exception as exc:
        logger.exception(
            "Excelファイルの読み込みに失敗しました",
            extra={"event": "text_processing.excel_read_failed", "path": str(path)},
        )
        raise DocumentParsingError(
            "Excel ファイルの解析に失敗しました。"
            "必要なライブラリ（pandas / openpyxl / xlrd など）がインストールされているか確認してください。"
        ) from exc

    logger.debug(
        "Excelファイルを読み込みました",
        extra={"event": "text_processing.excel.loaded", "path": str(path), "sheet_count": len(sheets)},
    )

    chunks: list[ChunkPayload] = []
    base_meta = dict(base_metadata or {})

    # max_chars を基準に、ざっくり同程度の token 上限も設定
    max_tokens_per_chunk = max(max_chars, 1)

    # 各シートごとにチャンク化を行う
    for sheet_index, (sheet_name, df) in enumerate(sheets.items()):
        logger.debug(
            "Excelシートのチャンク化を開始",
            extra={
                "event": "text_processing.excel.sheet_start",
                "sheet_name": sheet_name,
                "sheet_index": sheet_index,
                "row_count": len(df),
            },
        )
        # シート番号を擬似ページとみなす (1 始まり)
        page = sheet_index + 1

        # 現在のチャンク候補ブロック
        # 要素: (row_index, text, row_tokens)
        current_block: list[tuple[int, str, int]] = []
        current_chars = 0
        current_tokens = 0

        def flush_block() -> None:
            """現在のブロックを 1 チャンクとして確定し、chunks に追加する内部ユーティリティ。"""
            nonlocal current_block, current_chars, current_tokens
            if not current_block:
                return

            row_start = current_block[0][0]
            row_end = current_block[-1][0]
            # 各行のテキストを改行で連結
            content_lines = [t for (_, t, _) in current_block]
            content = "\n".join(content_lines).strip()
            if not content:
                # 中身が空ならチャンク化せずブロックをリセット
                current_block = []
                current_chars = 0
                current_tokens = 0
                return

            # 各行（TableRow）ごとのメタ情報を構築
            elements_meta = [
                {
                    "type": "TableRow",
                    "page": page,
                    "char_len": len(t),
                    "estimated_tokens": tok,
                    "text_preview": text_preview(t),
                    "row_index": idx,
                }
                for (idx, t, tok) in current_block
            ]

            estimated_tokens = sum(tok for (_, _, tok) in current_block)

            # チャンクのメタデータを構築
            metadata = {
                **base_meta,
                "source": "excel",
                "sources": ["excel"],
                "primary_source": "excel",
                "sheet_name": sheet_name,
                "sheet_index": sheet_index,
                "row_start": row_start,
                "row_end": row_end,
                "section_title_raw": sheet_name,
                "pages": [page],
                "element_types": ["Table"],
                "elements": elements_meta,
                "estimated_tokens": estimated_tokens,
            }

            # ChunkPayload を生成してリストに追加
            chunks.append(
                ChunkPayload(
                    chunk_label=sheet_name or None,
                    content=content,
                    page_start=page,
                    page_end=page,
                    metadata=metadata,
                )
            )

            # ブロックをリセット
            current_block = []
            current_chars = 0
            current_tokens = 0

        # ---- DataFrame を行ごとに走査し、ブロックを組み立てる ----
        for row_idx, row in df.iterrows():
            # 行の各セルをテキスト化し、空セルや NaN を除外
            cells: list[str] = []
            for value in row.tolist():
                if value is None:
                    continue
                s = str(value).strip()
                if not s or s.lower() == "nan":
                    continue
                cells.append(s)

            # 完全に空行はスキップ（＝ブロックを分断はしない）
            if not cells:
                continue

            # セルを " | " 区切りで連結し 1 行のテキストとする
            row_text = " | ".join(cells)
            # Excel 上の行番号（1 始まり）
            row_index = int(row_idx) + 1
            # estimate_token_count: Sudachi ベースでトークン数を概算するヘルパー
            row_tokens = estimate_token_count(row_text)
            # 行の文字数 + 改行分を 1 文字として加算
            row_chars = len(row_text) + 1

            # 既にブロックに何か入っていて、次の行を追加すると制限を超える場合は一旦 flush
            if current_block:
                if (
                    len(current_block) >= max_rows
                    or current_chars + row_chars > max_chars
                    or current_tokens + row_tokens > max_tokens_per_chunk
                ):
                    # flush_block: 現在のブロックをチャンクとして確定し、リセットする
                    flush_block()

            # ブロックに現在行を追加
            current_block.append((row_index, row_text, row_tokens))
            current_chars += row_chars
            current_tokens += row_tokens

        # シート末尾で残っているブロックがあれば flush
        if current_block:
            flush_block()

    logger.debug(
        "Excelチャンク生成が完了",
        extra={"event": "text_processing.excel.chunks_completed", "path": str(path), "chunk_count": len(chunks)},
    )
    return chunks

__all__ = ["build_excel_chunks_from_file"]
