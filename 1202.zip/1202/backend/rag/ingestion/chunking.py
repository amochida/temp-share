"""シンプルな文ベースのチャンク生成。

Docling/TXT から得た `_NormalizedElement` を文単位に分割し、
min/max 文字数とオーバーラップを満たす形でチャンクに束ねる。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from backend.foundation.logging import configure_logging
from backend.rag.ingestion.types import ChunkPayload, _NormalizedElement
from backend.rag.ingestion.utils import text_preview
from backend.rag.text import estimate_token_count

logger = configure_logging(__name__)


@dataclass(frozen=True)
class _Sentence:
    text: str
    page: int
    source: str | None


def build_standard_chunks(
    elements: Sequence[_NormalizedElement],
    *,
    max_chars: int,
    min_chars: int,
    overlap_chars: int = 200,
    base_metadata: Mapping[str, Any] | None = None,
) -> list[ChunkPayload]:
    """文リストを min/max/overlap に合わせて束ねる。"""
    sentences = _elements_to_sentences(elements, max_chars=max_chars, overlap_chars=overlap_chars)
    if not sentences:
        return []

    chunks: list[ChunkPayload] = []
    start = 0
    n = len(sentences)

    while start < n:
        end = start
        while end < n and _span_length(sentences, start, end + 1) <= max_chars:
            end += 1

        if end == start:
            end = start + 1

        while end < n and _span_length(sentences, start, end) < min_chars:
            if _span_length(sentences, start, end + 1) > max_chars:
                break
            end += 1

        chunk_sentences = sentences[start:end]
        chunks.append(_build_chunk(chunk_sentences, base_metadata=base_metadata))

        if end >= n:
            break

        desired_overlap = min(overlap_chars, _span_length(sentences, start, end))
        new_start = end
        running = 0
        for idx in range(end - 1, start - 1, -1):
            running += len(sentences[idx].text)
            if idx != end - 1:
                running += 1  # 改行分
            if running >= desired_overlap:
                new_start = idx
                break

        if new_start <= start:
            new_start = start + 1

        start = new_start

    logger.debug(
        "チャンク生成完了",
        extra={"chunk_count": len(chunks), "sentence_count": len(sentences)},
    )
    return chunks


def _elements_to_sentences(
    elements: Sequence[_NormalizedElement],
    *,
    max_chars: int,
    overlap_chars: int,
) -> list[_Sentence]:
    sentences: list[_Sentence] = []
    for elem in elements:
        text = (elem.text or "").strip()
        if not text:
            continue
        page = elem.page or 1
        source = None
        if isinstance(elem.metadata, Mapping):
            src = elem.metadata.get("source")
            source = str(src) if src is not None else None

        for sent in _split_sentences(text):
            parts = _split_long_text(sent, max_chars=max_chars, overlap_chars=overlap_chars)
            for part in parts:
                part = part.strip()
                if not part:
                    continue
                sentences.append(_Sentence(text=part, page=page, source=source))
    return sentences


def _split_sentences(text: str) -> list[str]:
    text = text.replace("\r\n", "\n")
    sentences: list[str] = []
    buf = ""
    break_chars = {"。", "．", ".", "\n"}

    for ch in text:
        buf += ch
        if ch in break_chars:
            if buf.strip():
                sentences.append(buf.strip())
            buf = ""

    if buf.strip():
        sentences.append(buf.strip())

    return sentences


def _split_long_text(text: str, *, max_chars: int, overlap_chars: int) -> list[str]:
    """1 文が長すぎる場合に、句読点・改行優先で分割する。"""
    if len(text) <= max_chars:
        return [text]

    parts: list[str] = []
    start = 0
    n = len(text)
    break_chars = "。．.\n"

    while start < n:
        tentative_end = min(start + max_chars, n)
        split = tentative_end

        if tentative_end < n:
            window_start = max(start, tentative_end - max_chars // 2)
            for i in range(tentative_end, window_start, -1):
                if text[i - 1] in break_chars:
                    split = i
                    break

        part = text[start:split].strip()
        if part:
            parts.append(part)

        if split >= n:
            break

        start = max(split - overlap_chars, start + 1)

    if not parts:
        return [text[:max_chars]]
    return parts


def _span_length(sentences: Sequence[_Sentence], start: int, end: int) -> int:
    if end <= start:
        return 0
    body = sum(len(s.text) for s in sentences[start:end])
    return body + max(0, end - start - 1)  # 改行ぶん


def _build_chunk(
    sentences: Sequence[_Sentence],
    *,
    base_metadata: Mapping[str, Any] | None,
) -> ChunkPayload:
    assert sentences, "chunk must contain at least one sentence"

    pages = {s.page or 1 for s in sentences}
    sources = {s.source for s in sentences if s.source}

    content = "\n".join(s.text for s in sentences).strip()
    label = _make_chunk_label(sentences[0].text, limit=60)

    elements_meta: list[dict[str, Any]] = []
    token_total = 0
    for s in sentences:
        tokens = estimate_token_count(s.text)
        token_total += tokens
        elements_meta.append(
            {
                "type": "Text",
                "page": s.page or 1,
                "char_len": len(s.text),
                "estimated_tokens": tokens,
                "text_preview": text_preview(s.text),
                "source": s.source,
            }
        )

    base_meta = dict(base_metadata or {})
    if sources:
        sources_sorted = sorted(sources)
        base_meta["sources"] = sources_sorted
        base_meta["primary_source"] = sources_sorted[0]

    metadata: dict[str, Any] = {
        **base_meta,
        "section_title_raw": label,
        "element_types": ["Text"],
        "pages": sorted(pages),
        "elements": elements_meta,
        "estimated_tokens": token_total,
    }

    page_start = min(pages) if pages else 1
    page_end = max(pages) if pages else 1

    return ChunkPayload(
        chunk_label=label,
        content=content,
        page_start=page_start,
        page_end=page_end,
        metadata=metadata,
    )


def _make_chunk_label(text: str, *, limit: int) -> str | None:
    label = text.replace("\n", " ").strip()
    if not label:
        return None
    if len(label) <= limit:
        return label
    return label[:limit]


__all__ = ["build_standard_chunks"]
