"""Small helpers shared across ingestion modules."""

from __future__ import annotations

_TEXT_PREVIEW_LENGTH = 80


def text_preview(text: str) -> str:
    """Return the first `_TEXT_PREVIEW_LENGTH` characters for metadata previews."""

    return text[:_TEXT_PREVIEW_LENGTH]


__all__ = ["text_preview"]

