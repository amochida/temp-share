"""Retriever・Reranker・Generator を束ねる RAG オーケストレーター。

このモジュールは RAG パイプライン全体の「司令塔」として、次の順番で処理を行う:

    1. retrieval_mode 判定（LLM）:
       会話履歴と最新質問から、docs / faqs のどちらを優先して検索すべきかを決定。

    2. Retriever（PgHybridRetriever）:
       PostgreSQL + pgvector + tsvector によるハイブリッド検索で候補 Document を取得。

    3. Reranker（CrossEncoder）:
       Retriever の候補を CrossEncoder によって再スコアリングし、より関連性の高い順に並び替え。

    4. Generator（rag_chain / LangChain Runnable）:
       取得済み Document・履歴・最新質問をもとに、LLM で最終回答を生成。

    5. 引用情報・メタ情報の構築:
       UI 表示用の ChatCitation リストや、RAG の挙動を記録する OrchestratorConfig を作成。

上記の一連の流れを `run_rag_pipeline` 1 つで隠蔽することで、
呼び出し側は「質問と履歴とフィルタを渡すと、回答と引用と構成情報が返ってくる」
というシンプルなインターフェイスで RAG を利用できる。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import time
from typing import Any, Mapping, Optional, Sequence
from urllib.parse import urlparse, urlunparse

from langchain_core.documents import Document

from backend.api.chat.schema import ChatCitation
from backend.api.search.schema import DocumentSearchFilters, FAQSearchFilters
from backend.foundation.logging import configure_logging
from backend.foundation.settings import settings
from backend.rag.config import rag_tuning
from backend.rag.prompts import DEFAULT_PROMPT_KEY
from backend.rag.rag_chain import run_rag_chain
from backend.rag.reranker import rerank_documents
from backend.rag.retrieval_mode import DEFAULT_MODE, RetrievalMode, infer_retrieval_mode
from backend.rag.retriever import PgHybridRetriever
from backend.rag.query_rewriter import rewrite_query_with_history
from backend.foundation.llm_client import LLMError

logger = configure_logging(__name__)

# 根拠となる Document が 1 件も取得できなかった場合の固定メッセージ
NO_EVIDENCE_MESSAGE = (
    "## 回答不可\n\n社内検索で根拠となる情報を取得できなかったため、回答できません。"
)


@dataclass(slots=True)
class OrchestratorConfig:
    """RAG 実行時のモードやソース情報をレスポンス用にまとめる構造体。

    RAG の動作モードや検索ソースの配分などをまとめて返すことで、
    UI 側やロギング側が「今回の回答がどのような条件で生成されたか」を把握しやすくする。

    Attributes:
        retrieval_mode (RetrievalMode):
            docs/faqs のどちらを優先したかを示すモード。
        sources (list[str]):
            実際に回答へ寄与した origin（例: "documents", "faqs"）の出現順リスト。
        weight_map (dict[str, float]):
            documents/faqs 間の重み配分（合計 1.0）。UI での可視化などに利用できる。
    """

    retrieval_mode: RetrievalMode
    sources: list[str]
    weight_map: dict[str, float]


@dataclass(slots=True)
class CitationAccumulator:
    """単一ドキュメントの引用情報をページ番号と共に保持する。"""

    citation: ChatCitation
    pages: set[int]


def _dump_filters(filters: DocumentSearchFilters | FAQSearchFilters | None) -> dict[str, Any] | None:
    """Pydantic モデルのフィルタをロギング用 dict に整形する。"""

    if filters is None:
        return None
    try:
        return filters.model_dump(exclude_none=True)
    except AttributeError:
        return None


async def run_rag_pipeline(
    *,
    query: str,
    history_text: str,
    answer_mode: Optional[str],
    doc_filters: Optional[DocumentSearchFilters],
    faq_filters: Optional[FAQSearchFilters],
) -> tuple[str, list[ChatCitation], str, OrchestratorConfig]:
    """Retriever→Reranker→LLM の順で RAG パイプラインを実行する。

    RAG の全ステップを 1 つの関数としてまとめたエントリーポイント。
    呼び出し側は質問・履歴・フィルタ条件を渡すだけで、最終回答と引用情報、
    および実行に利用した構成情報をまとめて受け取ることができる。

    処理の大まかな流れ:
        1. retrieval_mode 判定（または answer_mode による強制）
        2. docs/faqs の取得件数上限を決定
        3. 検索に使う semantic_queries（クエリ群）の構築
        4. PgHybridRetriever によるハイブリッド検索
        5. CrossEncoder による再ランキング
        6. LangChain Runnable (rag_chain) による回答生成
        7. 引用情報 / OrchestratorConfig の構築

    Args:
        query (str):
            最新のユーザー質問。
        history_text (str):
            LLM プロンプトに埋め込む履歴文字列（すでに整形済み）。
        answer_mode (Optional[str]):
            UI 側で強制された検索モード。 `"documents"` の場合は docs_only に固定。
        doc_filters (Optional[DocumentSearchFilters]):
            ドキュメント検索時のメタデータフィルタ。
        faq_filters (Optional[FAQSearchFilters]):
            FAQ 検索時のメタデータフィルタ。

    Returns:
        tuple[str, list[ChatCitation], str, OrchestratorConfig]:
            - 回答本文 (`answer_text`)
            - 引用リスト (`citations`)
            - 使用したプロンプトキー (`prompt_key`)
            - 実行時構成 (`OrchestratorConfig`)
    """
    pipeline_start = time.monotonic()
    rag = settings.rag
    logger.debug(
        "RAGオーケストレーター処理を開始",
        extra={
            "question": query,
            "history": history_text,
            "answer_mode": answer_mode,
            "doc_filters": _dump_filters(doc_filters),
            "faq_filters": _dump_filters(faq_filters),
        },
    )

    # 1. retrieval_mode の決定
    # answer_mode="documents" の場合は docs_only を強制し、それ以外は LLM に推論させる。
    if answer_mode == "documents":
        retrieval_mode: RetrievalMode = "docs_only"
        logger.debug(
            "UI 指示により検索モードを強制適用",
            extra={"answer_mode": answer_mode, "retrieval_mode": retrieval_mode},
        )
    else:
        try:
            mode_start = time.monotonic()
            retrieval_mode = await infer_retrieval_mode(history_text, query)
            mode_latency_ms = int((time.monotonic() - mode_start) * 1000)
            logger.debug(
                "LLM 推論による検索モードを決定",
                extra={"retrieval_mode": retrieval_mode},
            )
            logger.info(
                "検索モードの推論が完了",
                extra={
                    "event": "retrieval_mode.inference.complete",
                    "latency_ms": mode_latency_ms,
                    "retrieval_mode": retrieval_mode,
                },
            )
        except Exception as exc:  # pragma: no cover - 想定外エラー時の安全なフォールバック
            logger.warning(
                "検索モード判定に失敗したためデフォルトを使用します",
                extra={"error": str(exc), "fallback_mode": DEFAULT_MODE},
            )
            retrieval_mode = DEFAULT_MODE

    # 2. docs / faqs の取得上限件数をモードに応じて決定
    doc_limit, faq_limit = _determine_candidate_limits(retrieval_mode)

    # 3. 検索に利用するクエリ群（semantic_queries）を構築
    retrieval_queries, file_name_hints = await _build_retrieval_queries(history_text, query)
    reranker_query = (retrieval_queries[-1] if retrieval_queries else query) or query
    logger.info(
        "検索モード決定",
        extra={"retrieval_mode": retrieval_mode, "doc_limit": doc_limit, "faq_limit": faq_limit},
    )
    logger.debug(
        "検索クエリ構成を記録",
        extra={
            "retrieval_mode": retrieval_mode,
            "queries": retrieval_queries,
            "doc_limit": doc_limit,
            "faq_limit": faq_limit,
            "file_name_hints": file_name_hints,
        },
    )

    # 4. Retriever（PgHybridRetriever）の準備と実行
    retriever = PgHybridRetriever(
        doc_filters=doc_filters if doc_limit else None,
        faq_filters=faq_filters if faq_limit else None,
        doc_limit=doc_limit,
        faq_limit=faq_limit,
        keyword_weight=rag_tuning.hybrid_keyword_weight,
        vector_weight=rag_tuning.hybrid_vector_weight,
        semantic_queries=retrieval_queries,
        file_name_hints=file_name_hints,
    )
    logger.debug(
        "PgHybridRetriever の設定詳細",
        extra={
            "doc_limit": doc_limit,
            "faq_limit": faq_limit,
            "keyword_weight": rag_tuning.hybrid_keyword_weight,
            "vector_weight": rag_tuning.hybrid_vector_weight,
            "semantic_query_count": len(retrieval_queries),
        },
    )

    documents = await retriever.aget_relevant_documents(query)
    logger.debug(
        "ハイブリッド検索完了",
        extra={
            "result_count": len(documents),
            "sample_documents": _describe_documents(documents),
        },
    )

    # 5. Reranker（CrossEncoder）による再ランキング
    if rag.use_reranker:
        rerank_start = time.monotonic()
        reranked_docs = await rerank_documents(
            query=reranker_query,
            documents=documents,
            top_k=rag_tuning.rerank_top_k,
        )
        rerank_latency_ms = int((time.monotonic() - rerank_start) * 1000)
        logger.debug(
            "リランカー適用",
            extra={
                "selected_count": len(reranked_docs),
                "sample_documents": _describe_documents(reranked_docs),
            },
        )
        logger.info(
            "リランカー処理が完了",
            extra={
                "event": "reranker.complete",
                "latency_ms": rerank_latency_ms,
                "input_count": len(documents),
                "output_count": len(reranked_docs),
                "top_k": rag_tuning.rerank_top_k,
            },
        )
    else:
        limit = rag_tuning.rerank_top_k if rag_tuning.rerank_top_k > 0 else len(documents)
        reranked_docs = documents[:limit]
        logger.info(
            "リランカー無効化中のためスキップ",
            extra={"doc_count": len(documents), "reranked_count": len(reranked_docs)},
        )

    # 根拠文書が 1 件も残らなかった場合は「回答不可」を返す
    if not reranked_docs:
        config = OrchestratorConfig(
            retrieval_mode=retrieval_mode,
            sources=[],
            weight_map=_build_weight_map(retrieval_mode),
        )
        logger.warning(
            "根拠文書が取得できなかったため回答不可メッセージを返します",
            extra={"retrieval_mode": retrieval_mode, "query_count": len(retrieval_queries)},
        )
        logger.debug(
            "根拠文書が無いため回答不可を返却",
            extra={
                "retrieval_mode": retrieval_mode,
                "queries": retrieval_queries,
            },
        )
        return NO_EVIDENCE_MESSAGE, [], DEFAULT_PROMPT_KEY, config

    # 6. 回答生成用プロンプトの選択と LLM 呼び出し
    prompt_key = _select_prompt_key(retrieval_mode)
    prompt_documents = reranked_docs[: rag_tuning.prompt_document_limit]
    logger.debug(
        "回答生成に使用する文書一覧",
        extra={
            "prompt_key": prompt_key,
            "document_count": len(prompt_documents),
            "document_ids": [doc.metadata.get("document_id") for doc in prompt_documents],
            "origins": [doc.metadata.get("origin") for doc in prompt_documents],
        },
    )
    # LLM から回答本文＋参照した ID を受け取る
    answer_text, cited_document_ids, cited_faq_ids = await run_rag_chain(
        prompt_key=prompt_key,
        documents=prompt_documents,
        history=history_text,
        question=query,
    )
    logger.debug(
        "LLM応答取得",
        extra={
            "prompt_key": prompt_key,
            "prompt_document_count": len(prompt_documents),
            "cited_document_ids": cited_document_ids,
            "cited_faq_ids": cited_faq_ids,
        },
    )

    # 7. 引用情報・構成情報の構築
    # LLM が返した ID を元に、出典を絞り込み＆優先度順に並び替え
    citations = _build_citations_from_documents(
        prompt_documents,
        selected_document_ids=cited_document_ids,
        selected_faq_ids=cited_faq_ids,
    )

    config = OrchestratorConfig(
        retrieval_mode=retrieval_mode,
        sources=_summarize_sources(prompt_documents),
        weight_map=_build_weight_map(retrieval_mode),
    )

    logger.info(
        "回答整形完了",
        extra={
            "prompt_key": prompt_key,
            "citation_count": len(citations),
            "sources": config.sources,
        },
    )
    pipeline_latency_ms = int((time.monotonic() - pipeline_start) * 1000)
    logger.info(
        "RAGパイプラインが完了",
        extra={
            "event": "rag.pipeline.complete",
            "latency_ms": pipeline_latency_ms,
            "retrieval_mode": retrieval_mode,
            "doc_candidates": len(documents),
            "reranked_docs": len(reranked_docs),
            "prompt_docs": len(prompt_documents),
            "sources": config.sources,
        },
    )
    return answer_text, citations, prompt_key, config


def _describe_documents(documents: Sequence[Document], limit: int = 3) -> str:
    """ログ向けに Document の概要を整形する。"""

    snippets: list[str] = []
    for doc in documents[:limit]:
        title = doc.metadata.get("title") or doc.metadata.get("question") or "(タイトル不明)"
        origin = doc.metadata.get("origin") or "documents"
        snippets.append(f"[{origin}] {title}")
    return "; ".join(snippets) or "(該当なし)"


def _determine_candidate_limits(mode: RetrievalMode) -> tuple[int, int]:
    """Retrieval モードに応じて文書／FAQ の取得上限を決定する。

    docs_only / faqs_only 以外の場合は ``rag_tuning`` で定義したデフォルト値を使い、
    docs_only / faqs_only の場合は片側の件数を 0 に設定する。

    Args:
        mode (RetrievalMode):
            LLM が判定した検索モード。

    Returns:
        tuple[int, int]:
            `(doc_limit, faq_limit)` の順で返す。負の値は 0 に丸める。
    """
    doc_limit = rag_tuning.doc_candidate_limit
    faq_limit = rag_tuning.faq_candidate_limit

    if mode == "docs_only":
        faq_limit = 0
    elif mode == "faqs_only":
        doc_limit = 0

    return max(doc_limit, 0), max(faq_limit, 0)


def _build_weight_map(mode: RetrievalMode) -> dict[str, float]:
    """Retrieval モードに応じてソース配分の重みマップを返す。

    この重みは UI 表示やログ分析などで、
    「今回の回答は documents / faqs のどちらをどれくらい重視したか」
    を示すために利用できる。

    Args:
        mode (RetrievalMode):
            docs/faqs のどちらを重視するかを示すモード。

    Returns:
        dict[str, float]:
            `"documents"` / `"faqs"` をキーに持つ重み辞書（合計 1.0）。
    """
    if mode == "docs_only":
        base = {"documents": 1.0, "faqs": 0.0}
    elif mode == "faqs_only":
        base = {"documents": 0.0, "faqs": 1.0}
    elif mode == "docs_priority":
        base = {"documents": 0.7, "faqs": 0.3}
    elif mode == "faqs_priority":
        base = {"documents": 0.3, "faqs": 0.7}
    else:
        base = {"documents": 0.5, "faqs": 0.5}

    total = base["documents"] + base["faqs"] or 1.0
    return {key: value / total for key, value in base.items()}


def _select_prompt_key(mode: RetrievalMode) -> str:
    """Retrieval モードに応じて回答生成用プロンプトキーを選択する。

    docs を重視するモードの場合はポリシー重視のテンプレートを、
    faqs を重視するモードの場合は QA 一般向けテンプレートを選ぶ。

    Args:
        mode (RetrievalMode):
            documents/faqs のどちらを重視するかを表すモード。

    Returns:
        str:
            :mod:`backend.rag.prompts` に登録されたプロンプトキー。
    """
    if mode in {"docs_only", "docs_priority"}:
        return "policy_strict"
    if mode in {"faqs_only", "faqs_priority"}:
        return "qa_general"
    return DEFAULT_PROMPT_KEY


def _build_citations_from_documents(
    documents: Sequence[Document],
    *,
    selected_document_ids: Optional[Sequence[str]] = None,
    selected_faq_ids: Optional[Sequence[str]] = None,
) -> list[ChatCitation]:
    """LangChain Document から UI 表示用の引用情報を生成する。

    最終プロンプトへ埋め込んだ Document 配列をもとに、document_id / faq_id ごとに
    重複を取り除いた ChatCitation 配列を構築する。

    selected_document_ids / selected_faq_ids に値が渡された場合は、
    それらの ID を持つものだけに絞り込み、指定順に並べ替える。
    一致するものが 1 つも無い場合は、従来どおり documents の出現順を利用する。
    """

    doc_accumulator: dict[str, CitationAccumulator] = {}
    faq_accumulator: dict[str, ChatCitation] = {}
    document_order: list[str] = []
    faq_order: list[str] = []

    # selection を文字列 ID のリストとして揃えておく
    selected_document_ids_list: list[str] | None = None
    if selected_document_ids:
        selected_document_ids_list = [str(doc_id) for doc_id in selected_document_ids if doc_id]

    selected_faq_ids_list: list[str] | None = None
    if selected_faq_ids:
        selected_faq_ids_list = [str(faq_id) for faq_id in selected_faq_ids if faq_id]

    for doc in documents:
        origin = (doc.metadata.get("origin") or "documents").lower()
        citation = ChatCitation(
            document_id=doc.metadata.get("document_id"),
            chunk_id=doc.metadata.get("chunk_id"),
            faq_id=doc.metadata.get("faq_id"),
            title=doc.metadata.get("title") or doc.metadata.get("question"),
            score=doc.metadata.get("score"),
            snippet=doc.page_content,
            source=origin,
            source_uri=doc.metadata.get("source_uri"),
        )

        # FAQ ソース
        if origin == "faqs":
            raw_faq_id = doc.metadata.get("faq_id")
            if raw_faq_id is None:
                continue
            faq_id = str(raw_faq_id)
            if faq_id not in faq_accumulator:
                faq_accumulator[faq_id] = citation
                faq_order.append(faq_id)
            continue

        # ドキュメントソース
        raw_document_id = doc.metadata.get("document_id")
        if raw_document_id is None:
            continue
        document_id = str(raw_document_id)
        pages_to_add = _extract_page_numbers(doc.metadata)
        entry = doc_accumulator.get(document_id)
        if entry is None:
            doc_accumulator[document_id] = CitationAccumulator(
                citation=citation,
                pages=set(pages_to_add),
            )
            document_order.append(document_id)
        else:
            entry.pages.update(pages_to_add)

    # ドキュメント側の並び順（選択があれば優先）
    doc_id_order: list[str] = []
    if selected_document_ids_list:
        doc_id_order = [doc_id for doc_id in selected_document_ids_list if doc_id in doc_accumulator]
    if not doc_id_order:
        # LLM が ID を返さなかった／一致しなかった場合は従来どおり
        doc_id_order = document_order

    doc_items: list[ChatCitation] = []
    for document_id in doc_id_order:
        entry = doc_accumulator.get(document_id)
        if entry is None:
            continue
        citation = entry.citation
        pages = sorted(entry.pages)
        if pages:
            citation.title = _format_title_with_pages(citation.title, pages)
            citation.source_uri = _append_page_to_uri(citation.source_uri, pages[0])
        doc_items.append(citation)
        if len(doc_items) >= rag_tuning.doc_citation_limit:
            break

    # FAQ 側の並び順（選択があれば優先）
    faq_id_order: list[str] = []
    if selected_faq_ids_list:
        faq_id_order = [faq_id for faq_id in selected_faq_ids_list if faq_id in faq_accumulator]
    if not faq_id_order:
        faq_id_order = faq_order

    faq_items: list[ChatCitation] = []
    for faq_id in faq_id_order:
        citation = faq_accumulator.get(faq_id)
        if citation is None:
            continue
        faq_items.append(citation)
        if len(faq_items) >= rag_tuning.faq_citation_limit:
            break

    return doc_items[: rag_tuning.doc_citation_limit] + faq_items[: rag_tuning.faq_citation_limit]



def _normalize_page(value: object) -> int:
    """メタデータから受け取ったページ番号を 1 以上の整数に正規化する。"""

    try:
        page = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 1
    return page if page > 0 else 1


def _extract_page_numbers(metadata: Mapping[str, Any]) -> set[int]:
    """チャンクセマンティクスからページ範囲を抽出する。"""

    if not metadata:
        return {1}
    pages: set[int] = set()
    chunk_meta = metadata.get("chunk_metadata")
    if isinstance(chunk_meta, Mapping):
        raw_pages = chunk_meta.get("pages")
        if isinstance(raw_pages, Sequence):
            for value in raw_pages:
                try:
                    page = int(value)  # type: ignore[arg-type]
                except (TypeError, ValueError):
                    continue
                if page > 0:
                    pages.add(page)
    if pages:
        return pages
    start = metadata.get("page_start")
    end = metadata.get("page_end")
    if start is None and end is None:
        return {_normalize_page(metadata.get("page"))}
    page_start = _normalize_page(start)
    page_end = _normalize_page(end if end is not None else start)
    if page_end < page_start:
        page_end = page_start
    return {page for page in range(page_start, page_end + 1)}


def _format_title_with_pages(title: Optional[str], pages: Sequence[int]) -> Optional[str]:
    if not title or not pages:
        return title
    unique_pages = sorted(set(pages))
    page_text = ",".join(str(page) for page in unique_pages)
    return f"{title} (p.{page_text})"


def _append_page_to_uri(uri: Optional[str], page: int) -> Optional[str]:
    if not uri or page <= 0:
        return uri

    parsed = urlparse(uri)
    suffix = Path(parsed.path or "").suffix.lower()
    if suffix != ".pdf":  # 現状は PDF のみページアンカーに対応
        return uri

    page_fragment = f"page={page}"
    fragment = parsed.fragment
    if fragment:
        parts = fragment.split("&")
        if page_fragment not in parts:
            fragment = f"{fragment}&{page_fragment}"
    else:
        fragment = page_fragment

    return urlunparse(parsed._replace(fragment=fragment))


def _summarize_sources(documents: Sequence[Document]) -> list[str]:
    """引用済み Document 群から出典ソースの出現順リストを作成する。

    どの origin（"documents" / "faqs" など）が今回の回答に使われたかを、
    先に現れた順番でリスト化する。

    Args:
        documents (Sequence[Document]):
            rerank 後の Document 配列。

    Returns:
        list[str]:
            origin の値（例: "documents", "faqs"）を重複なく、出現順で並べたリスト。
    """
    seen: set[str] = set()
    ordered: list[str] = []

    for doc in documents:
        origin = str(doc.metadata.get("origin") or "documents")
        if origin not in seen:
            seen.add(origin)
            ordered.append(origin)

    return ordered


async def _build_retrieval_queries(history_text: str, question: str) -> tuple[list[str], list[str]]:
    """最新質問と履歴をもとに検索クエリ候補とファイル名ヒントを生成する。"""

    queries: list[str] = []
    cleaned_question = question.strip()
    if cleaned_question:
        queries.append(cleaned_question)

    contextual, file_name_hints, allow_duplicate = await _build_contextual_query(
        history_text,
        cleaned_question,
    )
    if contextual and (allow_duplicate or contextual not in queries):
        queries.append(contextual)

    if queries:
        return queries, file_name_hints
    return [cleaned_question], file_name_hints


async def _build_contextual_query(
    history_text: str, question: str
) -> tuple[str | None, list[str], bool]:
    """履歴を踏まえた補助クエリとファイル名ヒントを生成する。"""

    if not history_text.strip() or not question:
        return None, [], False

    recent_lines = [line.strip() for line in history_text.split("\n") if line.strip()]
    if not recent_lines:
        return None, [], False

    limited_lines = recent_lines[-rag_tuning.query_rewrite_history_turns :]
    limited_lines = _trim_lines_to_char_limit(
        limited_lines,
        rag_tuning.query_rewrite_char_limit,
    )
    if not limited_lines:
        return None, [], False

    context_for_prompt = "\n".join(limited_lines)
    recent_snippet = " ".join(limited_lines)
    if not recent_snippet:
        return None, [], False

    fallback = f"{recent_snippet} {question}".strip()
    if settings.rag.use_query_rewriter:
        try:
            rewritten = await rewrite_query_with_history(context_for_prompt, question)
            if rewritten:
                query_text = (rewritten.get("query_text") or "").strip()
                hints = [
                    hint.strip()
                    for hint in rewritten.get("file_name_hints", [])
                    if isinstance(hint, str) and hint.strip()
                ]
                if query_text:
                    return query_text, hints, False
                if question:
                    return question, hints, True
        except (LLMError, Exception) as exc:  # noqa: BLE001
            logger.warning(
                "クエリのリライトに失敗したため連結結果を使用します",
                extra={"error": str(exc)},
            )

    if fallback and fallback != question:
        logger.debug(
            "履歴を連結したクエリを使用",
            extra={"query": fallback},
        )
        return fallback, [], False
    return None, [], False


def _trim_lines_to_char_limit(lines: Sequence[str], char_limit: int) -> list[str]:
    """指定した行配列を文字数上限に収まるよう古い方から削る。"""

    trimmed = [line for line in lines if line]
    if char_limit <= 0:
        return trimmed

    while trimmed and len("\n".join(trimmed)) > char_limit:
        trimmed = trimmed[1:]
    return trimmed


__all__ = ["run_rag_pipeline", "OrchestratorConfig", "NO_EVIDENCE_MESSAGE"]
