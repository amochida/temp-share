"""PostgreSQL ベースのハイブリッド検索を行うカスタム Retriever。

RAG パイプラインにおける「検索担当」として、以下を一括で行う:

    * documents テーブルと faqs テーブルの横断検索
    * pgvector によるベクトル類似度検索
    * tsvector による全文検索（キーワードマッチ）
    * keyword / vector スコアの重み付け（HybridWeights）
    * Doc/FAQ の生辞書結果を LangChain Document 配列に変換

LangChain の BaseRetriever を継承してはいないが、
メソッド名として `aget_relevant_documents` / `get_relevant_documents` を提供し、
LangChain Retriever 互換のインターフェイスを部分的に持つ。

実際の検索ロジックはすべて `backend.rag.rag_search` に委譲され、
このクラスは「検索条件の組み立て」と「結果の Document 変換」を担う。
"""

from __future__ import annotations

from typing import Any, Sequence
import time

from langchain_core.documents import Document

from backend.foundation.logging import configure_logging
from backend.rag import rag_search
from backend.rag.rag_search import DocumentSearchFilters, FAQSearchFilters, HybridWeights

logger = configure_logging(__name__)


def _serialize_filters(filters: DocumentSearchFilters | FAQSearchFilters | None) -> dict[str, Any] | None:
    """Pydantic モデルをロギングしやすい dict に変換する。"""

    if filters is None:
        return None
    try:
        return filters.model_dump(exclude_none=True)
    except AttributeError:
        return None


class PgHybridRetriever:
    """PostgreSQL のドキュメント／FAQ テーブルを横断して候補を返すカスタム Retriever。

    「Pg」は PostgreSQL、「Hybrid」は keyword + vector のハイブリッド検索を表す。

    検索戦略の概要:
        * documents テーブルと faqs テーブルを必要に応じて両方検索
        * pgvector によるベクトル類似度 + tsvector による全文検索のスコアを
          HybridWeights(keyword, vector) に基づいて合成
        * 検索結果を LangChain Document(page_content, metadata) に変換して返す

    Args:
        doc_filters (DocumentSearchFilters | None):
            documents テーブル向けのフィルタ条件。
            組織コードやカテゴリなどアプリ固有の条件を含む。
        faq_filters (FAQSearchFilters | None):
            faqs テーブル向けのフィルタ条件。
        doc_limit (int):
            documents から取得する上限件数。
        faq_limit (int):
            faqs から取得する上限件数。
        keyword_weight (float):
            全文検索スコア(tsvector)にかける重み。
        vector_weight (float):
            ベクトル検索スコア(pgvector)にかける重み。
        semantic_queries (Sequence[str]):
            クエリ拡張済みのテキスト群。
            retriever は text_query と semantic_queries の両方を rag_search に渡し、
            ベクトル類似度計算に利用する。
    """

    def __init__(
        self,
        *,
        doc_filters: DocumentSearchFilters | None,
        faq_filters: FAQSearchFilters | None,
        doc_limit: int,
        faq_limit: int,
        keyword_weight: float,
        vector_weight: float,
        semantic_queries: Sequence[str],
        file_name_hints: Sequence[str] | None = None,
    ) -> None:
        self.doc_filters = doc_filters
        self.faq_filters = faq_filters
        self.doc_limit = doc_limit
        self.faq_limit = faq_limit
        self.keyword_weight = keyword_weight
        self.vector_weight = vector_weight
        # semantic_queries の前後空白を落とし、空文字は除外する
        self.semantic_queries = [q for q in (query.strip() for query in semantic_queries) if q]
        self.file_name_hints = [hint.strip() for hint in (file_name_hints or []) if hint and hint.strip()]

    def _build_weights(self) -> HybridWeights:
        """Create HybridWeights for hybrid search from configured keyword/vector weights.

        LangChain ではなくアプリ側で定義した `HybridWeights` 構造体を返す。
        rag_search 内のスコア合成処理に利用される。
        """
        return HybridWeights(keyword=self.keyword_weight, vector=self.vector_weight)

    async def _search(self, query: str) -> list[Document]:
        """Execute hybrid search over documents and FAQs, and return LangChain Documents.

        実際の検索は `rag_search.search_documents_hybrid` および
        `rag_search.search_faqs_hybrid` に委譲し、ここでは:

            * semantic_queries の決定
            * documents / faqs の検索呼び分け
            * 生の辞書結果 → LangChain Document への変換
            * デバッグログ出力

        を担当する。

        Args:
            query (str):
                ユーザーの質問文（text_query として渡す元のクエリ）。

        Returns:
            list[Document]:
                Document/FAQ を統一フォーマット（LangChain Document）へ変換した配列。
                page_content には snippet または answer が入り、
                その他の情報は metadata に格納される。
        """

        results: list[dict[str, Any]] = []
        weights = self._build_weights()

        # semantic_queries が指定されていなければ、元の query をそのまま使う
        semantic_inputs = self.semantic_queries or [query]
        start_ts = time.monotonic()

        logger.debug(
            "ハイブリッドリトリーバーの検索を開始",
            extra={
                "queries": semantic_inputs,
                "doc_limit": self.doc_limit,
                "faq_limit": self.faq_limit,
                "weights": {"keyword": weights.keyword, "vector": weights.vector},
                "doc_filters": _serialize_filters(self.doc_filters),
                "faq_filters": _serialize_filters(self.faq_filters),
            },
        )

        # documents テーブルのハイブリッド検索
        doc_rows: list[dict[str, Any]] = []
        if self.doc_limit > 0:
            doc_rows = await rag_search.search_documents_hybrid(
                text_query=query,
                semantic_queries=semantic_inputs,
                filters=self.doc_filters,
                limit=self.doc_limit,
                weights=weights,
                file_name_hints=self.file_name_hints,
            )
            results.extend(doc_rows)
            logger.debug(
                "ドキュメント検索の生結果を取得",
                extra={
                    "count": len(doc_rows),
                    "limit": self.doc_limit,
                    "sample_ids": [d.get("document_id") for d in doc_rows[:5]],
                },
            )

        # faqs テーブルのハイブリッド検索
        faq_rows: list[dict[str, Any]] = []
        if self.faq_limit > 0:
            faq_rows = await rag_search.search_faqs_hybrid(
                text_query=query,
                semantic_queries=semantic_inputs,
                filters=self.faq_filters,
                limit=self.faq_limit,
                weights=weights,
            )
            results.extend(faq_rows)
            logger.debug(
                "FAQ検索の生結果を取得",
                extra={
                    "count": len(faq_rows),
                    "limit": self.faq_limit,
                    "sample_ids": [f.get("faq_id") for f in faq_rows[:5]],
                },
            )

        # 生の dict リスト → LangChain Document リストに変換
        documents: list[Document] = []
        for item in results:
            # DB から返ってきた1レコードを metadata として扱う
            metadata = item.copy()

            # snippet があれば本文として優先し、ない場合は answer を fallback として利用する
            content = metadata.pop("snippet", None) or metadata.get("answer", "")

            documents.append(Document(page_content=str(content), metadata=metadata))

        logger.debug(
            "ハイブリッド検索結果を LangChain Document へ変換完了",
            extra={
                "count": len(documents),
                "sample_scores": [doc.metadata.get("score") for doc in documents[:5]],
                "origins": [doc.metadata.get("origin") for doc in documents[:5]],
                "sample_chunks": [
                    {
                        "document_id": doc.metadata.get("document_id"),
                        "chunk_id": doc.metadata.get("chunk_id"),
                        "faq_id": doc.metadata.get("faq_id"),
                        "score": doc.metadata.get("score"),
                    }
                    for doc in documents[:5]
                ],
            },
        )
        latency_ms = int((time.monotonic() - start_ts) * 1000)
        logger.info(
            "ハイブリッドリトリーバー処理が完了",
            extra={
                "event": "hybrid_retriever.complete",
                "latency_ms": latency_ms,
                "document_rows": len(doc_rows),
                "faq_rows": len(faq_rows),
                "document_count": len(documents),
                "doc_limit": self.doc_limit,
                "faq_limit": self.faq_limit,
            },
        )
        return documents

    async def aget_relevant_documents(self, query: str) -> list[Document]:
        """Asynchronous interface to retrieve relevant documents.

        Web 経路からのみ利用するため、同期フォールバックは提供しない。

        Args:
            query (str):
                ユーザーの質問文。

        Returns:
            list[Document]:
                検索結果を LangChain Document に変換した配列。
        """
        return await self._search(query)


__all__ = ["PgHybridRetriever"]
