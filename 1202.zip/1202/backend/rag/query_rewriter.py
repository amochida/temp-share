"""LLM を用いて検索クエリを文脈に合わせて言い換える補助モジュール。"""

from __future__ import annotations

import time
from typing import Any, Dict

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field

from backend.foundation.llm_client import (
    LLMError,
    extract_token_usage,
    get_langchain_chat_llm,
)
from backend.foundation.logging import configure_logging

logger = configure_logging(__name__)


class RewriteQueryResult(BaseModel):
    """クエリリライト結果のスキーマ（JSON 出力用）。"""

    query_text: str = Field(
        description=(
            "検索エンジンに渡すための、履歴を考慮した1文の日本語クエリ。"
            "敬語や前置きは不要で、端的な質問文にすること。"
        )
    )
    file_name_hints: list[str] = Field(
        default_factory=list,
        description=(
            "ユーザーの最新質問に含まれるファイル名・文書名の候補。"
            "ファイル名っぽい文字列が複数ある場合は最大5件まで含める。"
            "ファイル名が存在しない場合は空配列にする。"
        ),
    )


# JSON 出力用の OutputParser
_QUERY_REWRITE_OUTPUT_PARSER = PydanticOutputParser(pydantic_object=RewriteQueryResult)

# format_instructions をプロンプトから参照できるようにしておく
_QUERY_REWRITE_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            (
                "あなたは社内向けRAG検索システムのアシスタントです。"
                "これから与える直近の会話履歴とユーザーの最新質問を読み、"
                "検索に適した1文の質問と、質問文に含まれるファイル名候補を抽出してください。\n\n"
                "出力に関する重要なルール:\n"
                "- 出力は必ず1つのJSONオブジェクトのみとすること\n"
                "- JSON以外の余計な文章や説明は一切書かないこと\n"
            ),
        ),
        (
            "human",
            (
                "会話履歴:\n{history}\n\n"
                "最新の質問:\n{question}\n\n"
                "{format_instructions}"
            ),
        ),
    ]
)


async def rewrite_query_with_history(history: str, question: str) -> Dict[str, Any]:
    """履歴付きクエリを LLM で生成し、JSON 形式の結果を返す。

    戻り値の例:
        {
          \"query_text\": \"社員就業規則2024と賃金規程2024の違いを教えて\",
          \"file_name_hints\": [\"社員就業規則2024.pdf\", \"賃金規程2024.pdf\"]
        }

    - file_name_hints は、ユーザーの最新質問に含まれるファイル名・文書名の候補を
      最大5件まで含む配列。該当しない場合は空配列になる。
    """

    llm = get_langchain_chat_llm(temperature=0.1, purpose="query_rewriter")

    # JSON 形式の出力指示をプロンプトに埋め込む
    prompt = _QUERY_REWRITE_PROMPT.partial(
        format_instructions=_QUERY_REWRITE_OUTPUT_PARSER.get_format_instructions()
    )
    chain = prompt | llm

    logger.debug(
        "クエリリライト用に LLM へリクエストを送信",
        extra={"history": history, "question": question},
    )

    start_ts = time.monotonic()
    response = await chain.ainvoke({"history": history, "question": question})
    latency_ms = int((time.monotonic() - start_ts) * 1000)

    # LLM の生レスポンス（ChatMessage 等）から JSON をパース
    content = getattr(response, "content", "") or ""
    try:
        parsed: RewriteQueryResult = _QUERY_REWRITE_OUTPUT_PARSER.parse(content)
    except Exception as exc:  # パース失敗時はエラーとして扱う
        logger.exception(
            "クエリリライト結果の JSON パースに失敗しました",
            extra={"raw_content": content},
        )
        raise LLMError("failed to parse JSON from query rewriter") from exc

    # 後段が扱いやすいように dict で返す
    result: Dict[str, Any] = {
        "query_text": (parsed.query_text or "").strip(),
        # 空文字や空白だけのものは落として最大5件に制限
        "file_name_hints": [
            h.strip()
            for h in parsed.file_name_hints
            if h and h.strip()
        ][:5],
    }

    if not result["query_text"]:
        raise LLMError("empty query_text in query rewrite result")

    usage = extract_token_usage(response)
    logger.debug(
        "クエリリライト結果を受信",
        extra={
            "original_question": question,
            "rewritten_query": result["query_text"],
            "file_name_hints": result["file_name_hints"],
            "history_length": len(history or ""),
        },
    )
    logger.info(
        "クエリリライト用LLMの呼び出しが完了",
        extra={
            "event": "query_rewriter.llm_usage",
            "latency_ms": latency_ms,
            "prompt_tokens": usage["prompt_tokens"],
            "completion_tokens": usage["completion_tokens"],
            "total_tokens": usage["total_tokens"],
        },
    )
    return result


__all__ = ["rewrite_query_with_history"]
