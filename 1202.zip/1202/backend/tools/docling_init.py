"""Utility to download Docling models ahead of time."""
from __future__ import annotations

import os
from pathlib import Path

from docling.utils.model_downloader import download_models

DEFAULT_DOCLING_MODELS_DIR = "/app/models/docling"


def prepare_docling_models() -> Path:
    """Ensure Docling model artifacts exist locally and return their path."""

    target_dir = Path(
        os.getenv("DOCLING_ARTIFACTS_PATH", DEFAULT_DOCLING_MODELS_DIR)
    ).expanduser()

    if target_dir.exists() and any(target_dir.iterdir()):
        return target_dir

    target_dir.mkdir(parents=True, exist_ok=True)

    download_models(
        output_dir=target_dir,
        progress=True,
    )

    return target_dir


def main() -> None:  # pragma: no cover - utility entrypoint
    prepare_docling_models()


if __name__ == "__main__":  # pragma: no cover
    main()
