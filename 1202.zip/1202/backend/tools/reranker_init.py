"""Helper script to pre-download the reranker CrossEncoder model."""
from __future__ import annotations

import os
from pathlib import Path

from sentence_transformers import CrossEncoder

DEFAULT_MODEL_NAME = "hotchpotch/japanese-reranker-tiny-v2"
DEFAULT_MODEL_DIR = "/app/models/japanese-reranker-tiny-v2"


def prepare_model() -> Path:
    """Download the configured CrossEncoder model if missing."""

    model_name = os.getenv("RERANKER_MODEL_NAME", DEFAULT_MODEL_NAME)
    target_dir = Path(os.getenv("RERANKER_MODEL_DIR", DEFAULT_MODEL_DIR)).expanduser()
    if target_dir.exists() and any(target_dir.iterdir()):
        return target_dir

    target_dir.mkdir(parents=True, exist_ok=True)
    model = CrossEncoder(model_name)
    model.save(str(target_dir))
    return target_dir


def main() -> None:  # pragma: no cover - utility entrypoint
    prepare_model()


if __name__ == "__main__":  # pragma: no cover - script execution
    main()
