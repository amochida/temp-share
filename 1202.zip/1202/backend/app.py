"""FastAPIアプリケーションのエントリーポイント。

このモジュールはアプリ全体の「起点」として動作し、以下の責務を担う。

* FastAPI インスタンスの生成と共通設定（タイトル、OpenAPI 仕様のパスなど）
* ルーティング層（`backend.api`）の登録
* アプリ起動時・停止時のライフサイクルイベントに合わせたリソース確保／解放
  * 具体的には PostgreSQL 接続プールを起動時に確立し、終了時にクリーンに閉じる
* `/api/healthz` のようなメンテナンス用のシンプルなエンドポイント提供

"""
from __future__ import annotations

from uuid import uuid4

from fastapi import FastAPI, Request

from backend.api import register_routes
from backend.foundation.database import DatabaseConnectionPool
from backend.foundation.logging import configure_logging
from backend.foundation.request_context import (
    bind_api_name,
    bind_request_id,
    reset_api_name,
    reset_request_id,
)

# FastAPI 本体を生成する。タイトルや OpenAPI 仕様を公開するパスもここで定義する。
app = FastAPI(
    title="Staff RAG API",             # ブラウザのSwagger UIなどで表示されるサービス名
    version="0.1.0",                    # APIのバージョン。破壊的変更を判断する材料として活用する
    docs_url="/api/docs",               # Swagger UI の公開パス
    openapi_url="/api/openapi.json",    # 機械可読な OpenAPI 仕様のパス
    redoc_url="/api/redoc",             # ReDoc ドキュメントのパス（必要に応じて利用）
)
# 共通ロガーを設定し、モジュールパス（`backend.app`）をそのまま `module` フィールドに出力する。
logger = configure_logging(__name__)
logger.info("FastAPIアプリケーションの起動準備を開始", extra={"event": "app.startup.begin"})


@app.middleware("http")
async def request_context_middleware(request: Request, call_next):
    """request_id と api_name を ContextVar に束縛する共通ミドルウェア。"""

    # 既にリバースプロキシから X-Request-Id が届いている場合はそれを利用し、無ければ新規発行する
    request_id = request.headers.get("X-Request-Id") or str(uuid4())
    request_id_token = bind_request_id(request_id)
    # `/api/<name>/` 形式のプレフィックスから API 名を推定する。該当しなければ None を返す
    api_name = _extract_api_name(request.url.path)
    api_name_token = bind_api_name(api_name) if api_name else None

    # FastAPI の request.state にも同じ情報を保持し、エンドポイント内から参照可能にする。
    request.state.request_id = request_id
    request.state.api_name = api_name or "unknown"

    try:
        response = await call_next(request)
    finally:
        if api_name_token is not None:
            reset_api_name(api_name_token)
        reset_request_id(request_id_token)

    response.headers["X-Request-Id"] = request_id
    return response

# ルーティング層（backend.api以下）で定義された全エンドポイントを FastAPI インスタンスへ登録する。
# ルーターの詳細はそれぞれの `backend.api.*.router` モジュールを参照。
register_routes(app)


@app.on_event("startup")
def startup_event() -> None:
    """アプリ起動時に呼び出されるライフサイクルフック。

    主に以下の初期化処理を担う。

    * PostgreSQL との接続プールを確立する（以降のリクエストから素早く DB を使用できる）

    例外が発生した場合は FastAPI の起動自体が失敗し、コンテナのヘルスチェックで検知できる。
    """

    DatabaseConnectionPool.initialize()


@app.on_event("shutdown")
def shutdown_event() -> None:
    """アプリ停止時に呼び出されるクリーンアップ処理。

    接続プールを明示的に閉じることで、DB 側に不要なセッションを残さないようにする。
    本システムでは Docker コンテナ終了時に自動で実行される。
    """

    DatabaseConnectionPool.close()

@app.get("/api/health", tags=["health"])
def healthcheck() -> dict[str, str]:
    """監視や負荷分散のための単純なヘルスチェックエンドポイント。

    戻り値は常に一定の JSON (`{"status": "ok"}`) であり、
    ここで DB へのアクセスなどは行わない。インフラレベルの死活監視に活用する。
    """

    return {"status": "ok"}


def _extract_api_name(path: str) -> str | None:
    """`/api/<name>/...` の形式から API 名だけを抜き出すヘルパー。"""

    if not path.startswith("/api/"):
        return None

    segments = [segment for segment in path.split("/") if segment]
    if len(segments) < 2:
        return None

    return segments[1]
