-- ======================================================================
-- Staff Department RAG System - Core Schema
-- ======================================================================
-- このスキーマは、社内部門向けRAGシステムの中核データ構造を定義する
-- ドキュメント情報、FAQ情報、会話履歴、評価データ、監査ログを統一的に管理する
-- ======================================================================

-- ============================================================
-- タイムゾーン設定（日本標準時）
-- ============================================================
DO $$
BEGIN
    -- 接続中のデータベース名（本番: ragdb / 開発: ragdb-dev など）を動的に取得してタイムゾーン設定を適用
    EXECUTE format('ALTER DATABASE %I SET timezone TO %L', current_database(), 'Asia/Tokyo');
END
$$;

-- ============================================================
-- 必要な拡張モジュール
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";  -- UUID自動生成
CREATE EXTENSION IF NOT EXISTS vector;       -- pgvector: 意味ベクトル検索用
CREATE EXTENSION IF NOT EXISTS pg_trgm;      -- pg_trgm: 部分一致検索用（LIKE類似対応）

-- ============================================================
-- ドキュメントメタ情報
-- ============================================================
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),                    -- ドキュメントID
    department_code TEXT,                                             -- 管理部門コード（NULL/空は「全部門」扱い）
    title TEXT NOT NULL,                                               -- ドキュメントタイトル
    type TEXT,                                                         -- ドキュメント種別（規程／マニュアル／FAQなど）
    registration_type TEXT CHECK (registration_type IN ('manual','auto')) NOT NULL DEFAULT 'manual', -- 登録区分
    is_auto_import_target BOOLEAN NOT NULL DEFAULT FALSE,              -- 自動更新対象フラグ
    source_uri TEXT,                                                   -- 原本のURLまたは識別子
    public_scope TEXT CHECK (public_scope IN ('internal','restricted','public')) DEFAULT 'internal', -- 公開範囲
    status TEXT CHECK (status IN ('processing','ready','error','archived')) DEFAULT 'processing',     -- 処理状態
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,                 -- 柔軟な属性拡張用メタデータ
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),                     -- 登録日時
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()                      -- 更新日時
);

COMMENT ON TABLE documents IS
    '原本ドキュメントのメタ情報を保持するテーブル'
    ' 実ファイルは外部（SharePoint等）に存在し、DBには解析結果とメタのみ保持する';

COMMENT ON COLUMN documents.id IS 'ドキュメントを一意に識別するUUID';
COMMENT ON COLUMN documents.department_code IS 'フロントエンドから渡される部門コード。NULL/空文字は「全部門」で利用可能。';
COMMENT ON COLUMN documents.title IS 'ドキュメントのタイトル';
COMMENT ON COLUMN documents.type IS 'ドキュメントの種別（例：規程、マニュアル、FAQ）';
COMMENT ON COLUMN documents.registration_type IS '登録区分（manual=手動, auto=自動取込）';
COMMENT ON COLUMN documents.is_auto_import_target IS '自動取込対象かどうかを示すフラグ';
COMMENT ON COLUMN documents.source_uri IS '原本ドキュメントのURLまたは識別キー';
COMMENT ON COLUMN documents.public_scope IS '公開範囲（internal, restricted, public）';
COMMENT ON COLUMN documents.status IS 'ドキュメントの登録処理状態';
COMMENT ON COLUMN documents.metadata IS '任意の属性を保持するJSONB列。Sudachiトークン化済み情報や付随メタ情報を格納する。';
COMMENT ON COLUMN documents.created_at IS 'ドキュメント登録日時';
COMMENT ON COLUMN documents.updated_at IS '最終更新日時';

CREATE INDEX IF NOT EXISTS idx_documents_department_code ON documents(department_code);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_created_at ON documents(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_documents_metadata ON documents USING GIN(metadata);

-- ============================================================
-- ドキュメントチャンク情報
-- ============================================================
CREATE TABLE IF NOT EXISTS document_chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),                 -- チャンクID
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,    -- 紐づくドキュメントID
    chunk_label TEXT,               -- チャンク見出し（例：「第3章 労働時間」）
    chunk_order INT,                -- 同一ドキュメント内の順序
    page_start INT NOT NULL DEFAULT 1,  -- チャンク開始ページ（1始まり）
    page_end   INT NOT NULL DEFAULT 1,  -- チャンク終了ページ（1始まり）
    content TEXT NOT NULL,          -- チャンク本文
    summary TEXT,                   -- チャンク要約
    tokens_count INT,               -- チャンク内トークン数
    embedding VECTOR(1024),         -- 意味ベクトル（pgvector）
    content_tsv TSVECTOR NOT NULL DEFAULT to_tsvector('simple', ''),           -- 全文検索インデックス
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,  -- チャンク固有メタデータ（構造情報など）
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE document_chunks IS
    'ドキュメントを意味単位（章・段落など）に分割して保持するテーブル'
    ' pgvectorと全文検索(tsvector)を用いたハイブリッド検索に対応する'
    ' ドキュメントが物理削除されると、ON DELETE CASCADE により自動的に削除される';

COMMENT ON COLUMN document_chunks.id IS 'チャンクを一意に識別するUUID';
COMMENT ON COLUMN document_chunks.document_id IS '親ドキュメントのID（documents.id）';
COMMENT ON COLUMN document_chunks.chunk_label IS 'チャンクの見出しや章名';
COMMENT ON COLUMN document_chunks.chunk_order IS 'ドキュメント内のチャンク順序';
COMMENT ON COLUMN document_chunks.page_start IS 'チャンクがカバーする開始ページ番号（1始まり）';
COMMENT ON COLUMN document_chunks.page_end IS 'チャンクがカバーする終了ページ番号（1始まり）';
COMMENT ON COLUMN document_chunks.content IS 'チャンク本文テキスト';
COMMENT ON COLUMN document_chunks.summary IS 'チャンク本文の要約文（LLM再ランクなどに使用）';
COMMENT ON COLUMN document_chunks.tokens_count IS '本文トークン数（プロンプト長制御用）';
COMMENT ON COLUMN document_chunks.embedding IS 'チャンク本文の意味ベクトル（1024次元）';
COMMENT ON COLUMN document_chunks.content_tsv IS '全文検索用tsvectorデータ（SudachiPyで分かち書きした結果を格納）';
COMMENT ON COLUMN document_chunks.metadata IS '章タイトルや Element 情報など任意の属性を保持するJSONB列';
COMMENT ON COLUMN document_chunks.created_at IS 'レコード作成日時';
COMMENT ON COLUMN document_chunks.updated_at IS '最終更新日時';

CREATE INDEX IF NOT EXISTS idx_document_chunks_document_id ON document_chunks(document_id);
CREATE INDEX IF NOT EXISTS idx_document_chunks_content_tsv ON document_chunks USING GIN(content_tsv);
CREATE INDEX IF NOT EXISTS idx_document_chunks_embedding ON document_chunks USING ivfflat (embedding vector_cosine_ops);
CREATE INDEX IF NOT EXISTS idx_document_chunks_metadata ON document_chunks USING GIN(metadata);

-- ============================================================
-- FAQ情報テーブル
-- ============================================================
CREATE TABLE IF NOT EXISTS faqs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    department_code TEXT,
    category TEXT,
    type TEXT,
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    summary TEXT,
    tokens_count INT,
    embedding VECTOR(1024),
    question_tsv TSVECTOR NOT NULL DEFAULT to_tsvector('simple', ''),
    answer_tsv TSVECTOR NOT NULL DEFAULT to_tsvector('simple', ''),
    content_tsv TSVECTOR NOT NULL DEFAULT to_tsvector('simple', ''),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    public_scope TEXT CHECK (public_scope IN ('internal','restricted','public')) DEFAULT 'internal',
    status TEXT CHECK (status IN ('draft','ready','archived')) DEFAULT 'draft',
    created_by TEXT,
    updated_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE faqs IS
    '一問一答形式のFAQを保持するテーブル'
    ' 質問と回答をペアで管理し、意味ベクトルと全文検索の両方で検索対象となる';

COMMENT ON COLUMN faqs.id IS 'FAQを一意に識別するUUID';
COMMENT ON COLUMN faqs.department_code IS 'フロントエンドから渡される部門コード。NULL/空文字は「全部門」で利用可能。';
COMMENT ON COLUMN faqs.category IS 'FAQのカテゴリ（人事、勤怠、ITなど）';
COMMENT ON COLUMN faqs.type IS 'FAQの種別（業務手順、制度説明など）';
COMMENT ON COLUMN faqs.question IS '質問文（ユーザーのクエリとマッチングされる）';
COMMENT ON COLUMN faqs.answer IS '質問に対する回答文';
COMMENT ON COLUMN faqs.summary IS '回答の要約文（プロンプト最適化用）';
COMMENT ON COLUMN faqs.tokens_count IS '質問と回答の合計トークン数';
COMMENT ON COLUMN faqs.embedding IS 'FAQの意味ベクトル（1024次元）';
COMMENT ON COLUMN faqs.question_tsv IS '質問文の全文検索インデックス（tsvector形式、SudachiPyトークンを登録）';
COMMENT ON COLUMN faqs.answer_tsv IS '回答文の全文検索インデックス（tsvector形式、SudachiPyトークンを登録）';
COMMENT ON COLUMN faqs.content_tsv IS '質問と回答をまとめた全文検索インデックス（tsvector形式、SudachiPyトークンを登録）';
COMMENT ON COLUMN faqs.metadata IS 'タグや関連ドキュメントなど任意属性を保持するJSONB列';
COMMENT ON COLUMN faqs.public_scope IS '公開範囲（internal, restricted, public）';
COMMENT ON COLUMN faqs.status IS 'FAQの状態（draft, ready, archived）';
COMMENT ON COLUMN faqs.created_by IS '登録者の識別子（SSOヘッダー由来）';
COMMENT ON COLUMN faqs.updated_by IS '最終更新者の識別子（SSOヘッダー由来）';
COMMENT ON COLUMN faqs.created_at IS '登録日時';
COMMENT ON COLUMN faqs.updated_at IS '最終更新日時';

CREATE INDEX IF NOT EXISTS idx_faqs_department_code ON faqs(department_code);
CREATE INDEX IF NOT EXISTS idx_faqs_status ON faqs(status);
CREATE INDEX IF NOT EXISTS idx_faqs_created_at ON faqs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_faqs_question_tsv ON faqs USING GIN(question_tsv);
CREATE INDEX IF NOT EXISTS idx_faqs_answer_tsv ON faqs USING GIN(answer_tsv);
CREATE INDEX IF NOT EXISTS idx_faqs_content_tsv ON faqs USING GIN(content_tsv);
CREATE INDEX IF NOT EXISTS idx_faqs_embedding ON faqs USING ivfflat (embedding vector_cosine_ops);
CREATE INDEX IF NOT EXISTS idx_faqs_metadata ON faqs USING GIN(metadata);

-- ============================================================
-- スレッド情報（threads）
-- ============================================================
CREATE TABLE IF NOT EXISTS threads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),  -- スレッドID
    serial_no BIGSERIAL UNIQUE,                      -- 連番（デバッグ・並び替え用）
    user_id TEXT NOT NULL,                           -- スレッド作成者のユーザーID
    title TEXT,                                      -- スレッドタイトル（初回質問などを要約）
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,       -- 論理削除フラグ（TRUE=削除済み）
    deleted_at TIMESTAMPTZ,                          -- 削除日時（論理削除を実施した日時）
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),   -- 作成日時
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()    -- 最終更新日時
);

COMMENT ON TABLE threads IS
    'ユーザーが作成する会話スレッドを管理するテーブル'
    ' ユーザーはスレッドを論理削除可能で、削除から90日経過後に物理削除される';

COMMENT ON COLUMN threads.id IS 'スレッドを一意に識別するUUID';
COMMENT ON COLUMN threads.serial_no IS 'スレッドの連番（デバッグや並び替えに使用）';
COMMENT ON COLUMN threads.user_id IS 'スレッド作成者のユーザーID';
COMMENT ON COLUMN threads.title IS 'スレッドタイトル（初回質問の要約など）';
COMMENT ON COLUMN threads.is_deleted IS 'スレッドが削除済みかを示すフラグ（TRUE=削除済み）';
COMMENT ON COLUMN threads.deleted_at IS '論理削除を実施した日時';
COMMENT ON COLUMN threads.created_at IS 'スレッド作成日時';
COMMENT ON COLUMN threads.updated_at IS 'スレッド最終更新日時';

CREATE INDEX IF NOT EXISTS idx_threads_user_id ON threads(user_id);
CREATE INDEX IF NOT EXISTS idx_threads_is_deleted ON threads(is_deleted);
CREATE INDEX IF NOT EXISTS idx_threads_deleted_at ON threads(deleted_at);
CREATE INDEX IF NOT EXISTS idx_threads_created_at ON threads(created_at DESC);

-- ============================================================
-- 会話メッセージ情報（messages）
-- ============================================================
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),  -- メッセージID
    serial_no BIGSERIAL UNIQUE,                      -- 並び順・ページング用
    thread_id UUID REFERENCES threads(id) ON DELETE CASCADE, -- 紐づくスレッドID
    role TEXT CHECK (role IN ('user', 'assistant')) NOT NULL, -- 発話者種別
    content TEXT NOT NULL,                           -- メッセージ本文
    citations JSONB NOT NULL DEFAULT '[]'::jsonb,     -- 回答に添付された引用情報
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()    -- 発話日時
);

COMMENT ON TABLE messages IS
    'スレッド内の会話メッセージを保持するテーブル'
    ' スレッド削除は論理削除で管理されるため、削除済みスレッドのメッセージも保持される'
    ' スレッドが物理削除されると、ON DELETE CASCADE により自動的に削除される';

COMMENT ON COLUMN messages.id IS 'メッセージを一意に識別するUUID';
COMMENT ON COLUMN messages.serial_no IS 'メッセージの通し番号（並び替えやデバッグに使用）';
COMMENT ON COLUMN messages.thread_id IS '紐づくスレッドのUUID（threads.id）';
COMMENT ON COLUMN messages.role IS '発話者の種別（userまたはassistant）';
COMMENT ON COLUMN messages.content IS '会話メッセージの本文内容';
COMMENT ON COLUMN messages.citations IS '回答に添付された引用情報(JSONB)';
COMMENT ON COLUMN messages.created_at IS 'メッセージ作成日時';

CREATE INDEX IF NOT EXISTS idx_messages_thread_id ON messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

-- ============================================================
-- 回答評価情報（feedback）
-- ============================================================
CREATE TABLE IF NOT EXISTS feedback (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),                -- フィードバックID（主キー）
    user_id TEXT NOT NULL,                                         -- 評価を行ったユーザーID
    thread_id UUID,                                                -- 評価元スレッドID（threads.idの値を保持。外部キー制約は設けない）
    assistant_message_id UUID,                                     -- 評価対象となったメッセージID（messages.id を保持。FK は課していない）
    user_message TEXT NOT NULL,                                    -- 評価対象のユーザー発話内容（スナップショット保存）
    assistant_message TEXT NOT NULL,                               -- 評価対象のAI応答内容（スナップショット保存）
    rating TEXT CHECK (rating IN ('good', 'bad', 'cancel')) NOT NULL, -- ユーザー評価結果（good / bad / cancel）
    messages JSONB,                                                -- 評価時点の直近会話履歴（過去10件などをJSON形式で保存）
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()                  -- 登録日時（フィードバック実施日時）
);

COMMENT ON TABLE feedback IS
    'AI応答に対するユーザー評価を保持するテーブル。'
    ' threads / messages テーブルとは独立しており、スレッド削除後も評価情報を保持する。'
    ' 評価時点のユーザー発話・AI応答・会話履歴をスナップショットとして保存し、後続分析・モデル改善に活用する。'
    ' スナップショット設計により、参照元データが削除・変更されても当時の評価内容が失われない構造を採用。';

COMMENT ON COLUMN feedback.id IS 'フィードバックを一意に識別するUUID。';

COMMENT ON COLUMN feedback.user_id IS '評価を行ったユーザーの識別子。threads.user_idをコピー保存し、後続分析（部門・個人単位の傾向分析等）に利用可能。';

COMMENT ON COLUMN feedback.thread_id IS
    '評価元スレッドのUUID（threads.idの値を保持）。'
    ' threadsとの外部キー制約は設けず、削除済みスレッドの評価履歴を保持可能にする。';

COMMENT ON COLUMN feedback.assistant_message_id IS
    '評価対象の assistant メッセージID。messages.id を保持し、最新の評価状態を判定する用途で参照する。';

COMMENT ON COLUMN feedback.user_message IS
    'ユーザーがAIに入力した質問・発話の本文。'
    ' messagesテーブルの内容をスナップショットとして保存し、後から内容を再現できるようにする。';

COMMENT ON COLUMN feedback.assistant_message IS
    'AIが出力した回答本文。'
    ' 評価時点の回答を固定的に保存し、後からモデル改善や再学習に使用する。';

COMMENT ON COLUMN feedback.rating IS
    'ユーザーの評価結果。good（肯定）/bad（否定）/cancel（評価取り消し）のいずれかを保持。';

COMMENT ON COLUMN feedback.messages IS
    '評価時点の直近会話履歴をJSON形式で保存。'
    ' [{role, content}, ...] 構造を持ち、RAGモデル改善時のコンテキスト分析に使用する。';

COMMENT ON COLUMN feedback.created_at IS
    'フィードバック登録日時。ユーザーが評価を行った時刻を記録。';

CREATE INDEX IF NOT EXISTS idx_feedback_user_id ON feedback(user_id);
CREATE INDEX IF NOT EXISTS idx_feedback_thread_id ON feedback(thread_id);
CREATE INDEX IF NOT EXISTS idx_feedback_assistant_message_id ON feedback(assistant_message_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_feedback_rating ON feedback(rating);
CREATE INDEX IF NOT EXISTS idx_feedback_created_at ON feedback(created_at);
