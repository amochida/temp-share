#!/usr/bin/env bash
set -euo pipefail
# ------------------------------------------------------------
# Next.js + FastAPI 同時起動スクリプト
# ------------------------------------------------------------
# このスクリプトは app コンテナ内でフロントエンド(Next.js)
# とバックエンド(FastAPI)を並行して起動します。
# 
# 実行時の環境変数 ENVIRONMENT の値に応じて
# 「開発モード」と「本番モード」を自動で切り替えます。
#
# .env で指定する主な変数:
#   ENVIRONMENT=development or production
#   LOG_DIR=/var/log/rag
# ------------------------------------------------------------

# === 基本ディレクトリ設定 ==================================
APP_DIR=/app
BACKEND_DIR="${APP_DIR}/backend"
FRONTEND_DIR="${APP_DIR}/frontend"

# === .envから受け取る環境変数 ===============================
ENVIRONMENT=${ENVIRONMENT}
LOG_DIR=${LOG_DIR}
PYTHONPATH=${PYTHONPATH:-${APP_DIR}}

# === ログディレクトリの準備 =================================
# LOG_DIR が存在しない場合でも確実に作成
mkdir -p "${LOG_DIR}"
export LOG_DIR
export PYTHONPATH

# echo "リランカー用モデルを準備中..."
# python -m backend.tools.reranker_init

# echo "docling用モデルを準備中..."
# python -m backend.tools.docling_init

# ------------------------------------------------------------
# 開発モード（ENVIRONMENT=development）
# ------------------------------------------------------------
launch_dev() {
  echo "開発モードで起動します (FastAPI + Next.js)"
  echo "ホットリロードが有効です。コード変更が即時反映されます。"

  # Node.js 側のモードを development に設定
  export NODE_ENV=development

  # フロントエンドの依存関係を再確認
  echo "Node.js パッケージを再確認中..."
  cd "${FRONTEND_DIR}"
  npm_config_production=false npm install --legacy-peer-deps >/tmp/npm-dev.log 2>&1

  # FastAPI をホットリロードモードで起動
  echo "FastAPI (Uvicorn) を起動中..."
  uvicorn backend.app:app --host 0.0.0.0 --port 8000 --reload --app-dir "${BACKEND_DIR}" &
  UVICORN_PID=$!

  # Next.js を開発モードで起動
  echo "Next.js (npm run dev) を起動中..."
  npm run dev -- --hostname 0.0.0.0 --port 3000 &
  NEXT_PID=$!

  # Ctrl+Cなどで両方を安全に停止できるように設定
  trap 'echo "終了します"; kill ${UVICORN_PID} ${NEXT_PID}' INT TERM
  wait -n ${UVICORN_PID} ${NEXT_PID}
}

# ------------------------------------------------------------
# 本番モード（ENVIRONMENT=production）
# ------------------------------------------------------------
launch_prod() {
  echo "本番モードで起動します (FastAPI + Next.js)"
  echo "ホットリロードは無効です。最適化済みのビルドを使用します。"

  # Node.js 側のモードを production に設定
  export NODE_ENV=production

  # FastAPI を通常モードで起動
  echo "FastAPI (Uvicorn) を起動中..."
  uvicorn backend.app:app --host 0.0.0.0 --port 8000 --app-dir "${BACKEND_DIR}" --workers 8 &
  UVICORN_PID=$!

  # Next.js を本番モードで起動
  echo "Next.js (npm run start) を起動中..."
  cd "${FRONTEND_DIR}"
  npm run start -- --hostname 0.0.0.0 --port 3000 &
  NEXT_PID=$!

  # Ctrl+Cなどで両方を安全に停止できるように設定
  trap 'echo "終了します"; kill ${UVICORN_PID} ${NEXT_PID}' INT TERM
  wait -n ${UVICORN_PID} ${NEXT_PID}
}

# ------------------------------------------------------------
# 実行モードの判定
# ------------------------------------------------------------
if [ "${ENVIRONMENT}" = "development" ]; then
  launch_dev
else
  launch_prod
fi
